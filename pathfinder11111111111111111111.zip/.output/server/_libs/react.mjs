import { t as __commonJSMin } from "../_runtime.mjs";
//#region node_modules/react/cjs/react-jsx-dev-runtime.production.js
/**
* @license React
* react-jsx-dev-runtime.production.js
*
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*/
var require_react_jsx_dev_runtime_production = /* @__PURE__ */ __commonJSMin(((exports) => {
	exports.Fragment = Symbol.for("react.fragment");
	exports.jsxDEV = void 0;
}));
//#endregion
//#region node_modules/react/jsx-dev-runtime.js
var require_jsx_dev_runtime = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = require_react_jsx_dev_runtime_production();
}));
//#endregion
export { require_jsx_dev_runtime as t };
