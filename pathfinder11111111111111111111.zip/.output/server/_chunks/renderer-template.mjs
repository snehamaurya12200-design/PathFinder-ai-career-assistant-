import { r as HTTPResponse } from "../_libs/h3+rou3+srvx.mjs";
//#region #nitro/virtual/renderer-template
var rendererTemplate = () => new HTTPResponse("<!doctype html>\n<html lang=\"en\">\n  <head>\n    <meta charset=\"UTF-8\" />\n    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />\n    <title>Pathfinder — Discover Your Direction</title>\n    <meta name=\"description\" content=\"Discover your career direction with personalized roadmaps, skill matching, and AI guidance.\" />\n    <meta name=\"author\" content=\"Pathfinder\" />\n    <link rel=\"icon\" type=\"image/svg+xml\" href=\"/favicon.svg\" />\n    <link rel=\"icon\" type=\"image/x-icon\" href=\"/favicon.ico\" />\n    <link rel=\"apple-touch-icon\" href=\"/apple-touch-icon.png\" />\n    <meta property=\"og:title\" content=\"Pathfinder — Discover Your Direction\" />\n    <meta property=\"og:description\" content=\"Discover your career direction with personalized roadmaps, skill matching, and AI guidance.\" />\n    <meta property=\"og:type\" content=\"website\" />\n    <meta name=\"twitter:card\" content=\"summary_large_image\" />\n    <meta name=\"twitter:site\" content=\"@Pathfinder\" />\n    <meta name=\"twitter:title\" content=\"Pathfinder — Discover Your Direction\" />\n    <meta name=\"twitter:description\" content=\"Discover your career direction with personalized roadmaps, skill matching, and AI guidance.\" />\n  </head>\n  <body>\n    <div id=\"root\"></div>\n    <script type=\"module\" src=\"/src/main.tsx\"><\/script>\n  </body>\n</html>\n", { headers: { "content-type": "text/html; charset=utf-8" } });
//#endregion
//#region node_modules/nitro/dist/runtime/internal/routes/renderer-template.mjs
function renderIndexHTML(event) {
	return rendererTemplate(event.req);
}
//#endregion
export { renderIndexHTML as default };
