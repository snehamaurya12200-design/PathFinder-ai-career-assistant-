import { n as __toESM } from "../_runtime.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as require_jsx_dev_runtime } from "../_libs/react.mjs";
import { M as Plus, N as Play, W as LoaderCircle, _t as CircleCheck, lt as Compass, nt as Folder, ot as EllipsisVertical, v as Square, y as Sparkles, yt as ChevronRight, z as MessageCircle } from "../_libs/lucide-react.mjs";
import { d as readiness, f as usePathfinder, l as actions, n as AppShell } from "./AppShell-CmHrRTAn.mjs";
import { t as analyzeResumeWithGemini } from "./ai.functions-u7pgug8o.mjs";
import { t as blob_default } from "./blob-C9HcxTYw.mjs";
import { a as goalSkills, c as recommend, r as courseById, s as jobs } from "./pathfinder-data-LKyDtySq.mjs";
import { i as MockInterviewDialog, n as CourseDialog, o as StatusBadge } from "./dialogs-MK7DwIGg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Dd2MoNa6.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_dev_runtime = require_jsx_dev_runtime();
var tile_default = "/assets/tile-FnTGXmeG.png";
var gem_default = "/assets/gem-Duh8pW0V.png";
var _jsxFileName = "/app/applet/src/routes/index.tsx?tsr-split=component";
var skillBars = [
	{
		name: "Frontend",
		c: "bg-mint"
	},
	{
		name: "Communication",
		c: "bg-violet"
	},
	{
		name: "Data Structures",
		c: "bg-sun"
	}
];
var imgs = [
	blob_default,
	tile_default,
	gem_default
];
function Card({ className = "", children }) {
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
		className: `rounded-2xl border bg-card p-4 ${className}`,
		children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 31,
		columnNumber: 10
	}, this);
}
function Dashboard() {
	const st = usePathfinder((s) => s);
	const ready = readiness(st, goalSkills(st.goal));
	const recs = recommend(st.goal, st.skills, Object.keys(st.enrolled).filter((k) => st.enrolled[k] === 100), st.profile).slice(0, 3);
	const latestApp = st.applications[st.applications.length - 1];
	const feedJob = latestApp ? jobs.find((j) => j.id === latestApp.jobId) : [...jobs].sort((a, b) => b.match - a.match)[0];
	const ongoingId = Object.keys(st.enrolled).find((k) => st.enrolled[k] < 100);
	const ongoing = ongoingId ? courseById(ongoingId) : void 0;
	const ongoingPct = ongoingId ? st.enrolled[ongoingId] : 0;
	const [course, setCourse] = (0, import_react.useState)(null);
	const [iv, setIv] = (0, import_react.useState)(false);
	const [analyzingCv, setAnalyzingCv] = (0, import_react.useState)(false);
	const joined = st.groups.includes("Pathfinder Community");
	async function handleCvUpload(file) {
		setAnalyzingCv(true);
		try {
			let content = "";
			try {
				content = await file.text();
			} catch {
				content = "";
			}
			if (!content || content.trim().length < 20) content = `Candidate profile for ${file.name}. Experience in HTML, CSS, JavaScript, React components, state management and user interfaces. Goal: ${st.goal}.`;
			const res = await analyzeResumeWithGemini({ data: {
				fileName: file.name,
				content: content.slice(0, 8e3),
				targetGoal: st.goal
			} });
			if (res.ok && res.data) {
				actions.setCvAnalysis(file.name, {
					candidateName: res.data.candidateName,
					summary: res.data.summary,
					matchScore: res.data.matchScore,
					extractedSkills: res.data.extractedSkills || {},
					strengths: res.data.strengths || [],
					gaps: res.data.gaps || [],
					recommendations: res.data.recommendations || [],
					recommendedCourseId: res.data.recommendedCourseId,
					analyzedAt: (/* @__PURE__ */ new Date()).toISOString()
				});
				actions.addChatMessage({
					me: false,
					t: `I have reviewed your CV (${file.name}) for ${st.goal}!\n\nOverall Match: ${res.data.matchScore}%\n${res.data.summary}\n\nStrengths: ${(res.data.strengths || []).join(", ")}\nSkill Gaps: ${(res.data.gaps || []).join(", ")}\n\nI've updated your skills and recommended courses on your dashboard!`
				});
				toast.success(`CV analyzed: ${res.data.matchScore}% match for ${st.goal}`, { description: "Skills and AI insights updated across the platform." });
			} else {
				actions.setCvAnalysis(file.name, {
					summary: "Resume uploaded and skills mapped to your profile.",
					matchScore: 84,
					extractedSkills: {
						Frontend: 65,
						React: 55,
						JavaScript: 60,
						Communication: 40
					},
					strengths: ["Component building", "Web standards"],
					gaps: ["Advanced state", "System design"],
					recommendations: ["Complete React Pro"],
					analyzedAt: (/* @__PURE__ */ new Date()).toISOString()
				});
				toast.success("CV uploaded and profile updated");
			}
		} catch (err) {
			console.error(err);
			toast.error("Failed to analyze CV with Gemini");
		} finally {
			setAnalyzingCv(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(AppShell, { children: [
		/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
			className: "mb-6 flex flex-wrap items-center justify-between gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h1", {
				className: "mb-1 text-2xl font-bold",
				children: "Hello, Sneha 👋"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 114,
				columnNumber: 11
			}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
				className: "text-sm text-muted-foreground",
				children: [
					"Goal:",
					" ",
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Link, {
						to: "/roadmap",
						className: "font-bold text-foreground",
						children: st.goal
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 117,
						columnNumber: 13
					}, this),
					" ",
					"· ",
					ready,
					"% career-ready"
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 115,
				columnNumber: 11
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 113,
				columnNumber: 9
			}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Link, {
				to: "/quest",
				className: "inline-flex items-center gap-2.5 rounded-2xl border border-stone-200/90 bg-card px-4 py-2 text-xs font-semibold text-foreground shadow-sm hover:border-violet/40 hover:shadow-md transition-all",
				children: [
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "grid h-6 w-6 place-items-center rounded-lg bg-lilac/50 text-violet",
						children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Compass, { className: "h-3.5 w-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 126,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 125,
						columnNumber: 11
					}, this),
					st.careerDNA ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: [
						"Career DNA:",
						" ",
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("strong", {
							className: "text-foreground",
							children: st.careerDNA.archetype.title
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 130,
							columnNumber: 15
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 128,
						columnNumber: 27
					}, this) : /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: [
						"Take ",
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("strong", { children: "Career Quest" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 132,
							columnNumber: 20
						}, this),
						" (5-Round Discovery)"
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 131,
						columnNumber: 23
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(ChevronRight, { className: "h-3.5 w-3.5 text-muted-foreground" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 134,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 124,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 112,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
			className: "grid gap-5 xl:grid-cols-[1fr_300px]",
			children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "space-y-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "grid gap-5 md:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Card, { children: [
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "flex justify-between text-sm font-semibold",
								children: [
									"Lessons taken",
									" ",
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Link, {
										to: "/learning",
										className: "rounded-full border px-2 text-xs font-normal",
										children: "Details"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 143,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 141,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "mt-6 flex items-end gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
										className: "text-6xl font-semibold",
										children: st.lessonsDone
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 148,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
										className: "mb-8 text-xs text-orange",
										children: "↑ 7%"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 149,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("svg", {
										viewBox: "0 0 100 40",
										className: "mb-2 h-12 w-28",
										children: [
											/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("defs", { children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("linearGradient", {
												id: "g",
												x1: "0",
												x2: "0",
												y1: "0",
												y2: "1",
												children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("stop", {
													offset: "0",
													stopColor: "var(--orange)",
													stopOpacity: ".4"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 153,
													columnNumber: 23
												}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("stop", {
													offset: "1",
													stopColor: "var(--orange)",
													stopOpacity: "0"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 154,
													columnNumber: 23
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 152,
												columnNumber: 21
											}, this) }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 151,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("path", {
												d: "M0 38 L30 30 L55 8 L75 22 L100 18 L100 40 L0 40Z",
												fill: "url(#g)"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 157,
												columnNumber: 19
											}, this),
											/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("path", {
												d: "M0 38 L30 30 L55 8 L75 22 L100 18",
												fill: "none",
												stroke: "var(--orange)",
												strokeWidth: "2"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 158,
												columnNumber: 19
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 150,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 147,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
								className: "text-xs text-muted-foreground",
								children: "Lessons completed"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 161,
								columnNumber: 15
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 140,
							columnNumber: 13
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Card, {
							className: "grid grid-cols-2 gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "flex flex-col",
								children: [
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
										className: "text-sm font-semibold",
										children: "Skill tracker"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 165,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "mt-auto",
										children: [
											/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
												className: "text-5xl font-semibold",
												children: [st.hours, "h"]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 167,
												columnNumber: 19
											}, this),
											" ",
											/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
												className: "text-xs text-mint",
												children: "↑ 12%"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 168,
												columnNumber: 19
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 166,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
										className: "text-xs text-muted-foreground",
										children: "Hours spent learning"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 170,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 164,
								columnNumber: 15
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "space-y-3",
								children: [skillBars.map((s) => {
									const v = st.skills[s.name] ?? 0;
									return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Link, {
										to: "/skills",
										className: "block",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "flex justify-between text-xs",
											children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: s.name }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 177,
												columnNumber: 25
											}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: [v, "%"] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 178,
												columnNumber: 25
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 176,
											columnNumber: 23
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "mt-1 h-2 rounded-full bg-muted",
											children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
												className: `h-2 rounded-full ${s.c} transition-all`,
												style: { width: `${v}%` }
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 181,
												columnNumber: 25
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 180,
											columnNumber: 23
										}, this)]
									}, s.name, true, {
										fileName: _jsxFileName,
										lineNumber: 175,
										columnNumber: 24
									}, this);
								}), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Link, {
									to: "/skills",
									className: "block text-right text-xs text-link",
									children: [
										"+ view ",
										Math.max(0, Object.keys(st.skills).length - 3),
										" more skills"
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 187,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 172,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 163,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 139,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "grid gap-5 md:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "rounded-2xl bg-ink p-4 text-ink-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
										className: "text-xs opacity-70",
										children: "Job Feed"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 196,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Link, {
										to: "/jobs",
										search: latestApp ? { app: feedJob.id } : { job: feedJob.id },
										className: "relative mt-3 block rounded-xl bg-card p-3 text-card-foreground",
										children: [
											/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
												className: "text-sm font-semibold",
												children: feedJob.title
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 202,
												columnNumber: 17
											}, this),
											/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
												className: "mt-1 text-xs text-muted-foreground",
												children: [
													feedJob.company,
													" ·",
													" ",
													latestApp ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(StatusBadge, { status: latestApp.status }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 205,
														columnNumber: 32
													}, this) : `${feedJob.match}% match`
												]
											}, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 203,
												columnNumber: 17
											}, this),
											/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
												className: "mt-3 h-3 rounded bg-muted-foreground/40",
												style: { width: `${feedJob.match}%` }
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 207,
												columnNumber: 17
											}, this),
											/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(ChevronRight, { className: "absolute -right-3 top-1/2 h-6 w-6 -translate-y-1/2 rounded-full border bg-card p-1" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 210,
												columnNumber: 17
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 197,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Link, {
										to: "/jobs",
										className: "mt-4 block w-full rounded-full bg-card/15 py-2 text-center text-xs",
										children: st.applications.length ? `${st.applications.length} application${st.applications.length > 1 ? "s" : ""} · view all` : "Tap on card to analyse"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 212,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 195,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Card, {
								className: "flex flex-col",
								children: [
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
											className: "grid h-8 w-8 place-items-center rounded-full bg-blush",
											children: "🎤"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 218,
											columnNumber: 17
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
											className: "rounded-full border px-2 text-xs",
											children: "» MOCK"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 219,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 217,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
										className: "mt-3 text-sm font-semibold",
										children: "Try our Mock Interview tool"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 221,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
										className: "text-xs text-muted-foreground",
										children: "Practise answers with live AI feedback"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 222,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
										onClick: () => setIv(true),
										className: "mt-auto flex items-center justify-between pt-3 text-sm text-link",
										children: [
											st.interviews[0] ? `Start · last ${st.interviews[0].score}%` : "Start",
											" ",
											/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(ChevronRight, { className: "h-5 w-5 rounded-full bg-lilac p-0.5" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 227,
												columnNumber: 17
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 225,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 216,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Card, {
								className: "text-center",
								children: [
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
										className: "text-sm font-semibold",
										children: "Upload your CV"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 231,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
										className: "text-xs text-muted-foreground",
										children: "We'll review it and suggest next steps"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 232,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("label", {
										className: "mt-3 flex cursor-pointer flex-col items-center justify-center rounded-xl border-2 border-dashed border-link/40 bg-lilac/40 py-5 text-xs text-link transition hover:bg-lilac/60",
										children: [analyzingCv ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "flex flex-col items-center gap-1.5 py-1",
											children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(LoaderCircle, { className: "h-6 w-6 animate-spin text-link" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 237,
												columnNumber: 21
											}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: "Analyzing with Gemini…" }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 238,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 236,
											columnNumber: 32
										}, this) : st.cvName ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "flex flex-col items-center gap-1 py-1",
											children: [
												/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
													className: "flex items-center gap-1 font-semibold text-foreground",
													children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(CircleCheck, { className: "h-4 w-4 text-success" }, void 0, false, {
														fileName: _jsxFileName,
														lineNumber: 241,
														columnNumber: 23
													}, this), st.cvName]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 240,
													columnNumber: 21
												}, this),
												/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
													className: "rounded-full bg-mint px-2 py-0.5 text-[10px] font-bold text-primary-foreground",
													children: [st.cvAnalysis?.matchScore ?? 84, "% Match"]
												}, void 0, true, {
													fileName: _jsxFileName,
													lineNumber: 244,
													columnNumber: 21
												}, this),
												/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
													className: "text-[10px] text-muted-foreground underline",
													children: "Upload new CV"
												}, void 0, false, {
													fileName: _jsxFileName,
													lineNumber: 247,
													columnNumber: 21
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 239,
											columnNumber: 40
										}, this) : /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(import_jsx_dev_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Folder, { className: "mb-1 h-7 w-7 fill-link/70" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 251,
											columnNumber: 21
										}, this), " Drag & Drop file here"] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 250,
											columnNumber: 28
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("input", {
											type: "file",
											accept: ".pdf,.doc,.docx,.txt",
											className: "hidden",
											disabled: analyzingCv,
											onChange: (e) => {
												const f = e.target.files?.[0];
												if (f) handleCvUpload(f);
											}
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 253,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 235,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 230,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 194,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "mb-3 flex justify-between text-sm font-semibold",
						children: [
							"Course Recommendations",
							" ",
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Link, {
								to: "/learning",
								className: "text-xs font-normal text-link",
								children: "View all"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 264,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 262,
						columnNumber: 13
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "grid gap-5 md:grid-cols-3",
						children: recs.map(({ course: c, reason }, i) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
							onClick: () => setCourse({
								id: c.id,
								reason
							}),
							className: `rounded-2xl ${c.bg} p-4 text-left transition hover:-translate-y-0.5`,
							children: [
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("img", {
									src: imgs[i % 3],
									alt: "",
									width: 816,
									height: 816,
									loading: "lazy",
									className: "mx-auto h-24 w-24 object-contain"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 276,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: "mt-2 flex justify-between font-semibold",
									children: [c.title, /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(EllipsisVertical, { className: "h-4 w-4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 279,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 277,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
									className: "text-xs text-muted-foreground",
									children: c.desc
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 281,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: "mt-3 flex gap-2",
									children: [`${c.lessons} lessons`, st.enrolled[c.id] !== void 0 ? `${st.enrolled[c.id]}% done` : c.level].map((t) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
										className: "rounded-full bg-card/70 px-2 py-0.5 text-[10px]",
										children: t
									}, t, false, {
										fileName: _jsxFileName,
										lineNumber: 283,
										columnNumber: 130
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 282,
									columnNumber: 19
								}, this)
							]
						}, c.id, true, {
							fileName: _jsxFileName,
							lineNumber: 272,
							columnNumber: 22
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 268,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 261,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 138,
				columnNumber: 9
			}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "space-y-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Calendar, { interviews: st.applications.filter((a) => a.interview?.date).map((a) => a.interview.date) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 293,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "mb-2 flex justify-between text-sm font-semibold",
						children: [
							"Upcoming Lessons",
							" ",
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Link, {
								to: "/learning",
								className: "text-xs font-normal text-link",
								children: "View all"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 297,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 295,
						columnNumber: 13
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Card, { children: [
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "flex justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
								className: "grid h-8 w-8 place-items-center rounded-lg bg-lilac text-xs font-bold",
								children: ongoing?.title[0] ?? "+"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 303,
								columnNumber: 17
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(EllipsisVertical, { className: "h-4 w-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 306,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 302,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
							onClick: () => ongoing && setCourse({ id: ongoing.id }),
							className: "block text-left",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
								className: "mt-3 text-lg font-semibold",
								children: ongoing?.title ?? "No ongoing course"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 311,
								columnNumber: 17
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
								className: "text-xs text-muted-foreground",
								children: ongoing?.desc ?? "Enroll in a course from Learning"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 314,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 308,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "mt-3 flex justify-between text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: ongoing ? `${Math.round(ongoingPct / 100 * ongoing.lessons)} of ${ongoing.lessons}` : "0 of 0" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 319,
								columnNumber: 17
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: [ongoingPct, "%"] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 322,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 318,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "mt-1 h-2 rounded-full bg-muted",
							children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "h-2 rounded-full bg-mint transition-all",
								style: { width: `${ongoingPct}%` }
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 325,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 324,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "mt-4 flex items-center gap-2 rounded-full bg-ink p-1 text-ink-foreground",
							children: [
								ongoing ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
									className: "flex-1 pl-3 text-left text-xs",
									onClick: () => setCourse({ id: ongoing.id }),
									children: "Join lesson"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 330,
									columnNumber: 28
								}, this) : /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Link, {
									to: "/learning",
									className: "flex-1 pl-3 text-xs",
									children: "Browse courses"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 334,
									columnNumber: 31
								}, this),
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
									"aria-label": "Complete lesson",
									disabled: !ongoing,
									onClick: () => {
										if (ongoing) {
											actions.progressCourse(ongoing.id, Math.ceil(100 / ongoing.lessons), ongoing.skills, 1);
											toast.success("Lesson completed", { description: ongoing.title });
										}
									},
									children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Play, { className: "h-7 w-7 rounded-full bg-card/15 p-1.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 345,
										columnNumber: 19
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 337,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Link, {
									to: "/learning",
									"aria-label": "All courses",
									children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Square, { className: "h-7 w-7 rounded-full bg-card/15 p-2" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 348,
										columnNumber: 19
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 347,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Link, {
									to: "/assistant",
									"aria-label": "Ask assistant",
									children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(MessageCircle, { className: "h-7 w-7 rounded-full bg-card/15 p-1.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 351,
										columnNumber: 19
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 350,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 329,
							columnNumber: 15
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 301,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 294,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Link, {
						to: "/learning",
						className: "block",
						children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Card, {
							className: "ai-ring",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
								className: "flex items-center gap-1 text-sm font-semibold",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Sparkles, { className: "h-4 w-4 text-violet" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 359,
									columnNumber: 17
								}, this), " AI Insight"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 358,
								columnNumber: 15
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
								className: "mt-2 text-xs text-muted-foreground",
								children: recs[0] ? recs[0].reason : "You're on track — keep practising with mock tests."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 361,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 357,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 356,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Card, {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Link, {
							to: "/networking",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
								className: "text-2xl font-semibold",
								children: joined ? "1351+" : "1350+"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 368,
								columnNumber: 15
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
								className: "text-xs text-muted-foreground",
								children: "Students in our community"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 369,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 367,
							columnNumber: 13
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
							onClick: () => {
								actions.toggleGroup("Pathfinder Community");
								toast(joined ? "Left the community" : "Joined the community");
							},
							className: "flex h-8 items-center gap-1 rounded-full border px-3 text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Plus, { className: "h-3 w-3" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 375,
								columnNumber: 15
							}, this), joined ? "Joined" : "Join"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 371,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 366,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 292,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 137,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(CourseDialog, {
			courseId: course?.id ?? null,
			reason: course?.reason,
			open: course !== null,
			onOpenChange: (o) => !o && setCourse(null)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 381,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(MockInterviewDialog, {
			open: iv,
			onOpenChange: setIv
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 382,
			columnNumber: 7
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 111,
		columnNumber: 10
	}, this);
}
function Calendar({ interviews }) {
	const days = Array.from({ length: 35 }, (_, i) => i - 3);
	const marked = [
		7,
		10,
		17,
		22,
		24,
		29,
		...interviews.filter((d) => d.startsWith("2026-10")).map((d) => Number(d.slice(8)))
	];
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Card, { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
		className: "mb-3 flex justify-between text-sm font-semibold",
		children: ["October 2026 ", /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
			className: "rounded-full border px-2 text-xs font-normal",
			children: "Jan ▾"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 397,
			columnNumber: 22
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 396,
		columnNumber: 7
	}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
		className: "grid grid-cols-7 gap-y-2 text-center text-xs",
		children: [[
			"S",
			"M",
			"T",
			"W",
			"T",
			"F",
			"S"
		].map((d, i) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
			className: "text-muted-foreground",
			children: d
		}, i, false, {
			fileName: _jsxFileName,
			lineNumber: 400,
			columnNumber: 60
		}, this)), days.map((d) => {
			const n = d < 1 ? 30 + d : d > 31 ? d - 31 : d;
			return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
				className: `mx-auto grid h-7 w-7 place-items-center rounded-full ${d < 1 || d > 31 ? "text-muted-foreground/50" : ""} ${marked.includes(d) ? "bg-ink text-ink-foreground" : ""} ${d === 31 ? "border border-ink" : ""}`,
				children: n
			}, d, false, {
				fileName: _jsxFileName,
				lineNumber: 406,
				columnNumber: 16
			}, this);
		})]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 399,
		columnNumber: 7
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 395,
		columnNumber: 10
	}, this);
}
//#endregion
export { Dashboard as component };
