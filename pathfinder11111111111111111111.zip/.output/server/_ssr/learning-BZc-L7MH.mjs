import { _ as createFileRoute, g as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as objectType, r as enumType, s as stringType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/learning-BZc-L7MH.js
var $$splitComponentImporter = () => import("./learning-CTHPXpuJ.mjs");
var Route = createFileRoute("/learning")({
	validateSearch: objectType({
		course: stringType().optional(),
		open: enumType(["test", "interview"]).optional(),
		query: stringType().optional()
	}),
	head: () => ({ meta: [
		{ title: "My Development — Pathfinder" },
		{
			name: "description",
			content: "Leadership learning path, lessons and development skill comparison."
		},
		{
			property: "og:title",
			content: "My Development — Pathfinder"
		},
		{
			property: "og:description",
			content: "Your leadership learning journey."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
