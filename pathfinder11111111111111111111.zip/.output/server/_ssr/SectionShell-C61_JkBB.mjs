import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as require_jsx_dev_runtime } from "../_libs/react.mjs";
import { n as AppShell } from "./AppShell-CmHrRTAn.mjs";
import { t as Button } from "./button-Cp1tlOE-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/SectionShell-C61_JkBB.js
var import_jsx_dev_runtime = require_jsx_dev_runtime();
var _jsxFileName = "/app/applet/src/components/SectionShell.tsx";
function SectionShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(AppShell, { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("nav", {
		"aria-label": "Career sections",
		className: "mb-6 flex flex-wrap gap-2",
		children: [
			{
				to: "/interviews",
				label: "Interviews"
			},
			{
				to: "/roadmap",
				label: "My Roadmaps"
			},
			{
				to: "/learning",
				label: "My development"
			},
			{
				to: "/skills",
				label: "Assessment Report"
			}
		].map((item) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Button, {
			asChild: true,
			variant: "outline",
			size: "sm",
			children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Link, {
				to: item.to,
				activeProps: { className: "bg-lilac text-violet" },
				children: item.label
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 19,
				columnNumber: 13
			}, this)
		}, item.to, false, {
			fileName: _jsxFileName,
			lineNumber: 18,
			columnNumber: 11
		}, this))
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 9,
		columnNumber: 7
	}, this), children] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 8,
		columnNumber: 5
	}, this);
}
//#endregion
export { SectionShell as t };
