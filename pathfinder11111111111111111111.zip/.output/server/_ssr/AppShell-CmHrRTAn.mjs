import { n as __toESM } from "../_runtime.mjs";
import { b as useNavigate, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as require_jsx_dev_runtime } from "../_libs/react.mjs";
import { $ as GraduationCap, B as MapPin, Ct as CheckCheck, D as Search, Dt as Briefcase, G as Lightbulb, H as LogOut, I as Moon, K as LifeBuoy, L as MoonStar, Nt as Bell, Ot as BriefcaseBusiness, St as Check, T as Send, V as Mail, Y as KeyRound, _ as Sun, _t as CircleCheck, at as ExternalLink, et as Globe, ht as CircleQuestionMark, lt as Compass, m as Trash2, n as X, o as Users, p as TriangleAlert, q as LayoutGrid, s as User, st as Crown, tt as Github, w as Settings, x as Shield, xt as ChevronDown, y as Sparkles, yt as ChevronRight, z as MessageCircle } from "../_libs/lucide-react.mjs";
import { a as DialogOverlay$1, i as DialogDescription$1, n as DialogClose, o as DialogPortal$1, r as DialogContent$1, s as DialogTitle$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { i as Trigger, n as Portal, r as Root2, t as Content2 } from "../_libs/@radix-ui/react-popover+[...].mjs";
import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { i as Trigger$1, n as List, r as Root2$1, t as Content } from "../_libs/radix-ui__react-tabs.mjs";
import { n as SwitchThumb, t as Switch$1 } from "../_libs/radix-ui__react-switch.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/AppShell-CmHrRTAn.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_dev_runtime = require_jsx_dev_runtime();
var shapes_default = "/assets/shapes-CG5F2UXs.png";
var APP_STATUSES = [
	"Applied",
	"Under Review",
	"Shortlisted",
	"Interview Scheduled",
	"Selected",
	"Rejected"
];
var DEFAULT_SKILLS = {
	Frontend: 60,
	Communication: 12,
	"Data Structures": 27,
	JavaScript: 55,
	React: 48,
	TypeScript: 20,
	"Interaction Design": 75,
	"User Research": 85,
	"Content Strategy": 50,
	"Visual Design": 94,
	"Design Leadership": 40,
	"Product Thinking": 36
};
var initialProfile = {
	name: "Sneha Maurya",
	email: "snehamaurya12200@gmail.com",
	education: "B.Tech Computer Science (2021-2025)",
	headline: "Aspiring Frontend Developer & UI Enthusiast",
	avatarInitials: "S",
	location: "Bengaluru, India",
	bio: "Passionate about building responsive, accessible web interfaces and learning modern frontend frameworks.",
	github: "https://github.com/sneha-maurya",
	portfolio: "https://sneha-dev.portfolio",
	educationLevel: "Undergraduate",
	stream: "Computer Science & IT"
};
var initialSettings = {
	account: {
		fullName: "Sneha Maurya",
		email: "snehamaurya12200@gmail.com",
		phone: "+91 98765 43210"
	},
	appearance: "light",
	notifications: {
		learningReminders: true,
		interviewReminders: true,
		applicationUpdates: true,
		courseAnnouncements: true,
		weeklyDigest: false
	},
	aiPreferences: {
		autoSpeak: false,
		textOnly: false,
		voiceInputEnabled: true,
		voiceName: "Kore"
	},
	privacy: {
		shareProfileWithAI: true,
		saveChatHistory: true,
		analytics: false
	}
};
var initialSubscription = {
	plan: "free",
	interval: "monthly",
	activeUntil: "2026-11-30T00:00:00Z",
	isTrial: false,
	startedAt: "2026-10-01T00:00:00Z"
};
var initialNotifications = [
	{
		id: "notif-1",
		title: "Lesson Reminder",
		message: "Next lesson 'Component State Management' is ready in React Pro.",
		type: "lesson",
		at: "10m ago",
		read: false,
		link: "/learning"
	},
	{
		id: "notif-2",
		title: "Job Application Update",
		message: "FinTech Labs moved your Junior Frontend application to Shortlisted!",
		type: "job",
		at: "2h ago",
		read: false,
		link: "/jobs"
	},
	{
		id: "notif-3",
		title: "Mock Interview Ready",
		message: "Frontend Developer (Medium difficulty) is unlocked and waiting for you.",
		type: "interview",
		at: "Yesterday",
		read: true,
		link: "/"
	},
	{
		id: "notif-4",
		title: "AI Skill Insight",
		message: "Your TypeScript score improved! Try taking the Advanced React assessment next.",
		type: "roadmap",
		at: "2d ago",
		read: true,
		link: "/skills"
	}
];
var initialState = {
	goal: "Frontend Developer",
	skills: DEFAULT_SKILLS,
	applications: [],
	savedJobs: [],
	enrolled: { "react-pro": 35 },
	learningList: [],
	lessonsDone: 46,
	hours: 127,
	tests: [],
	interviews: [],
	detailedInterviews: [],
	connections: {},
	events: [],
	groups: [],
	chat: [{
		me: false,
		t: "Hi Sneha! Want me to review your CV and suggest your next best step?"
	}, {
		me: true,
		t: "Yes, I want to become a frontend developer."
	}],
	profile: initialProfile,
	settings: initialSettings,
	subscription: initialSubscription,
	notifications: initialNotifications,
	supportTickets: [],
	careerDNAHistory: [],
	activeQuestProgress: null
};
var KEY = "pathfinder-state-v1";
var state = initialState;
var hydrated = false;
var listeners = /* @__PURE__ */ new Set();
function hydrate() {
	if (hydrated || typeof window === "undefined") return;
	hydrated = true;
	try {
		const raw = localStorage.getItem(KEY);
		if (raw) {
			const parsed = JSON.parse(raw);
			state = {
				...initialState,
				...parsed,
				profile: {
					...initialProfile,
					...parsed.profile || {}
				},
				settings: {
					...initialSettings,
					...parsed.settings || {},
					account: {
						...initialSettings.account,
						...parsed.settings?.account || {}
					},
					notifications: {
						...initialSettings.notifications,
						...parsed.settings?.notifications || {}
					},
					aiPreferences: {
						...initialSettings.aiPreferences,
						...parsed.settings?.aiPreferences || {}
					},
					privacy: {
						...initialSettings.privacy,
						...parsed.settings?.privacy || {}
					}
				},
				subscription: {
					...initialSubscription,
					...parsed.subscription || {}
				},
				notifications: parsed.notifications ?? initialNotifications,
				supportTickets: parsed.supportTickets ?? [],
				careerDNA: parsed.careerDNA,
				careerDNAHistory: parsed.careerDNAHistory ?? [],
				activeQuestProgress: parsed.activeQuestProgress ?? null
			};
		}
	} catch {}
}
function setState(fn) {
	hydrate();
	state = {
		...state,
		...fn(state)
	};
	try {
		if (typeof window !== "undefined") localStorage.setItem(KEY, JSON.stringify(state));
	} catch {}
	listeners.forEach((l) => l());
}
function subscribe(l) {
	listeners.add(l);
	if (!hydrated) {
		hydrate();
		queueMicrotask(l);
	}
	return () => listeners.delete(l);
}
function usePathfinder(sel) {
	return (0, import_react.useSyncExternalStore)(subscribe, () => sel(state), () => sel(initialState));
}
var clamp = (n) => Math.max(0, Math.min(100, Math.round(n)));
var now = () => (/* @__PURE__ */ new Date()).toISOString();
var actions = {
	setGoal: (goal) => setState(() => ({ goal })),
	setSkill: (name, v) => setState((s) => ({ skills: {
		...s.skills,
		[name]: clamp(v)
	} })),
	removeSkill: (name) => setState((s) => {
		const k = { ...s.skills };
		delete k[name];
		return { skills: k };
	}),
	boostSkills: (names, by) => setState((s) => {
		const k = { ...s.skills };
		names.forEach((n) => {
			k[n] = clamp((k[n] ?? 0) + by);
		});
		return { skills: k };
	}),
	toggleSave: (id) => setState((s) => ({ savedJobs: s.savedJobs.includes(id) ? s.savedJobs.filter((x) => x !== id) : [...s.savedJobs, id] })),
	apply: (jobId, note) => setState((s) => s.applications.some((a) => a.jobId === jobId) ? {} : { applications: [...s.applications, {
		jobId,
		status: "Applied",
		appliedAt: now(),
		note,
		history: [{
			status: "Applied",
			at: now()
		}]
	}] }),
	updateApplication: (jobId, patch) => setState((s) => ({ applications: s.applications.map((a) => {
		if (a.jobId !== jobId) return a;
		const history = patch.status && patch.status !== a.status ? [...a.history, {
			status: patch.status,
			at: now()
		}] : a.history;
		return {
			...a,
			...patch,
			history
		};
	}) })),
	withdraw: (jobId) => setState((s) => ({ applications: s.applications.filter((a) => a.jobId !== jobId) })),
	enroll: (id) => setState((s) => s.enrolled[id] !== void 0 ? {} : {
		enrolled: {
			...s.enrolled,
			[id]: 0
		},
		learningList: s.learningList.filter((x) => x !== id)
	}),
	addToList: (id) => setState((s) => s.learningList.includes(id) || s.enrolled[id] !== void 0 ? {} : { learningList: [...s.learningList, id] }),
	removeFromList: (id) => setState((s) => ({ learningList: s.learningList.filter((x) => x !== id) })),
	progressCourse: (id, by, skills, lessonHours) => setState((s) => {
		const prev = s.enrolled[id] ?? 0;
		if (prev >= 100) return {};
		const next = clamp(prev + by);
		const k = { ...s.skills };
		const gain = next === 100 ? 8 : 2;
		skills.forEach((n) => {
			k[n] = clamp((k[n] ?? 0) + gain);
		});
		return {
			enrolled: {
				...s.enrolled,
				[id]: next
			},
			skills: k,
			lessonsDone: s.lessonsDone + 1,
			hours: s.hours + lessonHours
		};
	}),
	lessonComplete: () => setState((s) => ({
		lessonsDone: s.lessonsDone + 1,
		hours: s.hours + 1
	})),
	recordTest: (r, skills) => setState((s) => {
		const pct = r.score / r.total;
		const k = { ...s.skills };
		skills.forEach((n) => {
			const cur = k[n] ?? 0;
			k[n] = clamp(cur + (pct * 100 - cur) * .3);
		});
		return {
			tests: [{
				...r,
				at: now()
			}, ...s.tests],
			skills: k
		};
	}),
	recordInterview: (r) => setState((s) => ({
		interviews: [{
			...r,
			at: now()
		}, ...s.interviews],
		skills: {
			...s.skills,
			Communication: clamp((s.skills.Communication ?? 0) + (r.score >= 60 ? 6 : 2))
		}
	})),
	connect: (id) => setState((s) => ({ connections: {
		...s.connections,
		[id]: "pending"
	} })),
	acceptConnection: (id) => setState((s) => ({ connections: {
		...s.connections,
		[id]: "connected"
	} })),
	removeConnection: (id) => setState((s) => {
		const c = { ...s.connections };
		delete c[id];
		return { connections: c };
	}),
	toggleEvent: (id) => setState((s) => ({ events: s.events.includes(id) ? s.events.filter((x) => x !== id) : [...s.events, id] })),
	toggleGroup: (g) => setState((s) => ({ groups: s.groups.includes(g) ? s.groups.filter((x) => x !== g) : [...s.groups, g] })),
	setChat: (chat) => setState(() => ({ chat })),
	addChatMessage: (msg) => setState((s) => ({ chat: [...s.chat, msg] })),
	clearChat: () => setState(() => ({ chat: [{
		me: false,
		t: "Hi Sneha! I am your AI Career Advisor. Ask me anything about goals, skills, learning roadmaps, or interview prep!"
	}] })),
	setCvAnalysis: (cvName, analysis) => setState((s) => {
		const mergedSkills = { ...s.skills };
		if (analysis.extractedSkills) Object.entries(analysis.extractedSkills).forEach(([k, v]) => {
			if (typeof v === "number") {
				const cur = mergedSkills[k] ?? 0;
				mergedSkills[k] = clamp(Math.max(cur, v));
			}
		});
		return {
			cvName,
			cvAnalysis: analysis,
			skills: mergedSkills
		};
	}),
	updateSkillMap: (skillsMap) => setState((s) => {
		const k = { ...s.skills };
		Object.entries(skillsMap).forEach(([name, v]) => {
			k[name] = clamp(v);
		});
		return { skills: k };
	}),
	setCustomRoadmap: (roadmap) => setState(() => ({ customRoadmap: roadmap })),
	recordDetailedInterview: (report) => setState((s) => {
		const commGain = report.breakdown.communication >= 65 ? 8 : 4;
		const techSkill = s.goal === "Frontend Developer" ? "Frontend" : s.goal === "UI/UX Designer" ? "Interaction Design" : "Data Structures";
		const techGain = report.breakdown.technical >= 65 ? 8 : 4;
		const k = {
			...s.skills,
			Communication: clamp((s.skills.Communication ?? 0) + commGain),
			[techSkill]: clamp((s.skills[techSkill] ?? 0) + techGain)
		};
		const summaryResult = {
			role: report.role,
			difficulty: report.difficulty,
			score: report.score,
			at: report.at
		};
		return {
			detailedInterviews: [report, ...s.detailedInterviews || []],
			interviews: [summaryResult, ...s.interviews],
			skills: k
		};
	}),
	updateProfile: (patch) => setState((s) => {
		const nextProfile = {
			...s.profile,
			...patch
		};
		if (patch.name && !patch.avatarInitials) nextProfile.avatarInitials = patch.name.trim().charAt(0).toUpperCase() || "S";
		return { profile: nextProfile };
	}),
	updateSettings: (patch) => setState((s) => ({ settings: {
		...s.settings,
		...patch,
		account: {
			...s.settings.account,
			...patch.account || {}
		},
		notifications: {
			...s.settings.notifications,
			...patch.notifications || {}
		},
		aiPreferences: {
			...s.settings.aiPreferences,
			...patch.aiPreferences || {}
		},
		privacy: {
			...s.settings.privacy,
			...patch.privacy || {}
		}
	} })),
	upgradeToPro: (interval = "monthly") => setState((s) => ({
		subscription: {
			plan: "pro",
			interval,
			activeUntil: new Date(Date.now() + 2592e6).toISOString(),
			isTrial: true,
			startedAt: now()
		},
		notifications: [{
			id: `notif-${Date.now()}`,
			title: "Pro Activated!",
			message: "You now have unlimited AI mock interviews and custom roadmaps.",
			type: "system",
			at: "Just now",
			read: false
		}, ...s.notifications]
	})),
	downgradeToFree: () => setState((s) => ({
		subscription: {
			plan: "free",
			interval: "monthly",
			activeUntil: now(),
			isTrial: false,
			startedAt: now()
		},
		notifications: [{
			id: `notif-${Date.now()}`,
			title: "Subscription Updated",
			message: "You are currently on the Pathfinder Free plan.",
			type: "system",
			at: "Just now",
			read: false
		}, ...s.notifications]
	})),
	markNotificationRead: (id) => setState((s) => ({ notifications: s.notifications.map((n) => n.id === id ? {
		...n,
		read: true
	} : n) })),
	markAllNotificationsRead: () => setState((s) => ({ notifications: s.notifications.map((n) => ({
		...n,
		read: true
	})) })),
	clearNotifications: () => setState(() => ({ notifications: [] })),
	addNotification: (item) => setState((s) => ({ notifications: [{
		...item,
		id: `notif-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
		at: "Just now",
		read: false
	}, ...s.notifications] })),
	submitSupportTicket: (ticket) => {
		const id = `TKT-${Math.floor(1e3 + Math.random() * 9e3)}`;
		const newTicket = {
			...ticket,
			id,
			createdAt: now(),
			status: "Received"
		};
		setState((s) => ({
			supportTickets: [newTicket, ...s.supportTickets || []],
			notifications: [{
				id: `notif-${Date.now()}`,
				title: `Ticket Submitted (#${id})`,
				message: `Your inquiry regarding "${ticket.subject}" has been received. Our career team will respond shortly.`,
				type: "system",
				at: "Just now",
				read: false
			}, ...s.notifications]
		}));
		return id;
	},
	saveCareerDNA: (dna) => {
		setState((s) => {
			return {
				careerDNA: dna,
				careerDNAHistory: s.careerDNA ? [s.careerDNA, ...s.careerDNAHistory || []] : s.careerDNAHistory || [],
				activeQuestProgress: null,
				notifications: [{
					id: `notif-${Date.now()}`,
					title: `Career DNA Synthesized: ${dna.archetype.title}`,
					message: `Your discovery report is ready! Top career match: ${dna.careerMatches[0]?.title ?? "Exploration Path"}.`,
					type: "roadmap",
					at: "Just now",
					read: false,
					link: "/quest"
				}, ...s.notifications]
			};
		});
	},
	saveQuestProgress: (progress) => {
		setState(() => ({ activeQuestProgress: progress }));
	},
	clearQuestProgress: () => {
		setState(() => ({ activeQuestProgress: null }));
	},
	adoptCareerGoal: (newGoal) => {
		setState((s) => ({
			goal: newGoal,
			profile: {
				...s.profile,
				headline: `${newGoal} Aspirant`
			},
			notifications: [{
				id: `notif-${Date.now()}`,
				title: `Career Target Updated: ${newGoal}`,
				message: `Your learning path and recommended modules have aligned to ${newGoal}.`,
				type: "roadmap",
				at: "Just now",
				read: false,
				link: "/roadmap"
			}, ...s.notifications]
		}));
	},
	resetAllData: () => {
		if (typeof window !== "undefined") try {
			localStorage.removeItem(KEY);
			localStorage.removeItem("theme-mode");
			localStorage.removeItem("pathfinder_auto_speak");
		} catch {}
		setState(() => ({ ...initialState }));
	}
};
/** Career readiness: average of goal skills, nudged by activity. */
function readiness(s, goalSkills) {
	if (!goalSkills.length) return 0;
	return clamp(goalSkills.reduce((a, n) => a + (s.skills[n] ?? 0), 0) / goalSkills.length);
}
var modes = [
	"light",
	"dark",
	"night"
];
function applyMode(m) {
	if (typeof document === "undefined") return;
	const el = document.documentElement;
	el.classList.toggle("dark", m !== "light");
	el.classList.toggle("night", m === "night");
}
function getSavedMode() {
	if (typeof window === "undefined") return "light";
	const saved = localStorage.getItem("theme-mode");
	if (saved && modes.includes(saved)) return saved;
	return "light";
}
function setSavedMode(m) {
	if (typeof window === "undefined") return;
	localStorage.setItem("theme-mode", m);
	applyMode(m);
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var _jsxFileName$10 = "/app/applet/src/components/ui/popover.tsx";
var Popover = Root2;
var PopoverTrigger = Trigger;
var PopoverContent = import_react.forwardRef(({ className, align = "center", sideOffset = 4, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Portal, { children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Content2, {
	ref,
	align,
	sideOffset,
	className: cn("z-50 w-72 rounded-md border bg-popover p-4 text-popover-foreground shadow-md outline-none data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--radix-popover-content-transform-origin)", className),
	...props
}, void 0, false, {
	fileName: _jsxFileName$10,
	lineNumber: 17,
	columnNumber: 5
}, void 0) }, void 0, false, {
	fileName: _jsxFileName$10,
	lineNumber: 16,
	columnNumber: 3
}, void 0));
PopoverContent.displayName = Content2.displayName;
var _jsxFileName$9 = "/app/applet/src/components/ProfileDropdown.tsx";
function ProfileDropdown({ onOpenEditProfile, onOpenSettings, onOpenUpgrade }) {
	const store = usePathfinder((s) => s);
	const profile = store.profile;
	const isPro = store.subscription.plan === "pro";
	const [open, setOpen] = (0, import_react.useState)(false);
	const handleSignOut = () => {
		setOpen(false);
		toast.info("Signed out of Pathfinder (Demo Session)", { description: "Your local profile and progress remain securely saved on this device." });
	};
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Popover, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(PopoverTrigger, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
				type: "button",
				"aria-label": "User Profile Menu",
				className: "relative grid h-9 w-9 place-items-center rounded-full bg-sun font-bold text-ink transition-transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-ring",
				children: [profile.avatarInitials || "S", isPro && /* @__PURE__ */ (void 0)("span", {
					title: "Pro Member",
					className: "absolute -bottom-0.5 -right-0.5 grid h-3.5 w-3.5 place-items-center rounded-full bg-ink text-[8px] text-sun",
					children: "★"
				}, void 0, false, {
					fileName: _jsxFileName$9,
					lineNumber: 40,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName$9,
				lineNumber: 33,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName$9,
			lineNumber: 32,
			columnNumber: 7
		}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(PopoverContent, {
			align: "end",
			sideOffset: 8,
			className: "w-80 rounded-3xl border-border bg-card p-4 shadow-soft",
			children: [
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "flex items-center gap-3 pb-3 border-b border-border/80",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
						className: "grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-sun font-bold text-ink shadow-sm text-base",
						children: profile.avatarInitials || "S"
					}, void 0, false, {
						fileName: _jsxFileName$9,
						lineNumber: 57,
						columnNumber: 11
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "flex items-center gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
								className: "truncate text-sm font-bold text-foreground",
								children: profile.name
							}, void 0, false, {
								fileName: _jsxFileName$9,
								lineNumber: 62,
								columnNumber: 15
							}, this), isPro && /* @__PURE__ */ (void 0)("span", {
								className: "rounded-full bg-butter px-1.5 py-0.2 text-[9px] font-bold text-foreground",
								children: "PRO"
							}, void 0, false, {
								fileName: _jsxFileName$9,
								lineNumber: 64,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName$9,
							lineNumber: 61,
							columnNumber: 13
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
							className: "truncate text-xs text-muted-foreground",
							children: profile.email
						}, void 0, false, {
							fileName: _jsxFileName$9,
							lineNumber: 69,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName$9,
						lineNumber: 60,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName$9,
					lineNumber: 56,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "my-3 space-y-2 rounded-2xl bg-muted/40 p-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "flex items-center justify-between text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
								className: "text-muted-foreground",
								children: "Target Role"
							}, void 0, false, {
								fileName: _jsxFileName$9,
								lineNumber: 76,
								columnNumber: 13
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
								className: "font-semibold text-foreground",
								children: store.goal
							}, void 0, false, {
								fileName: _jsxFileName$9,
								lineNumber: 77,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName$9,
							lineNumber: 75,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "flex items-center justify-between text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
								className: "text-muted-foreground",
								children: "Education"
							}, void 0, false, {
								fileName: _jsxFileName$9,
								lineNumber: 80,
								columnNumber: 13
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
								className: "truncate max-w-[140px] font-medium text-foreground text-right",
								title: profile.education,
								children: profile.education
							}, void 0, false, {
								fileName: _jsxFileName$9,
								lineNumber: 81,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName$9,
							lineNumber: 79,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "flex items-center justify-between text-xs pt-1 border-t border-border/50",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
								className: "text-muted-foreground",
								children: "Learning Progress"
							}, void 0, false, {
								fileName: _jsxFileName$9,
								lineNumber: 89,
								columnNumber: 13
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
								className: "font-medium text-foreground",
								children: [
									store.lessonsDone,
									" lessons • ",
									store.hours,
									"h"
								]
							}, void 0, true, {
								fileName: _jsxFileName$9,
								lineNumber: 90,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName$9,
							lineNumber: 88,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName$9,
					lineNumber: 74,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "space-y-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
							type: "button",
							onClick: () => {
								setOpen(false);
								onOpenEditProfile();
							},
							className: "flex w-full items-center justify-between rounded-xl px-2.5 py-2 text-xs font-medium text-foreground transition hover:bg-muted",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
								className: "flex items-center gap-2.5",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(User, { className: "h-4 w-4 text-muted-foreground" }, void 0, false, {
									fileName: _jsxFileName$9,
									lineNumber: 107,
									columnNumber: 15
								}, this), "View & Edit Profile"]
							}, void 0, true, {
								fileName: _jsxFileName$9,
								lineNumber: 106,
								columnNumber: 13
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(ChevronRight, { className: "h-3.5 w-3.5 text-muted-foreground" }, void 0, false, {
								fileName: _jsxFileName$9,
								lineNumber: 110,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName$9,
							lineNumber: 98,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
							type: "button",
							onClick: () => {
								setOpen(false);
								onOpenSettings();
							},
							className: "flex w-full items-center justify-between rounded-xl px-2.5 py-2 text-xs font-medium text-foreground transition hover:bg-muted",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
								className: "flex items-center gap-2.5",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Settings, { className: "h-4 w-4 text-muted-foreground" }, void 0, false, {
									fileName: _jsxFileName$9,
									lineNumber: 122,
									columnNumber: 15
								}, this), "Account & Settings"]
							}, void 0, true, {
								fileName: _jsxFileName$9,
								lineNumber: 121,
								columnNumber: 13
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(ChevronRight, { className: "h-3.5 w-3.5 text-muted-foreground" }, void 0, false, {
								fileName: _jsxFileName$9,
								lineNumber: 125,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName$9,
							lineNumber: 113,
							columnNumber: 11
						}, this),
						!isPro ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
							type: "button",
							onClick: () => {
								setOpen(false);
								onOpenUpgrade();
							},
							className: "flex w-full items-center justify-between rounded-xl bg-butter/40 px-2.5 py-2 text-xs font-medium text-foreground transition hover:bg-butter/70",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
								className: "flex items-center gap-2.5 font-semibold",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Crown, { className: "h-4 w-4 text-sun" }, void 0, false, {
									fileName: _jsxFileName$9,
									lineNumber: 138,
									columnNumber: 17
								}, this), "Upgrade to Pro"]
							}, void 0, true, {
								fileName: _jsxFileName$9,
								lineNumber: 137,
								columnNumber: 15
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
								className: "rounded-full bg-ink px-1.5 py-0.5 text-[9px] font-bold text-ink-foreground",
								children: "1 Mo Free"
							}, void 0, false, {
								fileName: _jsxFileName$9,
								lineNumber: 141,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName$9,
							lineNumber: 129,
							columnNumber: 13
						}, this) : /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
							type: "button",
							onClick: () => {
								setOpen(false);
								onOpenUpgrade();
							},
							className: "flex w-full items-center justify-between rounded-xl bg-mint/20 px-2.5 py-2 text-xs font-medium text-foreground transition hover:bg-mint/40",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
								className: "flex items-center gap-2.5 font-semibold",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Crown, { className: "h-4 w-4 text-success" }, void 0, false, {
									fileName: _jsxFileName$9,
									lineNumber: 155,
									columnNumber: 17
								}, this), "Manage Pro Plan"]
							}, void 0, true, {
								fileName: _jsxFileName$9,
								lineNumber: 154,
								columnNumber: 15
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
								className: "text-[10px] text-muted-foreground",
								children: "Active"
							}, void 0, false, {
								fileName: _jsxFileName$9,
								lineNumber: 158,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName$9,
							lineNumber: 146,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "pt-1 border-t border-border/80",
							children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
								type: "button",
								onClick: handleSignOut,
								className: "flex w-full items-center gap-2.5 rounded-xl px-2.5 py-2 text-xs font-medium text-destructive transition hover:bg-destructive/10",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(LogOut, { className: "h-4 w-4" }, void 0, false, {
									fileName: _jsxFileName$9,
									lineNumber: 168,
									columnNumber: 15
								}, this), "Sign Out"]
							}, void 0, true, {
								fileName: _jsxFileName$9,
								lineNumber: 163,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName$9,
							lineNumber: 162,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName$9,
					lineNumber: 97,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName$9,
			lineNumber: 50,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName$9,
		lineNumber: 31,
		columnNumber: 5
	}, this);
}
var _jsxFileName$8 = "/app/applet/src/components/ui/dialog.tsx";
var Dialog = Dialog$1;
var DialogPortal = DialogPortal$1;
var DialogOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogOverlay$1, {
	ref,
	className: cn("fixed inset-0 z-50 bg-black/80  data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props
}, void 0, false, {
	fileName: _jsxFileName$8,
	lineNumber: 21,
	columnNumber: 3
}, void 0));
DialogOverlay.displayName = DialogOverlay$1.displayName;
var DialogContent = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogOverlay, {}, void 0, false, {
	fileName: _jsxFileName$8,
	lineNumber: 37,
	columnNumber: 5
}, void 0), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogContent$1, {
	ref,
	className: cn("fixed left-[50%] top-[50%] z-50 grid w-full max-w-lg translate-x-[-50%] translate-y-[-50%] gap-4 border bg-background p-6 shadow-lg duration-200 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95 sm:rounded-lg", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogClose, {
		className: "absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background cursor-pointer transition-opacity hover:opacity-100 focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:pointer-events-none data-[state=open]:bg-accent data-[state=open]:text-muted-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(X, { className: "h-4 w-4" }, void 0, false, {
			fileName: _jsxFileName$8,
			lineNumber: 48,
			columnNumber: 9
		}, void 0), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
			className: "sr-only",
			children: "Close"
		}, void 0, false, {
			fileName: _jsxFileName$8,
			lineNumber: 49,
			columnNumber: 9
		}, void 0)]
	}, void 0, true, {
		fileName: _jsxFileName$8,
		lineNumber: 47,
		columnNumber: 7
	}, void 0)]
}, void 0, true, {
	fileName: _jsxFileName$8,
	lineNumber: 38,
	columnNumber: 5
}, void 0)] }, void 0, true, {
	fileName: _jsxFileName$8,
	lineNumber: 36,
	columnNumber: 3
}, void 0));
DialogContent.displayName = DialogContent$1.displayName;
var DialogHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
	className: cn("flex flex-col space-y-1.5 text-center sm:text-left", className),
	...props
}, void 0, false, {
	fileName: _jsxFileName$8,
	lineNumber: 57,
	columnNumber: 3
}, void 0);
DialogHeader.displayName = "DialogHeader";
var DialogFooter = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
	className: cn("flex flex-col-reverse sm:flex-row sm:justify-end sm:space-x-2", className),
	...props
}, void 0, false, {
	fileName: _jsxFileName$8,
	lineNumber: 62,
	columnNumber: 3
}, void 0);
DialogFooter.displayName = "DialogFooter";
var DialogTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogTitle$1, {
	ref,
	className: cn("text-lg font-semibold leading-none tracking-tight", className),
	...props
}, void 0, false, {
	fileName: _jsxFileName$8,
	lineNumber: 73,
	columnNumber: 3
}, void 0));
DialogTitle.displayName = DialogTitle$1.displayName;
var DialogDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogDescription$1, {
	ref,
	className: cn("text-sm text-muted-foreground", className),
	...props
}, void 0, false, {
	fileName: _jsxFileName$8,
	lineNumber: 85,
	columnNumber: 3
}, void 0));
DialogDescription.displayName = DialogDescription$1.displayName;
var _jsxFileName$7 = "/app/applet/src/components/ProfileModal.tsx";
var EDUCATION_LEVEL_OPTIONS = [
	"Class 10",
	"Class 11",
	"Class 12",
	"Diploma",
	"Undergraduate",
	"Postgraduate",
	"PhD / Research",
	"Competitive Exams",
	"Working Professional"
];
var STREAM_OPTIONS = [
	"Computer Science & IT",
	"AI & Emerging Tech",
	"Science (PCM)",
	"Science (PCB)",
	"Medical & Healthcare",
	"Commerce & Finance",
	"Management & Business",
	"Law & Civil Services",
	"Arts & Humanities",
	"Design & Creative Arts",
	"Engineering (Core)",
	"Essential & Soft Skills"
];
function ProfileModal({ open, onOpenChange, mode = "edit" }) {
	const store = usePathfinder((s) => s);
	const profile = store.profile;
	const [isEditing, setIsEditing] = (0, import_react.useState)(mode === "edit");
	const [name, setName] = (0, import_react.useState)(profile.name);
	const [email, setEmail] = (0, import_react.useState)(profile.email);
	const [headline, setHeadline] = (0, import_react.useState)(profile.headline);
	const [education, setEducation] = (0, import_react.useState)(profile.education);
	const [educationLevel, setEducationLevel] = (0, import_react.useState)(profile.educationLevel || "Undergraduate");
	const [stream, setStream] = (0, import_react.useState)(profile.stream || "Computer Science & IT");
	const [goal, setGoal] = (0, import_react.useState)(store.goal);
	const [location, setLocation] = (0, import_react.useState)(profile.location || "Bengaluru, India");
	const [bio, setBio] = (0, import_react.useState)(profile.bio || "");
	const [github, setGithub] = (0, import_react.useState)(profile.github || "");
	const [portfolio, setPortfolio] = (0, import_react.useState)(profile.portfolio || "");
	const handleOpen = (isOpen) => {
		if (isOpen) {
			setName(profile.name);
			setEmail(profile.email);
			setHeadline(profile.headline);
			setEducation(profile.education);
			setEducationLevel(profile.educationLevel || "Undergraduate");
			setStream(profile.stream || "Computer Science & IT");
			setGoal(store.goal);
			setLocation(profile.location || "Bengaluru, India");
			setBio(profile.bio || "");
			setGithub(profile.github || "");
			setPortfolio(profile.portfolio || "");
			setIsEditing(mode === "edit");
		}
		onOpenChange(isOpen);
	};
	const handleSave = (e) => {
		e.preventDefault();
		if (!name.trim()) {
			toast.error("Full name cannot be blank");
			return;
		}
		actions.updateProfile({
			name: name.trim(),
			email: email.trim(),
			headline: headline.trim(),
			education: education.trim(),
			educationLevel,
			stream,
			location: location.trim(),
			bio: bio.trim(),
			github: github.trim(),
			portfolio: portfolio.trim()
		});
		if (goal.trim() && goal !== store.goal) actions.setGoal(goal.trim());
		toast.success("Profile updated successfully", { description: "Your personalized AI recommendations, course catalogue, and roadmaps will now use your updated academic profile." });
		onOpenChange(false);
	};
	const topSkills = Object.entries(store.skills).sort((a, b) => b[1] - a[1]).slice(0, 5);
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Dialog, {
		open,
		onOpenChange: handleOpen,
		children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogContent, {
			className: "max-w-2xl max-h-[90vh] overflow-y-auto rounded-3xl border-border bg-card p-6 shadow-soft",
			children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogHeader, {
				className: "text-left",
				children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
							className: "grid h-12 w-12 place-items-center rounded-2xl bg-sun text-lg font-bold text-ink shadow-sm",
							children: profile.avatarInitials || "S"
						}, void 0, false, {
							fileName: _jsxFileName$7,
							lineNumber: 134,
							columnNumber: 15
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogTitle, {
							className: "text-xl font-bold text-foreground",
							children: profile.name
						}, void 0, false, {
							fileName: _jsxFileName$7,
							lineNumber: 138,
							columnNumber: 17
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogDescription, {
							className: "text-xs text-muted-foreground",
							children: profile.headline
						}, void 0, false, {
							fileName: _jsxFileName$7,
							lineNumber: 141,
							columnNumber: 17
						}, this)] }, void 0, true, {
							fileName: _jsxFileName$7,
							lineNumber: 137,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName$7,
						lineNumber: 133,
						columnNumber: 13
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
						type: "button",
						onClick: () => setIsEditing(!isEditing),
						className: "rounded-full border border-border bg-muted/60 px-3 py-1.5 text-xs font-semibold text-foreground transition hover:bg-muted",
						children: isEditing ? "Preview Profile" : "Edit Profile"
					}, void 0, false, {
						fileName: _jsxFileName$7,
						lineNumber: 147,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName$7,
					lineNumber: 132,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName$7,
				lineNumber: 131,
				columnNumber: 9
			}, this), isEditing ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("form", {
				onSubmit: handleSave,
				className: "space-y-4 pt-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "grid grid-cols-1 gap-4 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("label", {
								className: "text-xs font-semibold text-foreground",
								children: "Full Name"
							}, void 0, false, {
								fileName: _jsxFileName$7,
								lineNumber: 161,
								columnNumber: 17
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(User, { className: "absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" }, void 0, false, {
									fileName: _jsxFileName$7,
									lineNumber: 163,
									columnNumber: 19
								}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("input", {
									type: "text",
									value: name,
									onChange: (e) => setName(e.target.value),
									required: true,
									className: "w-full rounded-xl border border-input bg-background py-2 pl-9 pr-3 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring",
									placeholder: "e.g. Sneha Maurya"
								}, void 0, false, {
									fileName: _jsxFileName$7,
									lineNumber: 164,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName$7,
								lineNumber: 162,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName$7,
							lineNumber: 160,
							columnNumber: 15
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("label", {
								className: "text-xs font-semibold text-foreground",
								children: "Email Address"
							}, void 0, false, {
								fileName: _jsxFileName$7,
								lineNumber: 176,
								columnNumber: 17
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Mail, { className: "absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" }, void 0, false, {
									fileName: _jsxFileName$7,
									lineNumber: 178,
									columnNumber: 19
								}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("input", {
									type: "email",
									value: email,
									onChange: (e) => setEmail(e.target.value),
									required: true,
									className: "w-full rounded-xl border border-input bg-background py-2 pl-9 pr-3 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring",
									placeholder: "e.g. sneha@example.com"
								}, void 0, false, {
									fileName: _jsxFileName$7,
									lineNumber: 179,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName$7,
								lineNumber: 177,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName$7,
							lineNumber: 175,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName$7,
						lineNumber: 159,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "grid grid-cols-1 gap-4 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("label", {
								className: "text-xs font-semibold text-foreground",
								children: "Primary Career Goal"
							}, void 0, false, {
								fileName: _jsxFileName$7,
								lineNumber: 193,
								columnNumber: 17
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Briefcase, { className: "absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" }, void 0, false, {
									fileName: _jsxFileName$7,
									lineNumber: 195,
									columnNumber: 19
								}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("select", {
									value: goal,
									onChange: (e) => setGoal(e.target.value),
									className: "w-full rounded-xl border border-input bg-background py-2 pl-9 pr-3 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring",
									children: [
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", {
											value: "Frontend Developer",
											children: "Frontend Developer"
										}, void 0, false, {
											fileName: _jsxFileName$7,
											lineNumber: 201,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", {
											value: "UI/UX Designer",
											children: "UI/UX Designer"
										}, void 0, false, {
											fileName: _jsxFileName$7,
											lineNumber: 202,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", {
											value: "Full Stack Engineer",
											children: "Full Stack Engineer"
										}, void 0, false, {
											fileName: _jsxFileName$7,
											lineNumber: 203,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", {
											value: "Data Analyst",
											children: "Data Analyst"
										}, void 0, false, {
											fileName: _jsxFileName$7,
											lineNumber: 204,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", {
											value: "AI / Machine Learning Specialist",
											children: "AI / Machine Learning Specialist"
										}, void 0, false, {
											fileName: _jsxFileName$7,
											lineNumber: 205,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", {
											value: "Medical & Healthcare Aspirant",
											children: "Medical & Healthcare Aspirant"
										}, void 0, false, {
											fileName: _jsxFileName$7,
											lineNumber: 208,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", {
											value: "Secondary School Student (Class 10-12)",
											children: "Secondary School Student (Class 10-12)"
										}, void 0, false, {
											fileName: _jsxFileName$7,
											lineNumber: 211,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", {
											value: "Chartered Accountant / Finance Specialist",
											children: "Chartered Accountant / Finance Specialist"
										}, void 0, false, {
											fileName: _jsxFileName$7,
											lineNumber: 214,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", {
											value: "Civil Services / UPSC Aspirant",
											children: "Civil Services / UPSC Aspirant"
										}, void 0, false, {
											fileName: _jsxFileName$7,
											lineNumber: 217,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", {
											value: "Legal Specialist / Corporate Lawyer",
											children: "Legal Specialist / Corporate Lawyer"
										}, void 0, false, {
											fileName: _jsxFileName$7,
											lineNumber: 220,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", {
											value: "Academic Researcher",
											children: "Academic Researcher"
										}, void 0, false, {
											fileName: _jsxFileName$7,
											lineNumber: 223,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", {
											value: "Business & Marketing Specialist",
											children: "Business & Marketing Specialist"
										}, void 0, false, {
											fileName: _jsxFileName$7,
											lineNumber: 224,
											columnNumber: 21
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName$7,
									lineNumber: 196,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName$7,
								lineNumber: 194,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName$7,
							lineNumber: 192,
							columnNumber: 15
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("label", {
								className: "text-xs font-semibold text-foreground",
								children: "Location"
							}, void 0, false, {
								fileName: _jsxFileName$7,
								lineNumber: 232,
								columnNumber: 17
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(MapPin, { className: "absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" }, void 0, false, {
									fileName: _jsxFileName$7,
									lineNumber: 234,
									columnNumber: 19
								}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("input", {
									type: "text",
									value: location,
									onChange: (e) => setLocation(e.target.value),
									className: "w-full rounded-xl border border-input bg-background py-2 pl-9 pr-3 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring",
									placeholder: "e.g. Bengaluru, India"
								}, void 0, false, {
									fileName: _jsxFileName$7,
									lineNumber: 235,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName$7,
								lineNumber: 233,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName$7,
							lineNumber: 231,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName$7,
						lineNumber: 191,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "grid grid-cols-1 gap-4 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("label", {
								className: "text-xs font-semibold text-foreground",
								children: "Education Level"
							}, void 0, false, {
								fileName: _jsxFileName$7,
								lineNumber: 248,
								columnNumber: 17
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("select", {
								value: educationLevel,
								onChange: (e) => setEducationLevel(e.target.value),
								className: "w-full rounded-xl border border-input bg-background py-2 px-3 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring",
								children: EDUCATION_LEVEL_OPTIONS.map((lvl) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", {
									value: lvl,
									children: lvl
								}, lvl, false, {
									fileName: _jsxFileName$7,
									lineNumber: 255,
									columnNumber: 21
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName$7,
								lineNumber: 249,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName$7,
							lineNumber: 247,
							columnNumber: 15
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("label", {
								className: "text-xs font-semibold text-foreground",
								children: "Academic Stream"
							}, void 0, false, {
								fileName: _jsxFileName$7,
								lineNumber: 263,
								columnNumber: 17
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("select", {
								value: stream,
								onChange: (e) => setStream(e.target.value),
								className: "w-full rounded-xl border border-input bg-background py-2 px-3 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring",
								children: STREAM_OPTIONS.map((s) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", {
									value: s,
									children: s
								}, s, false, {
									fileName: _jsxFileName$7,
									lineNumber: 270,
									columnNumber: 21
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName$7,
								lineNumber: 264,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName$7,
							lineNumber: 262,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName$7,
						lineNumber: 246,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("label", {
							className: "text-xs font-semibold text-foreground",
							children: "Professional Headline"
						}, void 0, false, {
							fileName: _jsxFileName$7,
							lineNumber: 279,
							columnNumber: 15
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("input", {
							type: "text",
							value: headline,
							onChange: (e) => setHeadline(e.target.value),
							className: "w-full rounded-xl border border-input bg-background py-2 px-3 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring",
							placeholder: "e.g. Aspiring Frontend Developer & UI Enthusiast"
						}, void 0, false, {
							fileName: _jsxFileName$7,
							lineNumber: 280,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName$7,
						lineNumber: 278,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("label", {
							className: "text-xs font-semibold text-foreground",
							children: "Institution / Degree Details"
						}, void 0, false, {
							fileName: _jsxFileName$7,
							lineNumber: 290,
							columnNumber: 15
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(GraduationCap, { className: "absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" }, void 0, false, {
								fileName: _jsxFileName$7,
								lineNumber: 294,
								columnNumber: 17
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("input", {
								type: "text",
								value: education,
								onChange: (e) => setEducation(e.target.value),
								className: "w-full rounded-xl border border-input bg-background py-2 pl-9 pr-3 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring",
								placeholder: "e.g. B.Tech Computer Science (2021-2025)"
							}, void 0, false, {
								fileName: _jsxFileName$7,
								lineNumber: 295,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName$7,
							lineNumber: 293,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName$7,
						lineNumber: 289,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("label", {
							className: "text-xs font-semibold text-foreground",
							children: "Short Bio / Career Summary"
						}, void 0, false, {
							fileName: _jsxFileName$7,
							lineNumber: 306,
							columnNumber: 15
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("textarea", {
							value: bio,
							onChange: (e) => setBio(e.target.value),
							rows: 3,
							className: "w-full rounded-xl border border-input bg-background p-3 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring",
							placeholder: "Briefly describe your interests, learning journey, and target opportunities..."
						}, void 0, false, {
							fileName: _jsxFileName$7,
							lineNumber: 309,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName$7,
						lineNumber: 305,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "grid grid-cols-1 gap-4 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("label", {
								className: "text-xs font-semibold text-foreground",
								children: "GitHub Profile"
							}, void 0, false, {
								fileName: _jsxFileName$7,
								lineNumber: 320,
								columnNumber: 17
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Github, { className: "absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" }, void 0, false, {
									fileName: _jsxFileName$7,
									lineNumber: 322,
									columnNumber: 19
								}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("input", {
									type: "url",
									value: github,
									onChange: (e) => setGithub(e.target.value),
									className: "w-full rounded-xl border border-input bg-background py-2 pl-9 pr-3 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring",
									placeholder: "https://github.com/..."
								}, void 0, false, {
									fileName: _jsxFileName$7,
									lineNumber: 323,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName$7,
								lineNumber: 321,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName$7,
							lineNumber: 319,
							columnNumber: 15
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("label", {
								className: "text-xs font-semibold text-foreground",
								children: "Portfolio Website"
							}, void 0, false, {
								fileName: _jsxFileName$7,
								lineNumber: 334,
								columnNumber: 17
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "relative",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Globe, { className: "absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" }, void 0, false, {
									fileName: _jsxFileName$7,
									lineNumber: 336,
									columnNumber: 19
								}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("input", {
									type: "url",
									value: portfolio,
									onChange: (e) => setPortfolio(e.target.value),
									className: "w-full rounded-xl border border-input bg-background py-2 pl-9 pr-3 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring",
									placeholder: "https://yourportfolio.dev"
								}, void 0, false, {
									fileName: _jsxFileName$7,
									lineNumber: 337,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName$7,
								lineNumber: 335,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName$7,
							lineNumber: 333,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName$7,
						lineNumber: 318,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogFooter, {
						className: "pt-3",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
							type: "button",
							onClick: () => onOpenChange(false),
							className: "rounded-full border border-border px-4 py-2 text-xs font-semibold text-muted-foreground hover:bg-muted",
							children: "Cancel"
						}, void 0, false, {
							fileName: _jsxFileName$7,
							lineNumber: 349,
							columnNumber: 15
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
							type: "submit",
							className: "rounded-full bg-ink px-5 py-2 text-xs font-semibold text-ink-foreground transition hover:opacity-90",
							children: "Save Changes"
						}, void 0, false, {
							fileName: _jsxFileName$7,
							lineNumber: 356,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName$7,
						lineNumber: 348,
						columnNumber: 13
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName$7,
				lineNumber: 158,
				columnNumber: 11
			}, this) : /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "space-y-5 pt-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "grid grid-cols-2 gap-3 sm:grid-cols-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "rounded-2xl bg-lilac/30 p-3 text-center",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
									className: "text-[11px] font-medium text-muted-foreground",
									children: "Target Role"
								}, void 0, false, {
									fileName: _jsxFileName$7,
									lineNumber: 368,
									columnNumber: 17
								}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
									className: "mt-0.5 text-xs font-bold text-foreground",
									children: store.goal
								}, void 0, false, {
									fileName: _jsxFileName$7,
									lineNumber: 369,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName$7,
								lineNumber: 367,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "rounded-2xl bg-mint/30 p-3 text-center",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
									className: "text-[11px] font-medium text-muted-foreground",
									children: "Lessons Done"
								}, void 0, false, {
									fileName: _jsxFileName$7,
									lineNumber: 372,
									columnNumber: 17
								}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
									className: "mt-0.5 text-xs font-bold text-foreground",
									children: store.lessonsDone
								}, void 0, false, {
									fileName: _jsxFileName$7,
									lineNumber: 373,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName$7,
								lineNumber: 371,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "rounded-2xl bg-sun/30 p-3 text-center",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
									className: "text-[11px] font-medium text-muted-foreground",
									children: "Study Hours"
								}, void 0, false, {
									fileName: _jsxFileName$7,
									lineNumber: 376,
									columnNumber: 17
								}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
									className: "mt-0.5 text-xs font-bold text-foreground",
									children: [store.hours, " hrs"]
								}, void 0, true, {
									fileName: _jsxFileName$7,
									lineNumber: 377,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName$7,
								lineNumber: 375,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "rounded-2xl bg-butter/50 p-3 text-center",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
									className: "text-[11px] font-medium text-muted-foreground",
									children: "Plan Status"
								}, void 0, false, {
									fileName: _jsxFileName$7,
									lineNumber: 380,
									columnNumber: 17
								}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
									className: "mt-0.5 text-xs font-bold text-foreground capitalize",
									children: store.subscription.plan === "pro" ? "Pro Member" : "Free Tier"
								}, void 0, false, {
									fileName: _jsxFileName$7,
									lineNumber: 381,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName$7,
								lineNumber: 379,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName$7,
						lineNumber: 366,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "rounded-2xl border border-border/80 bg-background/50 p-4 space-y-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h4", {
								className: "text-xs font-semibold text-foreground",
								children: "About & Background"
							}, void 0, false, {
								fileName: _jsxFileName$7,
								lineNumber: 388,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
								className: "text-xs leading-relaxed text-muted-foreground",
								children: profile.bio || "No summary provided yet. Click 'Edit Profile' to add your bio."
							}, void 0, false, {
								fileName: _jsxFileName$7,
								lineNumber: 389,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "flex flex-wrap items-center gap-3 pt-2 text-xs text-muted-foreground",
								children: [
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
										className: "flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(GraduationCap, { className: "h-3.5 w-3.5 text-violet" }, void 0, false, {
											fileName: _jsxFileName$7,
											lineNumber: 394,
											columnNumber: 19
										}, this), profile.education]
									}, void 0, true, {
										fileName: _jsxFileName$7,
										lineNumber: 393,
										columnNumber: 17
									}, this),
									profile.educationLevel && /* @__PURE__ */ (void 0)("span", {
										className: "rounded-full bg-lilac/50 px-2.5 py-0.5 text-[11px] font-semibold text-violet",
										children: profile.educationLevel
									}, void 0, false, {
										fileName: _jsxFileName$7,
										lineNumber: 398,
										columnNumber: 19
									}, this),
									profile.stream && /* @__PURE__ */ (void 0)("span", {
										className: "rounded-full bg-mint/50 px-2.5 py-0.5 text-[11px] font-semibold text-primary-foreground",
										children: profile.stream
									}, void 0, false, {
										fileName: _jsxFileName$7,
										lineNumber: 403,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
										className: "flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(MapPin, { className: "h-3.5 w-3.5 text-sun" }, void 0, false, {
											fileName: _jsxFileName$7,
											lineNumber: 408,
											columnNumber: 19
										}, this), profile.location || "Bengaluru, India"]
									}, void 0, true, {
										fileName: _jsxFileName$7,
										lineNumber: 407,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName$7,
								lineNumber: 392,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName$7,
						lineNumber: 387,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h4", {
								className: "text-xs font-semibold text-foreground",
								children: "Top Evaluated Skills"
							}, void 0, false, {
								fileName: _jsxFileName$7,
								lineNumber: 416,
								columnNumber: 17
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
								className: "text-[11px] text-muted-foreground",
								children: "Based on assessments & CV"
							}, void 0, false, {
								fileName: _jsxFileName$7,
								lineNumber: 417,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName$7,
							lineNumber: 415,
							columnNumber: 15
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "grid grid-cols-1 gap-2 sm:grid-cols-2",
							children: topSkills.map(([skill, val]) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "rounded-xl border border-border/70 bg-card p-2.5",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: "flex items-center justify-between text-xs",
									children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
										className: "font-medium text-foreground",
										children: skill
									}, void 0, false, {
										fileName: _jsxFileName$7,
										lineNumber: 423,
										columnNumber: 23
									}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
										className: "font-bold text-foreground",
										children: [val, "%"]
									}, void 0, true, {
										fileName: _jsxFileName$7,
										lineNumber: 424,
										columnNumber: 23
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName$7,
									lineNumber: 422,
									columnNumber: 21
								}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: "mt-1.5 h-1.5 w-full overflow-hidden rounded-full bg-muted",
									children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "h-full rounded-full bg-ink transition-all",
										style: { width: `${val}%` }
									}, void 0, false, {
										fileName: _jsxFileName$7,
										lineNumber: 427,
										columnNumber: 23
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName$7,
									lineNumber: 426,
									columnNumber: 21
								}, this)]
							}, skill, true, {
								fileName: _jsxFileName$7,
								lineNumber: 421,
								columnNumber: 19
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName$7,
							lineNumber: 419,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName$7,
						lineNumber: 414,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "rounded-2xl bg-muted/40 p-3.5 flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "flex items-center gap-2 text-xs text-muted-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Sparkles, { className: "h-4 w-4 text-violet shrink-0" }, void 0, false, {
								fileName: _jsxFileName$7,
								lineNumber: 439,
								columnNumber: 17
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: "Connected to Gemini AI Career Intelligence Engine" }, void 0, false, {
								fileName: _jsxFileName$7,
								lineNumber: 440,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName$7,
							lineNumber: 438,
							columnNumber: 15
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
							className: "inline-flex items-center gap-1 text-[11px] font-semibold text-success",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Check, { className: "h-3 w-3" }, void 0, false, {
								fileName: _jsxFileName$7,
								lineNumber: 443,
								columnNumber: 17
							}, this), " Live Context Sync"]
						}, void 0, true, {
							fileName: _jsxFileName$7,
							lineNumber: 442,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName$7,
						lineNumber: 437,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogFooter, { children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
						type: "button",
						onClick: () => setIsEditing(true),
						className: "w-full sm:w-auto rounded-full bg-ink px-5 py-2 text-xs font-semibold text-ink-foreground transition hover:opacity-90",
						children: "Edit Profile Details"
					}, void 0, false, {
						fileName: _jsxFileName$7,
						lineNumber: 448,
						columnNumber: 15
					}, this) }, void 0, false, {
						fileName: _jsxFileName$7,
						lineNumber: 447,
						columnNumber: 13
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName$7,
				lineNumber: 365,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName$7,
			lineNumber: 130,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName$7,
		lineNumber: 129,
		columnNumber: 5
	}, this);
}
var _jsxFileName$6 = "/app/applet/src/components/ui/tabs.tsx";
var Tabs = Root2$1;
var TabsList = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(List, {
	ref,
	className: cn("inline-flex h-9 items-center justify-center rounded-lg bg-muted p-1 text-muted-foreground", className),
	...props
}, void 0, false, {
	fileName: _jsxFileName$6,
	lineNumber: 12,
	columnNumber: 3
}, void 0));
TabsList.displayName = List.displayName;
var TabsTrigger = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Trigger$1, {
	ref,
	className: cn("inline-flex items-center justify-center whitespace-nowrap rounded-md px-3 py-1 text-sm font-medium ring-offset-background cursor-pointer transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 disabled:cursor-not-allowed data-[state=active]:bg-background data-[state=active]:text-foreground data-[state=active]:shadow", className),
	...props
}, void 0, false, {
	fileName: _jsxFileName$6,
	lineNumber: 27,
	columnNumber: 3
}, void 0));
TabsTrigger.displayName = Trigger$1.displayName;
var TabsContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Content, {
	ref,
	className: cn("mt-2 ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2", className),
	...props
}, void 0, false, {
	fileName: _jsxFileName$6,
	lineNumber: 42,
	columnNumber: 3
}, void 0));
TabsContent.displayName = Content.displayName;
var _jsxFileName$5 = "/app/applet/src/components/ui/switch.tsx";
var Switch = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Switch$1, {
	className: cn("peer inline-flex h-5 w-9 shrink-0 cursor-pointer items-center rounded-full border-2 border-transparent shadow-sm transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:bg-primary data-[state=unchecked]:bg-input", className),
	...props,
	ref,
	children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(SwitchThumb, { className: cn("pointer-events-none block h-4 w-4 rounded-full bg-background shadow-lg ring-0 transition-transform data-[state=checked]:translate-x-4 data-[state=unchecked]:translate-x-0") }, void 0, false, {
		fileName: _jsxFileName$5,
		lineNumber: 18,
		columnNumber: 5
	}, void 0)
}, void 0, false, {
	fileName: _jsxFileName$5,
	lineNumber: 10,
	columnNumber: 3
}, void 0));
Switch.displayName = Switch$1.displayName;
var _jsxFileName$4 = "/app/applet/src/components/SettingsModal.tsx";
function SettingsModal({ open, onOpenChange, defaultTab = "account" }) {
	const store = usePathfinder((s) => s);
	const settings = store.settings;
	const profile = store.profile;
	const [activeTab, setActiveTab] = (0, import_react.useState)(defaultTab);
	const [fullName, setFullName] = (0, import_react.useState)(profile.name);
	const [email, setEmail] = (0, import_react.useState)(profile.email);
	const [phone, setPhone] = (0, import_react.useState)(settings.account?.phone || "+91 98765 43210");
	const [currentPassword, setCurrentPassword] = (0, import_react.useState)("");
	const [newPassword, setNewPassword] = (0, import_react.useState)("");
	const [confirmPassword, setConfirmPassword] = (0, import_react.useState)("");
	const [pwUpdated, setPwUpdated] = (0, import_react.useState)(false);
	const [currentTheme, setCurrentTheme] = (0, import_react.useState)("light");
	const [learningReminders, setLearningReminders] = (0, import_react.useState)(settings.notifications.learningReminders);
	const [interviewReminders, setInterviewReminders] = (0, import_react.useState)(settings.notifications.interviewReminders);
	const [applicationUpdates, setApplicationUpdates] = (0, import_react.useState)(settings.notifications.applicationUpdates);
	const [courseAnnouncements, setCourseAnnouncements] = (0, import_react.useState)(settings.notifications.courseAnnouncements);
	const [weeklyDigest, setWeeklyDigest] = (0, import_react.useState)(settings.notifications.weeklyDigest);
	const [autoSpeak, setAutoSpeak] = (0, import_react.useState)(settings.aiPreferences.autoSpeak);
	const [textOnly, setTextOnly] = (0, import_react.useState)(settings.aiPreferences.textOnly);
	const [voiceInputEnabled, setVoiceInputEnabled] = (0, import_react.useState)(settings.aiPreferences.voiceInputEnabled);
	const [voiceName, setVoiceName] = (0, import_react.useState)(settings.aiPreferences.voiceName || "Kore");
	const [shareProfileWithAI, setShareProfileWithAI] = (0, import_react.useState)(settings.privacy.shareProfileWithAI);
	const [saveChatHistory, setSaveChatHistory] = (0, import_react.useState)(settings.privacy.saveChatHistory);
	const [analytics, setAnalytics] = (0, import_react.useState)(settings.privacy.analytics);
	const [showResetConfirm, setShowResetConfirm] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (open) {
			setFullName(profile.name);
			setEmail(profile.email);
			setPhone(settings.account?.phone || "+91 98765 43210");
			setCurrentTheme(getSavedMode());
			setLearningReminders(settings.notifications.learningReminders);
			setInterviewReminders(settings.notifications.interviewReminders);
			setApplicationUpdates(settings.notifications.applicationUpdates);
			setCourseAnnouncements(settings.notifications.courseAnnouncements);
			setWeeklyDigest(settings.notifications.weeklyDigest);
			setAutoSpeak(settings.aiPreferences.autoSpeak);
			setTextOnly(settings.aiPreferences.textOnly);
			setVoiceInputEnabled(settings.aiPreferences.voiceInputEnabled);
			setVoiceName(settings.aiPreferences.voiceName || "Kore");
			setShareProfileWithAI(settings.privacy.shareProfileWithAI);
			setSaveChatHistory(settings.privacy.saveChatHistory);
			setAnalytics(settings.privacy.analytics);
			setPwUpdated(false);
			setShowResetConfirm(false);
			if (defaultTab) setActiveTab(defaultTab);
		}
	}, [
		open,
		settings,
		profile,
		defaultTab
	]);
	const handleSaveAccount = (e) => {
		e.preventDefault();
		if (!fullName.trim()) {
			toast.error("Name cannot be empty");
			return;
		}
		actions.updateProfile({
			name: fullName.trim(),
			email: email.trim()
		});
		actions.updateSettings({ account: {
			fullName: fullName.trim(),
			email: email.trim(),
			phone: phone.trim()
		} });
		toast.success("Account details saved successfully");
	};
	const handleUpdatePassword = (e) => {
		e.preventDefault();
		if (!currentPassword) {
			toast.error("Please enter your current password");
			return;
		}
		if (newPassword.length < 6) {
			toast.error("New password must be at least 6 characters");
			return;
		}
		if (newPassword !== confirmPassword) {
			toast.error("New passwords do not match");
			return;
		}
		setCurrentPassword("");
		setNewPassword("");
		setConfirmPassword("");
		setPwUpdated(true);
		toast.success("Password changed successfully", { description: "Your login credentials have been securely updated." });
		setTimeout(() => setPwUpdated(false), 4e3);
	};
	const handleThemeChange = (mode) => {
		setCurrentTheme(mode);
		setSavedMode(mode);
		actions.updateSettings({ appearance: mode });
		toast.info(`${mode.charAt(0).toUpperCase() + mode.slice(1)} mode active`);
	};
	const handleToggleAutoSpeak = (checked) => {
		setAutoSpeak(checked);
		if (typeof window !== "undefined") localStorage.setItem("pathfinder_auto_speak", String(checked));
		actions.updateSettings({ aiPreferences: {
			...settings.aiPreferences,
			autoSpeak: checked,
			textOnly: !checked && textOnly
		} });
		toast(checked ? "Voice spoken responses enabled" : "Spoken responses disabled (Text-only mode)");
	};
	const handleToggleTextOnly = (checked) => {
		setTextOnly(checked);
		if (checked) {
			setAutoSpeak(false);
			if (typeof window !== "undefined") localStorage.setItem("pathfinder_auto_speak", "false");
		}
		actions.updateSettings({ aiPreferences: {
			...settings.aiPreferences,
			textOnly: checked,
			autoSpeak: checked ? false : autoSpeak
		} });
		toast(checked ? "Text-only response mode active" : "Multimedia response mode active");
	};
	const handleClearHistory = () => {
		actions.clearChat();
		toast.success("AI Conversation history cleared", { description: "The assistant has reset its chat memory to default greeting." });
	};
	const handleFullReset = () => {
		actions.resetAllData();
		setShowResetConfirm(false);
		onOpenChange(false);
		toast.success("Pathfinder reset to initial state", { description: "Default mock data and goals have been re-seeded." });
	};
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogContent, {
			className: "max-w-2xl max-h-[90vh] overflow-y-auto rounded-3xl border-border bg-card p-6 shadow-soft",
			children: [
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogHeader, {
					className: "text-left",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogTitle, {
						className: "text-xl font-bold text-foreground",
						children: "Settings"
					}, void 0, false, {
						fileName: _jsxFileName$4,
						lineNumber: 220,
						columnNumber: 11
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogDescription, {
						className: "text-xs text-muted-foreground",
						children: "Manage your account preferences, appearance, AI behaviors, and notification channels."
					}, void 0, false, {
						fileName: _jsxFileName$4,
						lineNumber: 221,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName$4,
					lineNumber: 219,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Tabs, {
					value: activeTab,
					onValueChange: setActiveTab,
					className: "w-full pt-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(TabsList, {
							className: "grid w-full grid-cols-5 rounded-2xl bg-muted/60 p-1 text-xs",
							children: [
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(TabsTrigger, {
									value: "account",
									className: "rounded-xl py-1.5 text-xs font-semibold",
									children: "Account"
								}, void 0, false, {
									fileName: _jsxFileName$4,
									lineNumber: 228,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(TabsTrigger, {
									value: "appearance",
									className: "rounded-xl py-1.5 text-xs font-semibold",
									children: "Appearance"
								}, void 0, false, {
									fileName: _jsxFileName$4,
									lineNumber: 231,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(TabsTrigger, {
									value: "notifications",
									className: "rounded-xl py-1.5 text-xs font-semibold",
									children: "Notifications"
								}, void 0, false, {
									fileName: _jsxFileName$4,
									lineNumber: 234,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(TabsTrigger, {
									value: "ai",
									className: "rounded-xl py-1.5 text-xs font-semibold",
									children: "AI Config"
								}, void 0, false, {
									fileName: _jsxFileName$4,
									lineNumber: 237,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(TabsTrigger, {
									value: "privacy",
									className: "rounded-xl py-1.5 text-xs font-semibold",
									children: "Privacy"
								}, void 0, false, {
									fileName: _jsxFileName$4,
									lineNumber: 240,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName$4,
							lineNumber: 227,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(TabsContent, {
							value: "account",
							className: "space-y-5 pt-3",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("form", {
								onSubmit: handleSaveAccount,
								className: "space-y-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "flex items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(User, { className: "h-4 w-4 text-violet" }, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 249,
											columnNumber: 17
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h4", {
											className: "text-xs font-bold uppercase tracking-wider text-muted-foreground",
											children: "Personal Information"
										}, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 250,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName$4,
										lineNumber: 248,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "grid grid-cols-1 gap-3 sm:grid-cols-2",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "space-y-1",
											children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("label", {
												className: "text-xs font-semibold text-foreground",
												children: "Full Name"
											}, void 0, false, {
												fileName: _jsxFileName$4,
												lineNumber: 257,
												columnNumber: 19
											}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("input", {
												type: "text",
												value: fullName,
												onChange: (e) => setFullName(e.target.value),
												required: true,
												className: "w-full rounded-xl border border-input bg-background py-2 px-3 text-sm text-foreground focus:ring-2 focus:ring-ring"
											}, void 0, false, {
												fileName: _jsxFileName$4,
												lineNumber: 258,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName$4,
											lineNumber: 256,
											columnNumber: 17
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "space-y-1",
											children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("label", {
												className: "text-xs font-semibold text-foreground",
												children: "Email"
											}, void 0, false, {
												fileName: _jsxFileName$4,
												lineNumber: 267,
												columnNumber: 19
											}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("input", {
												type: "email",
												value: email,
												onChange: (e) => setEmail(e.target.value),
												required: true,
												className: "w-full rounded-xl border border-input bg-background py-2 px-3 text-sm text-foreground focus:ring-2 focus:ring-ring"
											}, void 0, false, {
												fileName: _jsxFileName$4,
												lineNumber: 268,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName$4,
											lineNumber: 266,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName$4,
										lineNumber: 255,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "space-y-1",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("label", {
											className: "text-xs font-semibold text-foreground",
											children: "Phone Number"
										}, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 279,
											columnNumber: 17
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("input", {
											type: "text",
											value: phone,
											onChange: (e) => setPhone(e.target.value),
											className: "w-full rounded-xl border border-input bg-background py-2 px-3 text-sm text-foreground focus:ring-2 focus:ring-ring",
											placeholder: "+91 98765 43210"
										}, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 280,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName$4,
										lineNumber: 278,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "flex justify-end",
										children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
											type: "submit",
											className: "rounded-full bg-ink px-4 py-1.5 text-xs font-semibold text-ink-foreground transition hover:opacity-90",
											children: "Save Profile Details"
										}, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 290,
											columnNumber: 17
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName$4,
										lineNumber: 289,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName$4,
								lineNumber: 247,
								columnNumber: 13
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "border-t border-border pt-4",
								children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("form", {
									onSubmit: handleUpdatePassword,
									className: "space-y-3",
									children: [
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "flex items-center gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(KeyRound, { className: "h-4 w-4 text-sun" }, void 0, false, {
												fileName: _jsxFileName$4,
												lineNumber: 302,
												columnNumber: 19
											}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h4", {
												className: "text-xs font-bold uppercase tracking-wider text-muted-foreground",
												children: "Password & Security"
											}, void 0, false, {
												fileName: _jsxFileName$4,
												lineNumber: 303,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName$4,
											lineNumber: 301,
											columnNumber: 17
										}, this),
										pwUpdated && /* @__PURE__ */ (void 0)("div", {
											className: "flex items-center gap-2 rounded-xl bg-mint/30 p-2.5 text-xs text-foreground",
											children: [/* @__PURE__ */ (void 0)(CircleCheck, { className: "h-4 w-4 text-success" }, void 0, false, {
												fileName: _jsxFileName$4,
												lineNumber: 310,
												columnNumber: 21
											}, this), /* @__PURE__ */ (void 0)("span", { children: "Password updated successfully!" }, void 0, false, {
												fileName: _jsxFileName$4,
												lineNumber: 311,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName$4,
											lineNumber: 309,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "grid grid-cols-1 gap-3 sm:grid-cols-3",
											children: [
												/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
													className: "space-y-1",
													children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("label", {
														className: "text-xs font-semibold text-foreground",
														children: "Current Password"
													}, void 0, false, {
														fileName: _jsxFileName$4,
														lineNumber: 317,
														columnNumber: 21
													}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("input", {
														type: "password",
														value: currentPassword,
														onChange: (e) => setCurrentPassword(e.target.value),
														placeholder: "••••••••",
														className: "w-full rounded-xl border border-input bg-background py-2 px-3 text-sm text-foreground focus:ring-2 focus:ring-ring"
													}, void 0, false, {
														fileName: _jsxFileName$4,
														lineNumber: 320,
														columnNumber: 21
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName$4,
													lineNumber: 316,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
													className: "space-y-1",
													children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("label", {
														className: "text-xs font-semibold text-foreground",
														children: "New Password"
													}, void 0, false, {
														fileName: _jsxFileName$4,
														lineNumber: 329,
														columnNumber: 21
													}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("input", {
														type: "password",
														value: newPassword,
														onChange: (e) => setNewPassword(e.target.value),
														placeholder: "Min 6 chars",
														className: "w-full rounded-xl border border-input bg-background py-2 px-3 text-sm text-foreground focus:ring-2 focus:ring-ring"
													}, void 0, false, {
														fileName: _jsxFileName$4,
														lineNumber: 330,
														columnNumber: 21
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName$4,
													lineNumber: 328,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
													className: "space-y-1",
													children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("label", {
														className: "text-xs font-semibold text-foreground",
														children: "Confirm New"
													}, void 0, false, {
														fileName: _jsxFileName$4,
														lineNumber: 339,
														columnNumber: 21
													}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("input", {
														type: "password",
														value: confirmPassword,
														onChange: (e) => setConfirmPassword(e.target.value),
														placeholder: "••••••••",
														className: "w-full rounded-xl border border-input bg-background py-2 px-3 text-sm text-foreground focus:ring-2 focus:ring-ring"
													}, void 0, false, {
														fileName: _jsxFileName$4,
														lineNumber: 340,
														columnNumber: 21
													}, this)]
												}, void 0, true, {
													fileName: _jsxFileName$4,
													lineNumber: 338,
													columnNumber: 19
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName$4,
											lineNumber: 315,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "flex justify-end",
											children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
												type: "submit",
												className: "rounded-full border border-border bg-muted/60 px-4 py-1.5 text-xs font-semibold text-foreground transition hover:bg-muted",
												children: "Change Password"
											}, void 0, false, {
												fileName: _jsxFileName$4,
												lineNumber: 351,
												columnNumber: 19
											}, this)
										}, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 350,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName$4,
									lineNumber: 300,
									columnNumber: 15
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName$4,
								lineNumber: 299,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName$4,
							lineNumber: 246,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(TabsContent, {
							value: "appearance",
							className: "space-y-4 pt-3",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h4", {
								className: "text-xs font-bold uppercase tracking-wider text-muted-foreground",
								children: "Theme & Interface Mode"
							}, void 0, false, {
								fileName: _jsxFileName$4,
								lineNumber: 365,
								columnNumber: 15
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
								className: "mt-1 text-xs text-muted-foreground",
								children: "Choose the visual theme that suits your working environment. Your choice is saved automatically."
							}, void 0, false, {
								fileName: _jsxFileName$4,
								lineNumber: 368,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName$4,
								lineNumber: 364,
								columnNumber: 13
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "grid grid-cols-1 gap-3 sm:grid-cols-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
										type: "button",
										onClick: () => handleThemeChange("light"),
										className: `relative flex flex-col items-center gap-2 rounded-2xl border p-4 text-center transition ${currentTheme === "light" ? "border-primary bg-card ring-2 ring-primary/20 shadow-sm" : "border-border bg-card/60 hover:bg-card"}`,
										children: [
											/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
												className: "grid h-10 w-10 place-items-center rounded-full bg-sun/30 text-ink",
												children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Sun, { className: "h-5 w-5" }, void 0, false, {
													fileName: _jsxFileName$4,
													lineNumber: 385,
													columnNumber: 19
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName$4,
												lineNumber: 384,
												columnNumber: 17
											}, this),
											/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
												className: "text-xs font-bold text-foreground",
												children: "Light Mode"
											}, void 0, false, {
												fileName: _jsxFileName$4,
												lineNumber: 388,
												columnNumber: 19
											}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
												className: "text-[10px] text-muted-foreground",
												children: "Clean, high-contrast lavender & white"
											}, void 0, false, {
												fileName: _jsxFileName$4,
												lineNumber: 389,
												columnNumber: 19
											}, this)] }, void 0, true, {
												fileName: _jsxFileName$4,
												lineNumber: 387,
												columnNumber: 17
											}, this),
											currentTheme === "light" && /* @__PURE__ */ (void 0)("span", {
												className: "absolute top-2 right-2 grid h-4 w-4 place-items-center rounded-full bg-primary text-[10px] text-primary-foreground",
												children: "✓"
											}, void 0, false, {
												fileName: _jsxFileName$4,
												lineNumber: 394,
												columnNumber: 19
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName$4,
										lineNumber: 375,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
										type: "button",
										onClick: () => handleThemeChange("dark"),
										className: `relative flex flex-col items-center gap-2 rounded-2xl border p-4 text-center transition ${currentTheme === "dark" ? "border-primary bg-card ring-2 ring-primary/20 shadow-sm" : "border-border bg-card/60 hover:bg-card"}`,
										children: [
											/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
												className: "grid h-10 w-10 place-items-center rounded-full bg-violet/30 text-violet",
												children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Moon, { className: "h-5 w-5" }, void 0, false, {
													fileName: _jsxFileName$4,
													lineNumber: 410,
													columnNumber: 19
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName$4,
												lineNumber: 409,
												columnNumber: 17
											}, this),
											/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
												className: "text-xs font-bold text-foreground",
												children: "Dark Mode"
											}, void 0, false, {
												fileName: _jsxFileName$4,
												lineNumber: 413,
												columnNumber: 19
											}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
												className: "text-[10px] text-muted-foreground",
												children: "Comfortable for evening study sessions"
											}, void 0, false, {
												fileName: _jsxFileName$4,
												lineNumber: 414,
												columnNumber: 19
											}, this)] }, void 0, true, {
												fileName: _jsxFileName$4,
												lineNumber: 412,
												columnNumber: 17
											}, this),
											currentTheme === "dark" && /* @__PURE__ */ (void 0)("span", {
												className: "absolute top-2 right-2 grid h-4 w-4 place-items-center rounded-full bg-primary text-[10px] text-primary-foreground",
												children: "✓"
											}, void 0, false, {
												fileName: _jsxFileName$4,
												lineNumber: 419,
												columnNumber: 19
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName$4,
										lineNumber: 400,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
										type: "button",
										onClick: () => handleThemeChange("night"),
										className: `relative flex flex-col items-center gap-2 rounded-2xl border p-4 text-center transition ${currentTheme === "night" ? "border-primary bg-card ring-2 ring-primary/20 shadow-sm" : "border-border bg-card/60 hover:bg-card"}`,
										children: [
											/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
												className: "grid h-10 w-10 place-items-center rounded-full bg-mint/30 text-primary-foreground",
												children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(MoonStar, { className: "h-5 w-5" }, void 0, false, {
													fileName: _jsxFileName$4,
													lineNumber: 435,
													columnNumber: 19
												}, this)
											}, void 0, false, {
												fileName: _jsxFileName$4,
												lineNumber: 434,
												columnNumber: 17
											}, this),
											/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
												className: "text-xs font-bold text-foreground",
												children: "Night Mode"
											}, void 0, false, {
												fileName: _jsxFileName$4,
												lineNumber: 438,
												columnNumber: 19
											}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
												className: "text-[10px] text-muted-foreground",
												children: "Deep contrast with subtle purple tint"
											}, void 0, false, {
												fileName: _jsxFileName$4,
												lineNumber: 439,
												columnNumber: 19
											}, this)] }, void 0, true, {
												fileName: _jsxFileName$4,
												lineNumber: 437,
												columnNumber: 17
											}, this),
											currentTheme === "night" && /* @__PURE__ */ (void 0)("span", {
												className: "absolute top-2 right-2 grid h-4 w-4 place-items-center rounded-full bg-primary text-[10px] text-primary-foreground",
												children: "✓"
											}, void 0, false, {
												fileName: _jsxFileName$4,
												lineNumber: 444,
												columnNumber: 19
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName$4,
										lineNumber: 425,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName$4,
								lineNumber: 374,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName$4,
							lineNumber: 363,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(TabsContent, {
							value: "notifications",
							className: "space-y-4 pt-3",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h4", {
								className: "text-xs font-bold uppercase tracking-wider text-muted-foreground",
								children: "Notification Channels & Frequency"
							}, void 0, false, {
								fileName: _jsxFileName$4,
								lineNumber: 455,
								columnNumber: 15
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
								className: "mt-1 text-xs text-muted-foreground",
								children: "Control which alerts appear in your top notifications feed and browser reminders."
							}, void 0, false, {
								fileName: _jsxFileName$4,
								lineNumber: 458,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName$4,
								lineNumber: 454,
								columnNumber: 13
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "space-y-3 divide-y divide-border/60",
								children: [
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "flex items-center justify-between pt-2",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
											className: "text-xs font-semibold text-foreground",
											children: "Learning & Lesson Reminders"
										}, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 466,
											columnNumber: 19
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
											className: "text-[11px] text-muted-foreground",
											children: "Alerts when your scheduled curriculum modules and exercises are due"
										}, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 469,
											columnNumber: 19
										}, this)] }, void 0, true, {
											fileName: _jsxFileName$4,
											lineNumber: 465,
											columnNumber: 17
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Switch, {
											checked: learningReminders,
											onCheckedChange: (checked) => {
												setLearningReminders(checked);
												actions.updateSettings({ notifications: {
													...settings.notifications,
													learningReminders: checked
												} });
											}
										}, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 473,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName$4,
										lineNumber: 464,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "flex items-center justify-between pt-3",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
											className: "text-xs font-semibold text-foreground",
											children: "Mock Interview Alerts"
										}, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 486,
											columnNumber: 19
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
											className: "text-[11px] text-muted-foreground",
											children: "Reminders for scheduled practice interviews and feedback readiness"
										}, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 487,
											columnNumber: 19
										}, this)] }, void 0, true, {
											fileName: _jsxFileName$4,
											lineNumber: 485,
											columnNumber: 17
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Switch, {
											checked: interviewReminders,
											onCheckedChange: (checked) => {
												setInterviewReminders(checked);
												actions.updateSettings({ notifications: {
													...settings.notifications,
													interviewReminders: checked
												} });
											}
										}, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 491,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName$4,
										lineNumber: 484,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "flex items-center justify-between pt-3",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
											className: "text-xs font-semibold text-foreground",
											children: "Job Application Updates"
										}, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 504,
											columnNumber: 19
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
											className: "text-[11px] text-muted-foreground",
											children: "Status changes when companies shortlist, schedule, or review your applications"
										}, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 505,
											columnNumber: 19
										}, this)] }, void 0, true, {
											fileName: _jsxFileName$4,
											lineNumber: 503,
											columnNumber: 17
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Switch, {
											checked: applicationUpdates,
											onCheckedChange: (checked) => {
												setApplicationUpdates(checked);
												actions.updateSettings({ notifications: {
													...settings.notifications,
													applicationUpdates: checked
												} });
											}
										}, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 509,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName$4,
										lineNumber: 502,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "flex items-center justify-between pt-3",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
											className: "text-xs font-semibold text-foreground",
											children: "Course & Content Announcements"
										}, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 522,
											columnNumber: 19
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
											className: "text-[11px] text-muted-foreground",
											children: "New modules added to enrolled courses and roadmap milestone releases"
										}, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 525,
											columnNumber: 19
										}, this)] }, void 0, true, {
											fileName: _jsxFileName$4,
											lineNumber: 521,
											columnNumber: 17
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Switch, {
											checked: courseAnnouncements,
											onCheckedChange: (checked) => {
												setCourseAnnouncements(checked);
												actions.updateSettings({ notifications: {
													...settings.notifications,
													courseAnnouncements: checked
												} });
											}
										}, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 529,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName$4,
										lineNumber: 520,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "flex items-center justify-between pt-3",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
											className: "text-xs font-semibold text-foreground",
											children: "Weekly Progress Digest"
										}, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 542,
											columnNumber: 19
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
											className: "text-[11px] text-muted-foreground",
											children: "Sunday summary of hours logged, skills boosted, and test performance"
										}, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 543,
											columnNumber: 19
										}, this)] }, void 0, true, {
											fileName: _jsxFileName$4,
											lineNumber: 541,
											columnNumber: 17
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Switch, {
											checked: weeklyDigest,
											onCheckedChange: (checked) => {
												setWeeklyDigest(checked);
												actions.updateSettings({ notifications: {
													...settings.notifications,
													weeklyDigest: checked
												} });
											}
										}, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 547,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName$4,
										lineNumber: 540,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName$4,
								lineNumber: 463,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName$4,
							lineNumber: 453,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(TabsContent, {
							value: "ai",
							className: "space-y-4 pt-3",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h4", {
								className: "text-xs font-bold uppercase tracking-wider text-muted-foreground",
								children: "AI Career Advisor Behaviors"
							}, void 0, false, {
								fileName: _jsxFileName$4,
								lineNumber: 563,
								columnNumber: 15
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
								className: "mt-1 text-xs text-muted-foreground",
								children: "Fine-tune voice responses, speech synthesis models, and conversation modes."
							}, void 0, false, {
								fileName: _jsxFileName$4,
								lineNumber: 566,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName$4,
								lineNumber: 562,
								columnNumber: 13
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "space-y-3 divide-y divide-border/60",
								children: [
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "flex items-center justify-between pt-2",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
											className: "text-xs font-semibold text-foreground",
											children: "Automatic Spoken Responses"
										}, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 574,
											columnNumber: 19
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
											className: "text-[11px] text-muted-foreground",
											children: "AI automatically reads aloud its replies using high-fidelity Gemini speech"
										}, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 577,
											columnNumber: 19
										}, this)] }, void 0, true, {
											fileName: _jsxFileName$4,
											lineNumber: 573,
											columnNumber: 17
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Switch, {
											checked: autoSpeak,
											onCheckedChange: handleToggleAutoSpeak
										}, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 581,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName$4,
										lineNumber: 572,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "flex items-center justify-between pt-3",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
											className: "text-xs font-semibold text-foreground",
											children: "Text-Only Response Mode"
										}, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 586,
											columnNumber: 19
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
											className: "text-[11px] text-muted-foreground",
											children: "Disable all automatic voice playback for silent environments"
										}, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 587,
											columnNumber: 19
										}, this)] }, void 0, true, {
											fileName: _jsxFileName$4,
											lineNumber: 585,
											columnNumber: 17
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Switch, {
											checked: textOnly,
											onCheckedChange: handleToggleTextOnly
										}, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 591,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName$4,
										lineNumber: 584,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "flex items-center justify-between pt-3",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
											className: "text-xs font-semibold text-foreground",
											children: "Microphone Voice Input"
										}, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 596,
											columnNumber: 19
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
											className: "text-[11px] text-muted-foreground",
											children: "Enable hands-free dictation button on the AI Assistant screen"
										}, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 597,
											columnNumber: 19
										}, this)] }, void 0, true, {
											fileName: _jsxFileName$4,
											lineNumber: 595,
											columnNumber: 17
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Switch, {
											checked: voiceInputEnabled,
											onCheckedChange: (checked) => {
												setVoiceInputEnabled(checked);
												actions.updateSettings({ aiPreferences: {
													...settings.aiPreferences,
													voiceInputEnabled: checked
												} });
											}
										}, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 601,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName$4,
										lineNumber: 594,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "flex items-center justify-between pt-3",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
											className: "text-xs font-semibold text-foreground",
											children: "AI Voice Persona"
										}, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 614,
											columnNumber: 19
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
											className: "text-[11px] text-muted-foreground",
											children: "Select the tone and timber of the synthetic speech engine"
										}, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 615,
											columnNumber: 19
										}, this)] }, void 0, true, {
											fileName: _jsxFileName$4,
											lineNumber: 613,
											columnNumber: 17
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("select", {
											value: voiceName,
											onChange: (e) => {
												const next = e.target.value;
												setVoiceName(next);
												actions.updateSettings({ aiPreferences: {
													...settings.aiPreferences,
													voiceName: next
												} });
												toast.info(`Voice persona switched to ${next}`);
											},
											className: "rounded-xl border border-input bg-background py-1.5 px-3 text-xs text-foreground focus:ring-2 focus:ring-ring",
											children: [
												/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", {
													value: "Kore",
													children: "Kore (Balanced & Clear)"
												}, void 0, false, {
													fileName: _jsxFileName$4,
													lineNumber: 631,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", {
													value: "Puck",
													children: "Puck (Engaging & Warm)"
												}, void 0, false, {
													fileName: _jsxFileName$4,
													lineNumber: 632,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", {
													value: "Fenrir",
													children: "Fenrir (Deep & Professional)"
												}, void 0, false, {
													fileName: _jsxFileName$4,
													lineNumber: 633,
													columnNumber: 19
												}, this),
												/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", {
													value: "Aoede",
													children: "Aoede (Friendly & Calm)"
												}, void 0, false, {
													fileName: _jsxFileName$4,
													lineNumber: 634,
													columnNumber: 19
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName$4,
											lineNumber: 619,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName$4,
										lineNumber: 612,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName$4,
								lineNumber: 571,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName$4,
							lineNumber: 561,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(TabsContent, {
							value: "privacy",
							className: "space-y-4 pt-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h4", {
									className: "text-xs font-bold uppercase tracking-wider text-muted-foreground",
									children: "Data Privacy & Chat Management"
								}, void 0, false, {
									fileName: _jsxFileName$4,
									lineNumber: 643,
									columnNumber: 15
								}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
									className: "mt-1 text-xs text-muted-foreground",
									children: "Control how your profile and skill evaluations are utilized by the career intelligence model."
								}, void 0, false, {
									fileName: _jsxFileName$4,
									lineNumber: 646,
									columnNumber: 15
								}, this)] }, void 0, true, {
									fileName: _jsxFileName$4,
									lineNumber: 642,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: "space-y-3 divide-y divide-border/60",
									children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "flex items-center justify-between pt-2",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
											className: "text-xs font-semibold text-foreground",
											children: "Share Profile with AI Advisor"
										}, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 655,
											columnNumber: 19
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
											className: "text-[11px] text-muted-foreground",
											children: "Allows Gemini to reference your name, skills, and target goal to give tailored feedback"
										}, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 658,
											columnNumber: 19
										}, this)] }, void 0, true, {
											fileName: _jsxFileName$4,
											lineNumber: 654,
											columnNumber: 17
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Switch, {
											checked: shareProfileWithAI,
											onCheckedChange: (checked) => {
												setShareProfileWithAI(checked);
												actions.updateSettings({ privacy: {
													...settings.privacy,
													shareProfileWithAI: checked
												} });
											}
										}, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 663,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName$4,
										lineNumber: 653,
										columnNumber: 15
									}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "flex items-center justify-between pt-3",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
											className: "text-xs font-semibold text-foreground",
											children: "Save Conversation History"
										}, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 676,
											columnNumber: 19
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
											className: "text-[11px] text-muted-foreground",
											children: "Store previous chat turns so the assistant maintains conversational context"
										}, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 677,
											columnNumber: 19
										}, this)] }, void 0, true, {
											fileName: _jsxFileName$4,
											lineNumber: 675,
											columnNumber: 17
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Switch, {
											checked: saveChatHistory,
											onCheckedChange: (checked) => {
												setSaveChatHistory(checked);
												actions.updateSettings({ privacy: {
													...settings.privacy,
													saveChatHistory: checked
												} });
											}
										}, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 681,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName$4,
										lineNumber: 674,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName$4,
									lineNumber: 652,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: "rounded-2xl border border-border/80 bg-muted/30 p-4 space-y-3 mt-4",
									children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
											className: "text-xs font-semibold text-foreground",
											children: "Clear AI Conversation History"
										}, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 696,
											columnNumber: 19
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
											className: "text-[11px] text-muted-foreground",
											children: "Reset chat messages back to the initial career greeting"
										}, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 699,
											columnNumber: 19
										}, this)] }, void 0, true, {
											fileName: _jsxFileName$4,
											lineNumber: 695,
											columnNumber: 17
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
											type: "button",
											onClick: handleClearHistory,
											className: "rounded-full border border-border bg-card px-3 py-1.5 text-xs font-medium text-foreground hover:bg-muted",
											children: "Clear Chat"
										}, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 703,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName$4,
										lineNumber: 694,
										columnNumber: 15
									}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "border-t border-border/60 pt-3 flex items-center justify-between",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
											className: "text-xs font-semibold text-destructive",
											children: "Reset All Pathfinder Data"
										}, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 714,
											columnNumber: 19
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
											className: "text-[11px] text-muted-foreground",
											children: "Clears local state, mock applications, skills, and resets to defaults"
										}, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 717,
											columnNumber: 19
										}, this)] }, void 0, true, {
											fileName: _jsxFileName$4,
											lineNumber: 713,
											columnNumber: 17
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
											type: "button",
											onClick: () => setShowResetConfirm(true),
											className: "rounded-full bg-destructive/10 px-3 py-1.5 text-xs font-semibold text-destructive hover:bg-destructive/20",
											children: "Reset All Data"
										}, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 721,
											columnNumber: 17
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName$4,
										lineNumber: 712,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName$4,
									lineNumber: 693,
									columnNumber: 13
								}, this),
								showResetConfirm && /* @__PURE__ */ (void 0)("div", {
									className: "rounded-2xl border border-destructive/40 bg-destructive/10 p-4 space-y-3 animate-in fade-in",
									children: [
										/* @__PURE__ */ (void 0)("div", {
											className: "flex items-center gap-2 text-destructive font-semibold text-xs",
											children: [/* @__PURE__ */ (void 0)(TriangleAlert, { className: "h-4 w-4" }, void 0, false, {
												fileName: _jsxFileName$4,
												lineNumber: 734,
												columnNumber: 19
											}, this), /* @__PURE__ */ (void 0)("span", { children: "Are you sure you want to reset everything?" }, void 0, false, {
												fileName: _jsxFileName$4,
												lineNumber: 735,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName$4,
											lineNumber: 733,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ (void 0)("p", {
											className: "text-xs text-muted-foreground",
											children: "This will reset all your enrolled course progress, mock interview logs, custom roadmaps, and profile changes back to factory defaults."
										}, void 0, false, {
											fileName: _jsxFileName$4,
											lineNumber: 737,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ (void 0)("div", {
											className: "flex gap-2 justify-end",
											children: [/* @__PURE__ */ (void 0)("button", {
												type: "button",
												onClick: () => setShowResetConfirm(false),
												className: "rounded-full border border-border bg-card px-3 py-1 text-xs font-medium text-foreground hover:bg-muted",
												children: "Cancel"
											}, void 0, false, {
												fileName: _jsxFileName$4,
												lineNumber: 742,
												columnNumber: 19
											}, this), /* @__PURE__ */ (void 0)("button", {
												type: "button",
												onClick: handleFullReset,
												className: "rounded-full bg-destructive px-3.5 py-1 text-xs font-semibold text-destructive-foreground hover:bg-destructive/90",
												children: "Confirm Reset"
											}, void 0, false, {
												fileName: _jsxFileName$4,
												lineNumber: 749,
												columnNumber: 19
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName$4,
											lineNumber: 741,
											columnNumber: 17
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName$4,
									lineNumber: 732,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName$4,
							lineNumber: 641,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName$4,
					lineNumber: 226,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogFooter, {
					className: "pt-2",
					children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
						type: "button",
						onClick: () => onOpenChange(false),
						className: "rounded-full bg-ink px-5 py-2 text-xs font-semibold text-ink-foreground transition hover:opacity-90",
						children: "Close Settings"
					}, void 0, false, {
						fileName: _jsxFileName$4,
						lineNumber: 763,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName$4,
					lineNumber: 762,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName$4,
			lineNumber: 218,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName$4,
		lineNumber: 217,
		columnNumber: 5
	}, this);
}
var _jsxFileName$3 = "/app/applet/src/components/UpgradeProModal.tsx";
function UpgradeProModal({ open, onOpenChange }) {
	const subscription = usePathfinder((s) => s).subscription;
	const isPro = subscription.plan === "pro";
	const [interval, setInterval] = (0, import_react.useState)("monthly");
	const [loading, setLoading] = (0, import_react.useState)(false);
	const handleUpgrade = () => {
		setLoading(true);
		setTimeout(() => {
			actions.upgradeToPro(interval);
			setLoading(false);
			toast.success("Pathfinder Pro Activated!", { description: "Your 1-month free trial is now live. Enjoy unlimited AI interviews and custom roadmaps." });
			onOpenChange(false);
		}, 400);
	};
	const handleDowngrade = () => {
		actions.downgradeToFree();
		toast.info("Switched to Pathfinder Free plan", { description: "You can re-upgrade anytime to unlock unlimited AI features." });
		onOpenChange(false);
	};
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogContent, {
			className: "max-w-3xl max-h-[92vh] overflow-y-auto rounded-3xl border-border bg-card p-6 sm:p-8 shadow-soft",
			children: [
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogHeader, {
					className: "text-center",
					children: [
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-butter text-ink shadow-sm mb-2",
							children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Crown, { className: "h-6 w-6 text-sun" }, void 0, false, {
								fileName: _jsxFileName$3,
								lineNumber: 88,
								columnNumber: 13
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName$3,
							lineNumber: 87,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogTitle, {
							className: "text-2xl font-bold text-foreground",
							children: isPro ? "Your Pathfinder Pro Membership" : "Accelerate Your Career with Pathfinder Pro"
						}, void 0, false, {
							fileName: _jsxFileName$3,
							lineNumber: 90,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogDescription, {
							className: "text-xs text-muted-foreground max-w-md mx-auto",
							children: isPro ? "You have full access to unlimited voice mock interviews, custom week-by-week roadmaps, and CV gap diagnosis." : "Master high-demand tech skills faster with personalized AI coaching, realistic interview simulations, and verified roadmaps."
						}, void 0, false, {
							fileName: _jsxFileName$3,
							lineNumber: 95,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName$3,
					lineNumber: 86,
					columnNumber: 9
				}, this),
				!isPro && /* @__PURE__ */ (void 0)("div", {
					className: "flex items-center justify-center gap-3 pt-2",
					children: [
						/* @__PURE__ */ (void 0)("span", {
							className: `text-xs font-semibold ${interval === "monthly" ? "text-foreground" : "text-muted-foreground"}`,
							children: "Monthly"
						}, void 0, false, {
							fileName: _jsxFileName$3,
							lineNumber: 105,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ (void 0)("button", {
							type: "button",
							onClick: () => setInterval(interval === "monthly" ? "yearly" : "monthly"),
							className: "relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent bg-ink transition-colors focus:outline-none",
							children: /* @__PURE__ */ (void 0)("span", { className: `pointer-events-none inline-block h-5 w-5 transform rounded-full bg-sun shadow-lg transition duration-200 ease-in-out ${interval === "yearly" ? "translate-x-5" : "translate-x-0"}` }, void 0, false, {
								fileName: _jsxFileName$3,
								lineNumber: 115,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName$3,
							lineNumber: 110,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ (void 0)("div", {
							className: "flex items-center gap-1.5",
							children: [/* @__PURE__ */ (void 0)("span", {
								className: `text-xs font-semibold ${interval === "yearly" ? "text-foreground" : "text-muted-foreground"}`,
								children: "Annual"
							}, void 0, false, {
								fileName: _jsxFileName$3,
								lineNumber: 122,
								columnNumber: 15
							}, this), /* @__PURE__ */ (void 0)("span", {
								className: "rounded-full bg-mint/50 px-2 py-0.5 text-[10px] font-bold text-foreground",
								children: "Save 25%"
							}, void 0, false, {
								fileName: _jsxFileName$3,
								lineNumber: 127,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName$3,
							lineNumber: 121,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName$3,
					lineNumber: 104,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "grid grid-cols-1 gap-5 pt-4 md:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "rounded-3xl border border-border/80 bg-background/50 p-6 flex flex-col justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
									className: "rounded-full bg-muted px-2.5 py-0.5 text-[11px] font-semibold text-muted-foreground",
									children: "Free Starter"
								}, void 0, false, {
									fileName: _jsxFileName$3,
									lineNumber: 140,
									columnNumber: 17
								}, this), !isPro && /* @__PURE__ */ (void 0)("span", {
									className: "rounded-full bg-muted/80 px-2 py-0.5 text-[10px] font-semibold text-foreground",
									children: "Current Plan"
								}, void 0, false, {
									fileName: _jsxFileName$3,
									lineNumber: 144,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName$3,
								lineNumber: 139,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "mt-4",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
									className: "text-3xl font-bold text-foreground",
									children: "$0"
								}, void 0, false, {
									fileName: _jsxFileName$3,
									lineNumber: 150,
									columnNumber: 17
								}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
									className: "text-xs text-muted-foreground",
									children: " / forever"
								}, void 0, false, {
									fileName: _jsxFileName$3,
									lineNumber: 151,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName$3,
								lineNumber: 149,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
								className: "mt-2 text-xs text-muted-foreground",
								children: "Essential tools to evaluate skills and track daily learning progress."
							}, void 0, false, {
								fileName: _jsxFileName$3,
								lineNumber: 153,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "mt-6 space-y-2.5 text-xs text-muted-foreground",
								children: [
									"1 custom AI learning roadmap",
									"Basic skill radar auditing",
									"1 mock interview per month",
									"Standard public job feed",
									"Standard AI assistant response speed"
								].map((f, i) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Check, { className: "h-4 w-4 text-muted-foreground shrink-0" }, void 0, false, {
										fileName: _jsxFileName$3,
										lineNumber: 160,
										columnNumber: 21
									}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: f }, void 0, false, {
										fileName: _jsxFileName$3,
										lineNumber: 161,
										columnNumber: 21
									}, this)]
								}, i, true, {
									fileName: _jsxFileName$3,
									lineNumber: 159,
									columnNumber: 19
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName$3,
								lineNumber: 157,
								columnNumber: 15
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName$3,
							lineNumber: 138,
							columnNumber: 13
						}, this), isPro && /* @__PURE__ */ (void 0)("div", {
							className: "pt-6",
							children: /* @__PURE__ */ (void 0)("button", {
								type: "button",
								onClick: handleDowngrade,
								className: "w-full rounded-full border border-border bg-card py-2 text-xs font-semibold text-muted-foreground transition hover:bg-muted hover:text-foreground",
								children: "Downgrade to Free"
							}, void 0, false, {
								fileName: _jsxFileName$3,
								lineNumber: 169,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName$3,
							lineNumber: 168,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName$3,
						lineNumber: 137,
						columnNumber: 11
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "relative rounded-3xl border-2 border-primary bg-card p-6 shadow-md flex flex-col justify-between",
						children: [
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
								className: "absolute -top-3 right-6 rounded-full bg-sun px-3 py-0.5 text-[10px] font-bold text-ink shadow-sm",
								children: "MOST POPULAR"
							}, void 0, false, {
								fileName: _jsxFileName$3,
								lineNumber: 182,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "flex items-center gap-1.5",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
											className: "rounded-full bg-ink px-2.5 py-0.5 text-[11px] font-semibold text-ink-foreground",
											children: "Pathfinder Pro"
										}, void 0, false, {
											fileName: _jsxFileName$3,
											lineNumber: 189,
											columnNumber: 19
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
											className: "rounded-full bg-butter px-2 py-0.5 text-[10px] font-semibold text-foreground",
											children: "1 Month Free"
										}, void 0, false, {
											fileName: _jsxFileName$3,
											lineNumber: 192,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName$3,
										lineNumber: 188,
										columnNumber: 17
									}, this), isPro && /* @__PURE__ */ (void 0)("span", {
										className: "rounded-full bg-mint/50 px-2.5 py-0.5 text-[10px] font-bold text-foreground flex items-center gap-1",
										children: [/* @__PURE__ */ (void 0)(Check, { className: "h-3 w-3" }, void 0, false, {
											fileName: _jsxFileName$3,
											lineNumber: 198,
											columnNumber: 21
										}, this), " Active"]
									}, void 0, true, {
										fileName: _jsxFileName$3,
										lineNumber: 197,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName$3,
									lineNumber: 187,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: "mt-4 flex items-baseline gap-1",
									children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
										className: "text-3xl font-bold text-foreground",
										children: interval === "monthly" ? "$19" : "$14"
									}, void 0, false, {
										fileName: _jsxFileName$3,
										lineNumber: 204,
										columnNumber: 17
									}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
										className: "text-xs text-muted-foreground",
										children: ["/ month ", interval === "yearly" ? "(billed annually)" : ""]
									}, void 0, true, {
										fileName: _jsxFileName$3,
										lineNumber: 207,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName$3,
									lineNumber: 203,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
									className: "mt-2 text-xs text-muted-foreground",
									children: "Complete career intelligence suite with voice mock interviews and custom roadmaps."
								}, void 0, false, {
									fileName: _jsxFileName$3,
									lineNumber: 211,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: "mt-6 space-y-2.5 text-xs",
									children: [
										{
											title: "Unlimited AI Roadmaps",
											desc: "Generate week-by-week personalized curriculums with live milestones"
										},
										{
											title: "Voice Mock Interviews",
											desc: "Realistic speech evaluation with rubric scorecards (Technical, Communication)"
										},
										{
											title: "1-Click CV Gap Diagnosis",
											desc: "In-depth resume parsing and matching to target job descriptions"
										},
										{
											title: "Priority Gemini 3.8 Engine",
											desc: "Fastest response latency with zero rate-limit throttling"
										},
										{
											title: "Course Certificates",
											desc: "Verified credentials to share directly on LinkedIn and resumes"
										},
										{
											title: "Exclusive Job Alerts",
											desc: "Early notifications when hiring partners list junior frontend & design roles"
										}
									].map((f, i) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "flex items-start gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "mt-0.5 grid h-4 w-4 shrink-0 place-items-center rounded-full bg-ink text-[10px] text-sun",
											children: "✓"
										}, void 0, false, {
											fileName: _jsxFileName$3,
											lineNumber: 218,
											columnNumber: 21
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
											className: "font-semibold text-foreground",
											children: f.title
										}, void 0, false, {
											fileName: _jsxFileName$3,
											lineNumber: 222,
											columnNumber: 23
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
											className: "text-[11px] text-muted-foreground",
											children: f.desc
										}, void 0, false, {
											fileName: _jsxFileName$3,
											lineNumber: 223,
											columnNumber: 23
										}, this)] }, void 0, true, {
											fileName: _jsxFileName$3,
											lineNumber: 221,
											columnNumber: 21
										}, this)]
									}, i, true, {
										fileName: _jsxFileName$3,
										lineNumber: 217,
										columnNumber: 19
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName$3,
									lineNumber: 215,
									columnNumber: 15
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName$3,
								lineNumber: 186,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "pt-6",
								children: !isPro ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
									type: "button",
									disabled: loading,
									onClick: handleUpgrade,
									className: "w-full flex items-center justify-center gap-2 rounded-full bg-ink py-2.5 text-xs font-semibold text-ink-foreground shadow-sm transition hover:opacity-90 disabled:opacity-50",
									children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Sparkles, { className: "h-4 w-4 text-sun" }, void 0, false, {
										fileName: _jsxFileName$3,
										lineNumber: 238,
										columnNumber: 19
									}, this), loading ? "Activating Trial..." : "Start 1-Month Free Trial"]
								}, void 0, true, {
									fileName: _jsxFileName$3,
									lineNumber: 232,
									columnNumber: 17
								}, this) : /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: "rounded-2xl bg-muted/40 p-3 text-center",
									children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
										className: "text-xs font-semibold text-foreground",
										children: "Pro Membership is Active"
									}, void 0, false, {
										fileName: _jsxFileName$3,
										lineNumber: 243,
										columnNumber: 19
									}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
										className: "text-[11px] text-muted-foreground mt-0.5",
										children: ["Trial valid until ", new Date(subscription.activeUntil).toLocaleDateString()]
									}, void 0, true, {
										fileName: _jsxFileName$3,
										lineNumber: 244,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName$3,
									lineNumber: 242,
									columnNumber: 17
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName$3,
								lineNumber: 230,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName$3,
						lineNumber: 181,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName$3,
					lineNumber: 135,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "mt-4 rounded-2xl bg-muted/30 p-3 flex items-center justify-between text-xs text-muted-foreground",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
						className: "flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Shield, { className: "h-4 w-4 text-violet" }, void 0, false, {
							fileName: _jsxFileName$3,
							lineNumber: 255,
							columnNumber: 13
						}, this), "No risk • Demo trial environment • Cancel anytime with one click"]
					}, void 0, true, {
						fileName: _jsxFileName$3,
						lineNumber: 254,
						columnNumber: 11
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
						className: "font-medium text-foreground",
						children: "Instant Activation"
					}, void 0, false, {
						fileName: _jsxFileName$3,
						lineNumber: 258,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName$3,
					lineNumber: 253,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogFooter, {
					className: "pt-2",
					children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
						type: "button",
						onClick: () => onOpenChange(false),
						className: "rounded-full border border-border px-4 py-1.5 text-xs font-semibold text-muted-foreground hover:bg-muted",
						children: "Close"
					}, void 0, false, {
						fileName: _jsxFileName$3,
						lineNumber: 262,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName$3,
					lineNumber: 261,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName$3,
			lineNumber: 85,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName$3,
		lineNumber: 84,
		columnNumber: 5
	}, this);
}
var _jsxFileName$2 = "/app/applet/src/components/SupportCenterModal.tsx";
var FAQS = [
	{
		id: "faq-1",
		category: "AI Assistant",
		question: "How does the AI Assistant personalize career advice?",
		answer: "Pathfinder passes your target career goal, skill audit levels, completed courses, and uploaded CV directly into Google Gemini 3.8. The model checks your exact skill gaps and provides customized weekly milestones rather than generic advice."
	},
	{
		id: "faq-2",
		category: "AI Assistant",
		question: "How do I turn voice speech playback on or off?",
		answer: "You can toggle voice playback at any time using the 'Voice On / Voice Off' pill at the top of the AI Assistant screen or within Settings > AI Config. When turned off, the assistant operates in silent text-only mode."
	},
	{
		id: "faq-3",
		category: "AI Assistant",
		question: "Can I generate a custom week-by-week learning roadmap?",
		answer: "Yes! Simply ask the AI Assistant: 'Can you generate a 4-week learning roadmap for me?'. Gemini will craft a custom curriculum with deliverables and automatically save it to your 'Explore Careers' and 'Learning' sections."
	},
	{
		id: "faq-4",
		category: "Courses & Learning",
		question: "How are lesson hours and skill radar points calculated?",
		answer: "When you complete lessons and interactive code builds in courses like React Pro, the platform calculates completion percentages and applies skill gains (e.g. +8 points on completion) directly to your radar graph and dashboard progress tracker."
	},
	{
		id: "faq-5",
		category: "Courses & Learning",
		question: "Can I enroll in multiple career tracks simultaneously?",
		answer: "Yes. You can explore courses in Frontend, UI/UX, Data Structures, and Communication. Your enrolled courses and progress persist automatically across sessions."
	},
	{
		id: "faq-6",
		category: "Job Applications",
		question: "How does 1-click job application tracking work?",
		answer: "Clicking 'Easy Apply' on any opportunity in the Job Board immediately logs the application with an 'Applied' status. You can track progress across review stages, interview schedules, and offers in your applications feed."
	},
	{
		id: "faq-7",
		category: "Job Applications",
		question: "Does uploading my CV boost my job match percentage?",
		answer: "Yes. The CV parser audits your resume against required role competencies and recommends high-impact courses to close any gaps before you apply."
	},
	{
		id: "faq-8",
		category: "Account & Billing",
		question: "How do I activate the 1-month free Pathfinder Pro trial?",
		answer: "Click 'Upgrade now' in the sidebar or from your profile dropdown. The 1-month trial activates instantly with no credit card required in this demo environment."
	},
	{
		id: "faq-9",
		category: "Account & Billing",
		question: "Can I reset my career progress data?",
		answer: "Yes. Open Settings > Privacy and click 'Reset All Pathfinder Data'. This will restore the platform back to initial sample state."
	}
];
function SupportCenterModal({ open, onOpenChange }) {
	const profile = usePathfinder((s) => s).profile;
	const [activeTab, setActiveTab] = (0, import_react.useState)("faq");
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [selectedCategory, setSelectedCategory] = (0, import_react.useState)("All");
	const [expandedFaq, setExpandedFaq] = (0, import_react.useState)("faq-1");
	const [subject, setSubject] = (0, import_react.useState)("");
	const [category, setCategory] = (0, import_react.useState)("AI Assistant");
	const [priority, setPriority] = (0, import_react.useState)("Normal");
	const [message, setMessage] = (0, import_react.useState)("");
	const [submittedTicketId, setSubmittedTicketId] = (0, import_react.useState)(null);
	const categories = [
		"All",
		"AI Assistant",
		"Courses & Learning",
		"Job Applications",
		"Account & Billing"
	];
	const filteredFaqs = FAQS.filter((f) => {
		const matchesCategory = selectedCategory === "All" || f.category === selectedCategory;
		const matchesSearch = !searchQuery.trim() || f.question.toLowerCase().includes(searchQuery.toLowerCase()) || f.answer.toLowerCase().includes(searchQuery.toLowerCase());
		return matchesCategory && matchesSearch;
	});
	const handleTicketSubmit = (e) => {
		e.preventDefault();
		if (!subject.trim()) {
			toast.error("Please enter a subject line");
			return;
		}
		if (!message.trim() || message.trim().length < 10) {
			toast.error("Please provide a detailed message (minimum 10 characters)");
			return;
		}
		const ticketId = actions.submitSupportTicket({
			subject: subject.trim(),
			category,
			priority,
			message: message.trim()
		});
		setSubmittedTicketId(ticketId);
		toast.success(`Support Ticket #${ticketId} Logged`, { description: "Our career advisory team has received your ticket." });
	};
	const handleResetForm = () => {
		setSubject("");
		setMessage("");
		setCategory("AI Assistant");
		setPriority("Normal");
		setSubmittedTicketId(null);
	};
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogContent, {
			className: "max-w-2xl max-h-[90vh] overflow-y-auto rounded-3xl border-border bg-card p-6 shadow-soft",
			children: [
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogHeader, {
					className: "text-left",
					children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "flex items-center gap-2.5",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "grid h-9 w-9 place-items-center rounded-xl bg-lilac/50 text-foreground",
							children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(LifeBuoy, { className: "h-5 w-5" }, void 0, false, {
								fileName: _jsxFileName$2,
								lineNumber: 176,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName$2,
							lineNumber: 175,
							columnNumber: 13
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogTitle, {
							className: "text-xl font-bold text-foreground",
							children: "Support Center"
						}, void 0, false, {
							fileName: _jsxFileName$2,
							lineNumber: 179,
							columnNumber: 15
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogDescription, {
							className: "text-xs text-muted-foreground",
							children: "Browse step-by-step guides, FAQs, or contact our dedicated career team."
						}, void 0, false, {
							fileName: _jsxFileName$2,
							lineNumber: 182,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName$2,
							lineNumber: 178,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName$2,
						lineNumber: 174,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName$2,
					lineNumber: 173,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Tabs, {
					value: activeTab,
					onValueChange: setActiveTab,
					className: "w-full pt-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(TabsList, {
							className: "grid w-full grid-cols-2 rounded-2xl bg-muted/60 p-1 text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(TabsTrigger, {
								value: "faq",
								className: "rounded-xl py-1.5 text-xs font-semibold",
								children: "Frequently Asked Questions"
							}, void 0, false, {
								fileName: _jsxFileName$2,
								lineNumber: 191,
								columnNumber: 13
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(TabsTrigger, {
								value: "contact",
								className: "rounded-xl py-1.5 text-xs font-semibold",
								children: "Contact Support Team"
							}, void 0, false, {
								fileName: _jsxFileName$2,
								lineNumber: 194,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName$2,
							lineNumber: 190,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(TabsContent, {
							value: "faq",
							className: "space-y-4 pt-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: "relative",
									children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Search, { className: "absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" }, void 0, false, {
										fileName: _jsxFileName$2,
										lineNumber: 203,
										columnNumber: 15
									}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("input", {
										type: "text",
										value: searchQuery,
										onChange: (e) => setSearchQuery(e.target.value),
										placeholder: "Search help topics, roadmaps, voice commands...",
										className: "w-full rounded-2xl border border-input bg-background py-2 pl-9 pr-3 text-xs text-foreground focus:ring-2 focus:ring-ring"
									}, void 0, false, {
										fileName: _jsxFileName$2,
										lineNumber: 204,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName$2,
									lineNumber: 202,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: "flex flex-wrap gap-1.5",
									children: categories.map((c) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
										type: "button",
										onClick: () => setSelectedCategory(c),
										className: `rounded-full px-2.5 py-1 text-[11px] font-semibold transition ${selectedCategory === c ? "bg-ink text-ink-foreground" : "border border-border bg-card text-muted-foreground hover:bg-muted hover:text-foreground"}`,
										children: c
									}, c, false, {
										fileName: _jsxFileName$2,
										lineNumber: 216,
										columnNumber: 17
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName$2,
									lineNumber: 214,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: "space-y-2 pt-1 max-h-[380px] overflow-y-auto pr-1",
									children: filteredFaqs.length > 0 ? filteredFaqs.map((faq) => {
										const isExpanded = expandedFaq === faq.id;
										return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "rounded-2xl border border-border/80 bg-background/50 transition overflow-hidden",
											children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
												type: "button",
												onClick: () => setExpandedFaq(isExpanded ? null : faq.id),
												className: "flex w-full items-center justify-between p-3.5 text-left text-xs font-bold text-foreground hover:bg-muted/30",
												children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
													className: "flex items-center gap-2",
													children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(CircleQuestionMark, { className: "h-3.5 w-3.5 text-violet shrink-0" }, void 0, false, {
														fileName: _jsxFileName$2,
														lineNumber: 247,
														columnNumber: 27
													}, this), faq.question]
												}, void 0, true, {
													fileName: _jsxFileName$2,
													lineNumber: 246,
													columnNumber: 25
												}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(ChevronDown, { className: `h-4 w-4 text-muted-foreground transition-transform duration-200 shrink-0 ${isExpanded ? "rotate-180" : ""}` }, void 0, false, {
													fileName: _jsxFileName$2,
													lineNumber: 250,
													columnNumber: 25
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName$2,
												lineNumber: 241,
												columnNumber: 23
											}, this), isExpanded && /* @__PURE__ */ (void 0)("div", {
												className: "px-3.5 pb-3.5 pt-1 text-xs text-muted-foreground leading-relaxed border-t border-border/40",
												children: [/* @__PURE__ */ (void 0)("p", { children: faq.answer }, void 0, false, {
													fileName: _jsxFileName$2,
													lineNumber: 258,
													columnNumber: 27
												}, this), /* @__PURE__ */ (void 0)("span", {
													className: "mt-2 inline-block rounded-md bg-muted px-2 py-0.5 text-[10px] font-medium text-foreground/70",
													children: ["Category: ", faq.category]
												}, void 0, true, {
													fileName: _jsxFileName$2,
													lineNumber: 259,
													columnNumber: 27
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName$2,
												lineNumber: 257,
												columnNumber: 25
											}, this)]
										}, faq.id, true, {
											fileName: _jsxFileName$2,
											lineNumber: 237,
											columnNumber: 21
										}, this);
									}) : /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "rounded-2xl border border-dashed border-border p-6 text-center text-xs text-muted-foreground",
										children: "No matching help articles found. Try searching a different keyword or contact our team directly below."
									}, void 0, false, {
										fileName: _jsxFileName$2,
										lineNumber: 268,
										columnNumber: 17
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName$2,
									lineNumber: 232,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName$2,
							lineNumber: 200,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(TabsContent, {
							value: "contact",
							className: "space-y-4 pt-3",
							children: submittedTicketId ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "rounded-3xl border border-border bg-mint/20 p-6 text-center space-y-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "mx-auto grid h-12 w-12 place-items-center rounded-2xl bg-mint text-primary-foreground shadow-sm",
										children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(CircleCheck, { className: "h-6 w-6 text-success" }, void 0, false, {
											fileName: _jsxFileName$2,
											lineNumber: 281,
											columnNumber: 19
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName$2,
										lineNumber: 280,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h4", {
										className: "text-base font-bold text-foreground",
										children: [
											"Support Ticket #",
											submittedTicketId,
											" Logged"
										]
									}, void 0, true, {
										fileName: _jsxFileName$2,
										lineNumber: 283,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
										className: "text-xs text-muted-foreground max-w-sm mx-auto leading-relaxed",
										children: [
											"Thank you, ",
											profile.name,
											"! Your request has been forwarded to our career support queue. A career specialist will respond to ",
											profile.email,
											" within 2 hours."
										]
									}, void 0, true, {
										fileName: _jsxFileName$2,
										lineNumber: 286,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "pt-2",
										children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
											type: "button",
											onClick: handleResetForm,
											className: "rounded-full bg-ink px-4 py-1.5 text-xs font-semibold text-ink-foreground hover:opacity-90",
											children: "Submit Another Inquiry"
										}, void 0, false, {
											fileName: _jsxFileName$2,
											lineNumber: 291,
											columnNumber: 19
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName$2,
										lineNumber: 290,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName$2,
								lineNumber: 279,
								columnNumber: 15
							}, this) : /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("form", {
								onSubmit: handleTicketSubmit,
								className: "space-y-3.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "grid grid-cols-1 gap-3 sm:grid-cols-2",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "space-y-1",
											children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("label", {
												className: "text-xs font-semibold text-foreground",
												children: "Your Name"
											}, void 0, false, {
												fileName: _jsxFileName$2,
												lineNumber: 304,
												columnNumber: 21
											}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("input", {
												type: "text",
												disabled: true,
												value: profile.name,
												className: "w-full rounded-xl border border-input bg-muted/50 py-2 px-3 text-xs text-muted-foreground"
											}, void 0, false, {
												fileName: _jsxFileName$2,
												lineNumber: 305,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName$2,
											lineNumber: 303,
											columnNumber: 19
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "space-y-1",
											children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("label", {
												className: "text-xs font-semibold text-foreground",
												children: "Email Address"
											}, void 0, false, {
												fileName: _jsxFileName$2,
												lineNumber: 313,
												columnNumber: 21
											}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("input", {
												type: "email",
												disabled: true,
												value: profile.email,
												className: "w-full rounded-xl border border-input bg-muted/50 py-2 px-3 text-xs text-muted-foreground"
											}, void 0, false, {
												fileName: _jsxFileName$2,
												lineNumber: 314,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName$2,
											lineNumber: 312,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName$2,
										lineNumber: 302,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "grid grid-cols-1 gap-3 sm:grid-cols-2",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "space-y-1",
											children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("label", {
												className: "text-xs font-semibold text-foreground",
												children: "Inquiry Category"
											}, void 0, false, {
												fileName: _jsxFileName$2,
												lineNumber: 325,
												columnNumber: 21
											}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("select", {
												value: category,
												onChange: (e) => setCategory(e.target.value),
												className: "w-full rounded-xl border border-input bg-background py-2 px-3 text-xs text-foreground focus:ring-2 focus:ring-ring",
												children: [
													/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", {
														value: "AI Assistant",
														children: "AI Assistant & Gemini Prompts"
													}, void 0, false, {
														fileName: _jsxFileName$2,
														lineNumber: 333,
														columnNumber: 23
													}, this),
													/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", {
														value: "Courses & Learning",
														children: "Courses & Curriculum"
													}, void 0, false, {
														fileName: _jsxFileName$2,
														lineNumber: 334,
														columnNumber: 23
													}, this),
													/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", {
														value: "Job Applications",
														children: "Job Applications & CV"
													}, void 0, false, {
														fileName: _jsxFileName$2,
														lineNumber: 335,
														columnNumber: 23
													}, this),
													/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", {
														value: "Account & Billing",
														children: "Account & Billing"
													}, void 0, false, {
														fileName: _jsxFileName$2,
														lineNumber: 336,
														columnNumber: 23
													}, this),
													/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", {
														value: "Other",
														children: "Other Question"
													}, void 0, false, {
														fileName: _jsxFileName$2,
														lineNumber: 337,
														columnNumber: 23
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName$2,
												lineNumber: 328,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName$2,
											lineNumber: 324,
											columnNumber: 19
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "space-y-1",
											children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("label", {
												className: "text-xs font-semibold text-foreground",
												children: "Priority"
											}, void 0, false, {
												fileName: _jsxFileName$2,
												lineNumber: 342,
												columnNumber: 21
											}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("select", {
												value: priority,
												onChange: (e) => setPriority(e.target.value),
												className: "w-full rounded-xl border border-input bg-background py-2 px-3 text-xs text-foreground focus:ring-2 focus:ring-ring",
												children: [
													/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", {
														value: "Normal",
														children: "Normal (Response within 24h)"
													}, void 0, false, {
														fileName: _jsxFileName$2,
														lineNumber: 348,
														columnNumber: 23
													}, this),
													/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", {
														value: "High",
														children: "High (Response within 4h)"
													}, void 0, false, {
														fileName: _jsxFileName$2,
														lineNumber: 349,
														columnNumber: 23
													}, this),
													/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", {
														value: "Urgent",
														children: "Urgent (Immediate attention)"
													}, void 0, false, {
														fileName: _jsxFileName$2,
														lineNumber: 350,
														columnNumber: 23
													}, this)
												]
											}, void 0, true, {
												fileName: _jsxFileName$2,
												lineNumber: 343,
												columnNumber: 21
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName$2,
											lineNumber: 341,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName$2,
										lineNumber: 323,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "space-y-1",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("label", {
											className: "text-xs font-semibold text-foreground",
											children: "Subject"
										}, void 0, false, {
											fileName: _jsxFileName$2,
											lineNumber: 356,
											columnNumber: 19
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("input", {
											type: "text",
											value: subject,
											onChange: (e) => setSubject(e.target.value),
											required: true,
											placeholder: "e.g. Issue connecting AI roadmap to learning tab",
											className: "w-full rounded-xl border border-input bg-background py-2 px-3 text-xs text-foreground focus:ring-2 focus:ring-ring"
										}, void 0, false, {
											fileName: _jsxFileName$2,
											lineNumber: 357,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName$2,
										lineNumber: 355,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "space-y-1",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("label", {
											className: "text-xs font-semibold text-foreground",
											children: "Detailed Message"
										}, void 0, false, {
											fileName: _jsxFileName$2,
											lineNumber: 368,
											columnNumber: 19
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("textarea", {
											value: message,
											onChange: (e) => setMessage(e.target.value),
											rows: 4,
											required: true,
											placeholder: "Please explain the question or problem in detail...",
											className: "w-full rounded-xl border border-input bg-background p-3 text-xs text-foreground focus:ring-2 focus:ring-ring"
										}, void 0, false, {
											fileName: _jsxFileName$2,
											lineNumber: 369,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName$2,
										lineNumber: 367,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "flex justify-end pt-2",
										children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
											type: "submit",
											className: "flex items-center gap-2 rounded-full bg-ink px-5 py-2 text-xs font-semibold text-ink-foreground transition hover:opacity-90",
											children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Send, { className: "h-3.5 w-3.5" }, void 0, false, {
												fileName: _jsxFileName$2,
												lineNumber: 384,
												columnNumber: 21
											}, this), "Submit Support Ticket"]
										}, void 0, true, {
											fileName: _jsxFileName$2,
											lineNumber: 380,
											columnNumber: 19
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName$2,
										lineNumber: 379,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName$2,
								lineNumber: 301,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName$2,
							lineNumber: 277,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName$2,
					lineNumber: 189,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogFooter, {
					className: "pt-2",
					children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
						type: "button",
						onClick: () => onOpenChange(false),
						className: "rounded-full border border-border px-4 py-1.5 text-xs font-semibold text-muted-foreground hover:bg-muted",
						children: "Close"
					}, void 0, false, {
						fileName: _jsxFileName$2,
						lineNumber: 394,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName$2,
					lineNumber: 393,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName$2,
			lineNumber: 172,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName$2,
		lineNumber: 171,
		columnNumber: 5
	}, this);
}
var _jsxFileName$1 = "/app/applet/src/components/NotificationPopover.tsx";
function NotificationPopover() {
	const notifications = usePathfinder((s) => s).notifications;
	useNavigate();
	const [open, setOpen] = (0, import_react.useState)(false);
	const [filter, setFilter] = (0, import_react.useState)("all");
	const unreadCount = notifications.filter((n) => !n.read).length;
	const displayedNotifications = notifications.filter((n) => {
		if (filter === "unread") return !n.read;
		return true;
	});
	const handleMarkAllRead = () => {
		actions.markAllNotificationsRead();
		toast.success("All notifications marked as read");
	};
	const handleClearAll = () => {
		actions.clearNotifications();
		toast.info("Notification feed cleared");
	};
	const handleItemClick = (item) => {
		if (!item.read) actions.markNotificationRead(item.id);
		if (item.link) {
			setOpen(false);
			window.location.href = item.link;
		}
	};
	const getItemIcon = (type) => {
		switch (type) {
			case "lesson": return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(GraduationCap, { className: "h-4 w-4 text-violet" }, void 0, false, {
				fileName: _jsxFileName$1,
				lineNumber: 56,
				columnNumber: 16
			}, this);
			case "job": return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Briefcase, { className: "h-4 w-4 text-sun" }, void 0, false, {
				fileName: _jsxFileName$1,
				lineNumber: 58,
				columnNumber: 16
			}, this);
			case "interview": return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(MessageCircle, { className: "h-4 w-4 text-pink-500" }, void 0, false, {
				fileName: _jsxFileName$1,
				lineNumber: 60,
				columnNumber: 16
			}, this);
			case "roadmap": return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Sparkles, { className: "h-4 w-4 text-mint" }, void 0, false, {
				fileName: _jsxFileName$1,
				lineNumber: 62,
				columnNumber: 16
			}, this);
			default: return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Bell, { className: "h-4 w-4 text-ink" }, void 0, false, {
				fileName: _jsxFileName$1,
				lineNumber: 65,
				columnNumber: 16
			}, this);
		}
	};
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Popover, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(PopoverTrigger, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
				type: "button",
				"aria-label": `Notifications ${unreadCount > 0 ? `(${unreadCount} unread)` : ""}`,
				className: "relative grid h-9 w-9 place-items-center rounded-full text-foreground/80 transition hover:bg-muted hover:text-foreground focus:outline-none focus:ring-2 focus:ring-ring",
				children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Bell, { className: "h-5 w-5" }, void 0, false, {
					fileName: _jsxFileName$1,
					lineNumber: 77,
					columnNumber: 11
				}, this), unreadCount > 0 && /* @__PURE__ */ (void 0)("span", {
					className: "absolute top-1.5 right-1.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-destructive px-1 text-[9px] font-bold text-destructive-foreground",
					children: unreadCount > 9 ? "9+" : unreadCount
				}, void 0, false, {
					fileName: _jsxFileName$1,
					lineNumber: 79,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName$1,
				lineNumber: 72,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName$1,
			lineNumber: 71,
			columnNumber: 7
		}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(PopoverContent, {
			align: "end",
			sideOffset: 8,
			className: "w-80 sm:w-96 rounded-3xl border-border bg-card p-4 shadow-soft",
			children: [
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "flex items-center justify-between pb-3 border-b border-border/80",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
							className: "text-sm font-bold text-foreground",
							children: "Notifications"
						}, void 0, false, {
							fileName: _jsxFileName$1,
							lineNumber: 94,
							columnNumber: 13
						}, this), unreadCount > 0 && /* @__PURE__ */ (void 0)("span", {
							className: "rounded-full bg-destructive/10 px-2 py-0.5 text-[10px] font-bold text-destructive",
							children: [unreadCount, " new"]
						}, void 0, true, {
							fileName: _jsxFileName$1,
							lineNumber: 96,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName$1,
						lineNumber: 93,
						columnNumber: 11
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "flex items-center gap-2",
						children: [unreadCount > 0 && /* @__PURE__ */ (void 0)("button", {
							type: "button",
							onClick: handleMarkAllRead,
							title: "Mark all as read",
							className: "flex items-center gap-1 text-[11px] font-medium text-muted-foreground hover:text-foreground transition",
							children: [/* @__PURE__ */ (void 0)(CheckCheck, { className: "h-3 w-3" }, void 0, false, {
								fileName: _jsxFileName$1,
								lineNumber: 110,
								columnNumber: 17
							}, this), "Read all"]
						}, void 0, true, {
							fileName: _jsxFileName$1,
							lineNumber: 104,
							columnNumber: 15
						}, this), notifications.length > 0 && /* @__PURE__ */ (void 0)("button", {
							type: "button",
							onClick: handleClearAll,
							title: "Clear all notifications",
							className: "text-muted-foreground hover:text-destructive transition p-1",
							children: /* @__PURE__ */ (void 0)(Trash2, { className: "h-3.5 w-3.5" }, void 0, false, {
								fileName: _jsxFileName$1,
								lineNumber: 121,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName$1,
							lineNumber: 115,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName$1,
						lineNumber: 102,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName$1,
					lineNumber: 92,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "flex gap-2 py-2.5",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
						type: "button",
						onClick: () => setFilter("all"),
						className: `rounded-full px-3 py-1 text-xs font-semibold transition ${filter === "all" ? "bg-ink text-ink-foreground" : "bg-muted text-muted-foreground hover:text-foreground"}`,
						children: [
							"All (",
							notifications.length,
							")"
						]
					}, void 0, true, {
						fileName: _jsxFileName$1,
						lineNumber: 129,
						columnNumber: 11
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
						type: "button",
						onClick: () => setFilter("unread"),
						className: `rounded-full px-3 py-1 text-xs font-semibold transition ${filter === "unread" ? "bg-ink text-ink-foreground" : "bg-muted text-muted-foreground hover:text-foreground"}`,
						children: [
							"Unread (",
							unreadCount,
							")"
						]
					}, void 0, true, {
						fileName: _jsxFileName$1,
						lineNumber: 140,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName$1,
					lineNumber: 128,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "max-h-80 space-y-2 overflow-y-auto pr-1",
					children: displayedNotifications.length > 0 ? displayedNotifications.map((notif) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						onClick: () => handleItemClick(notif),
						className: `group relative flex items-start gap-3 rounded-2xl p-3 text-left transition cursor-pointer ${notif.read ? "bg-background/40 hover:bg-muted/50 text-muted-foreground" : "border border-border/80 bg-muted/30 hover:bg-muted/60 text-foreground"}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "mt-0.5 grid h-7 w-7 shrink-0 place-items-center rounded-xl bg-card shadow-xs",
								children: getItemIcon(notif.type)
							}, void 0, false, {
								fileName: _jsxFileName$1,
								lineNumber: 166,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "min-w-0 flex-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "flex items-center justify-between gap-1",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
											className: `text-xs font-bold truncate ${notif.read ? "text-muted-foreground" : "text-foreground"}`,
											children: notif.title
										}, void 0, false, {
											fileName: _jsxFileName$1,
											lineNumber: 172,
											columnNumber: 21
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
											className: "text-[10px] text-muted-foreground shrink-0",
											children: notif.at
										}, void 0, false, {
											fileName: _jsxFileName$1,
											lineNumber: 177,
											columnNumber: 21
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName$1,
										lineNumber: 171,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
										className: "mt-0.5 text-xs text-muted-foreground line-clamp-2 leading-relaxed",
										children: notif.message
									}, void 0, false, {
										fileName: _jsxFileName$1,
										lineNumber: 179,
										columnNumber: 19
									}, this),
									notif.link && /* @__PURE__ */ (void 0)("span", {
										className: "mt-1.5 inline-flex items-center gap-1 text-[10px] font-semibold text-primary/80 group-hover:text-primary",
										children: ["View details ", /* @__PURE__ */ (void 0)(ExternalLink, { className: "h-2.5 w-2.5" }, void 0, false, {
											fileName: _jsxFileName$1,
											lineNumber: 184,
											columnNumber: 36
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName$1,
										lineNumber: 183,
										columnNumber: 21
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName$1,
								lineNumber: 170,
								columnNumber: 17
							}, this),
							!notif.read && /* @__PURE__ */ (void 0)("span", { className: "mt-1 h-2 w-2 shrink-0 rounded-full bg-violet" }, void 0, false, {
								fileName: _jsxFileName$1,
								lineNumber: 189,
								columnNumber: 33
							}, this)
						]
					}, notif.id, true, {
						fileName: _jsxFileName$1,
						lineNumber: 157,
						columnNumber: 15
					}, this)) : /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "py-8 text-center text-xs text-muted-foreground",
						children: filter === "unread" ? "No unread notifications" : "No notifications yet"
					}, void 0, false, {
						fileName: _jsxFileName$1,
						lineNumber: 193,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName$1,
					lineNumber: 154,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName$1,
			lineNumber: 86,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName$1,
		lineNumber: 70,
		columnNumber: 5
	}, this);
}
var _jsxFileName = "/app/applet/src/components/AppShell.tsx";
var nav = [
	{
		to: "/",
		label: "Dashboard",
		icon: LayoutGrid
	},
	{
		to: "/assistant",
		label: "AI Assistant",
		icon: MessageCircle
	},
	{
		to: "/quest",
		label: "Career Quest",
		icon: Compass
	},
	{
		to: "/roadmap",
		label: "Explore Careers",
		icon: Search
	},
	{
		to: "/skills",
		label: "My Skills",
		icon: Lightbulb
	},
	{
		to: "/jobs",
		label: "Job Board",
		icon: BriefcaseBusiness
	},
	{
		to: "/learning",
		label: "Learning",
		icon: GraduationCap
	},
	{
		to: "/networking",
		label: "Networking",
		icon: Users
	}
];
function AppShell({ children }) {
	const isPro = usePathfinder((s) => s).subscription.plan === "pro";
	const navigate = useNavigate();
	const [profileOpen, setProfileOpen] = (0, import_react.useState)(false);
	const [profileMode, setProfileMode] = (0, import_react.useState)("edit");
	const [settingsOpen, setSettingsOpen] = (0, import_react.useState)(false);
	const [settingsTab, setSettingsTab] = (0, import_react.useState)("account");
	const [upgradeOpen, setUpgradeOpen] = (0, import_react.useState)(false);
	const [supportOpen, setSupportOpen] = (0, import_react.useState)(false);
	const [searchVal, setSearchVal] = (0, import_react.useState)("");
	const handleSearchSubmit = (e) => {
		e.preventDefault();
		if (!searchVal.trim()) return;
		navigate({ to: "/roadmap" });
	};
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
		className: "min-h-screen p-3 md:p-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "mx-auto flex max-w-[1400px] overflow-hidden rounded-3xl bg-background shadow-soft",
				children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("aside", {
					className: "hidden w-60 shrink-0 flex-col bg-sidebar p-5 lg:flex",
					children: [
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "mb-8 flex items-center gap-2 font-bold",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
								className: "grid h-7 w-7 place-items-center rounded-lg bg-ink text-xs text-ink-foreground",
								children: "P"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 68,
								columnNumber: 13
							}, this), "Pathfinder"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 67,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("nav", {
							className: "space-y-1",
							children: nav.map((n, i) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Link, {
								to: n.to,
								activeOptions: { exact: true },
								className: "flex items-center gap-3 rounded-xl px-3 py-2 text-sm text-foreground/80 hover:bg-card/60",
								activeProps: n.to !== "/" || i === 0 ? { className: "bg-card font-semibold text-foreground" } : {},
								children: [
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(n.icon, { className: "h-4 w-4" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 86,
										columnNumber: 17
									}, this),
									" ",
									n.label
								]
							}, i, true, {
								fileName: _jsxFileName,
								lineNumber: 75,
								columnNumber: 15
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 73,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "relative mt-auto rounded-2xl bg-card/70 p-4 pt-20 text-center",
							children: [
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("img", {
									src: shapes_default,
									alt: "",
									width: 816,
									height: 816,
									loading: "lazy",
									className: "absolute -top-10 left-1/2 w-32 -translate-x-1/2 pointer-events-none"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 91,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
									className: "font-bold flex items-center justify-center gap-1.5",
									children: isPro ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(import_jsx_dev_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Crown, { className: "h-4 w-4 text-sun" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 102,
										columnNumber: 19
									}, this), "Pathfinder Pro"] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 101,
										columnNumber: 17
									}, this) : "Upgrade to Pro"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 99,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
									className: "mt-1 text-xs text-muted-foreground",
									children: isPro ? "Unlimited mock interviews and roadmaps" : "Unlock mock interviews and AI roadmaps"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 109,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
									className: `mt-2 inline-block rounded-full px-2 py-0.5 text-[10px] font-semibold ${isPro ? "bg-mint/40 text-foreground" : "bg-butter"}`,
									children: isPro ? "Active Membership" : "Free for 1 month"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 114,
									columnNumber: 13
								}, this),
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
									type: "button",
									onClick: () => setUpgradeOpen(true),
									className: "mt-3 w-full rounded-full bg-ink py-2 text-xs font-semibold text-ink-foreground transition hover:opacity-90 cursor-pointer",
									children: isPro ? "Manage Plan" : "Upgrade now"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 119,
									columnNumber: 13
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 90,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "mt-5 space-y-1 text-sm text-foreground/80",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
								type: "button",
								onClick: () => setSupportOpen(true),
								className: "flex w-full items-center gap-3 rounded-xl px-3 py-2 text-left text-sm text-foreground/80 hover:bg-card/60 transition cursor-pointer",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(LifeBuoy, { className: "h-4 w-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 133,
									columnNumber: 15
								}, this), " Support Center"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 128,
								columnNumber: 13
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
								type: "button",
								onClick: () => {
									setSettingsTab("account");
									setSettingsOpen(true);
								},
								className: "flex w-full items-center gap-3 rounded-xl px-3 py-2 text-left text-sm text-foreground/80 hover:bg-card/60 transition cursor-pointer",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Settings, { className: "h-4 w-4" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 143,
									columnNumber: 15
								}, this), " Settings"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 135,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 127,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 66,
					columnNumber: 9
				}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("main", {
					className: "min-w-0 flex-1 p-5 md:p-7",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("header", {
						className: "mb-6 flex items-center gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("form", {
								onSubmit: handleSearchSubmit,
								className: "flex w-full max-w-xs items-center gap-2 rounded-full bg-muted px-4 py-1.5 text-sm text-muted-foreground focus-within:ring-2 focus-within:ring-ring",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Search, { className: "h-4 w-4 shrink-0" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 153,
									columnNumber: 15
								}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("input", {
									type: "text",
									value: searchVal,
									onChange: (e) => setSearchVal(e.target.value),
									placeholder: "Search careers, skills…",
									className: "w-full bg-transparent text-xs text-foreground placeholder:text-muted-foreground focus:outline-none"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 154,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 149,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Link, {
								to: "/assistant",
								className: "ai-ring flex items-center gap-1.5 rounded-full px-4 py-1.5 text-xs font-semibold",
								children: ["AI Assistant ", /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Sparkles, { className: "h-3.5 w-3.5" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 166,
									columnNumber: 28
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 162,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "ml-auto flex items-center gap-3 sm:gap-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(ThemeToggle, {}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 169,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(NotificationPopover, {}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 170,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(ProfileDropdown, {
										onOpenEditProfile: () => {
											setProfileMode("edit");
											setProfileOpen(true);
										},
										onOpenSettings: (tab) => {
											setSettingsTab(tab || "account");
											setSettingsOpen(true);
										},
										onOpenUpgrade: () => setUpgradeOpen(true)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 171,
										columnNumber: 15
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 168,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 148,
						columnNumber: 11
					}, this), children]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 147,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 65,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(ProfileModal, {
				open: profileOpen,
				onOpenChange: setProfileOpen,
				mode: profileMode
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 189,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(SettingsModal, {
				open: settingsOpen,
				onOpenChange: setSettingsOpen,
				defaultTab: settingsTab
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 190,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(UpgradeProModal, {
				open: upgradeOpen,
				onOpenChange: setUpgradeOpen
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 191,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(SupportCenterModal, {
				open: supportOpen,
				onOpenChange: setSupportOpen
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 192,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 64,
		columnNumber: 5
	}, this);
}
function ThemeToggle() {
	const [mode, setMode] = (0, import_react.useState)("light");
	(0, import_react.useEffect)(() => {
		const saved = getSavedMode();
		setMode(saved);
		applyMode(saved);
	}, []);
	const next = () => {
		const m = modes[(modes.indexOf(mode) + 1) % modes.length];
		setMode(m);
		setSavedMode(m);
	};
	const Icon = mode === "light" ? Sun : mode === "dark" ? Moon : MoonStar;
	const label = mode === "light" ? "Light mode" : mode === "dark" ? "Dark mode" : "Night mode";
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
		onClick: next,
		"aria-label": `${label} – click to switch`,
		title: label,
		className: "flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-medium transition hover:bg-muted cursor-pointer",
		children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Icon, { className: "h-4 w-4" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 220,
			columnNumber: 7
		}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
			className: "hidden sm:inline",
			children: label.replace(" mode", "")
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 221,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 214,
		columnNumber: 5
	}, this);
}
//#endregion
export { DialogDescription as a, DialogTitle as c, readiness as d, usePathfinder as f, DialogContent as i, actions as l, AppShell as n, DialogFooter as o, Dialog as r, DialogHeader as s, APP_STATUSES as t, cn as u };
