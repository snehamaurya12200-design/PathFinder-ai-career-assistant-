import { a as TSS_SERVER_FUNCTION, l as createServerFn } from "./createServerFn-DDDJMFWM.mjs";
import { a as objectType, c as unionType, i as numberType, n as arrayType, o as recordType, r as enumType, s as stringType, t as anyType } from "../_libs/zod.mjs";
import { t as getServerFnById } from "../__23tanstack-start-server-fn-resolver-DatHn2cg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ai.functions-u7pgug8o.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
/**
* Resilient multi-model execution helper.
* Tries the primary model first, and automatically falls back to secondary models
* if a 503 (high demand) or 429 (rate-limit) or 404 (unavailable) occurs.
*/
var LegacyInput = objectType({
	system: stringType().max(4e3),
	messages: arrayType(objectType({
		role: enumType(["user", "assistant"]),
		content: stringType().max(6e3)
	})).max(40)
});
createServerFn({ method: "POST" }).validator((d) => LegacyInput.parse(d)).handler(createSsrRpc("e6ce4f300af1ec33e34c8b840a63975ac94b41ab18b9a6fbe88567a0e0ab07f8"));
var CareerAgentInput = objectType({
	message: stringType(),
	history: arrayType(objectType({
		role: enumType(["user", "assistant"]),
		content: stringType()
	})).optional(),
	userState: objectType({
		name: stringType().optional(),
		email: stringType().optional(),
		education: stringType().optional(),
		educationLevel: stringType().optional(),
		stream: stringType().optional(),
		headline: stringType().optional(),
		goal: stringType().optional(),
		skills: recordType(stringType(), numberType()).optional(),
		enrolledCourses: arrayType(stringType()).optional(),
		lessonsDone: numberType().optional(),
		hours: numberType().optional(),
		cvName: stringType().optional(),
		recentTests: arrayType(anyType()).optional(),
		recentInterviews: arrayType(anyType()).optional()
	}).optional()
});
var askCareerAgent = createServerFn({ method: "POST" }).validator((d) => CareerAgentInput.parse(d)).handler(createSsrRpc("7e60424a563255576b8b72325f1f02b95839e31de0c6d4492cc2913b3e9c6b28"));
var ResumeInput = objectType({
	fileName: stringType(),
	content: stringType(),
	targetGoal: stringType()
});
var analyzeResumeWithGemini = createServerFn({ method: "POST" }).validator((d) => ResumeInput.parse(d)).handler(createSsrRpc("d8df0d55df6c0abc614da7327152fbc6cf79e14660b6a8f13f17d30eb1105087"));
var InterviewInput = objectType({
	role: stringType(),
	difficulty: stringType(),
	question: stringType(),
	answer: stringType(),
	questionIndex: numberType().optional(),
	totalQuestions: numberType().optional()
});
var evaluateInterviewAnswerWithGemini = createServerFn({ method: "POST" }).validator((d) => InterviewInput.parse(d)).handler(createSsrRpc("b2b7569ca2546f51b50ed2bfd387f09682c66cec60c9f7c96653a733572f5284"));
var SpeechInput = objectType({
	text: stringType().max(2e3),
	voiceName: enumType([
		"Kore",
		"Puck",
		"Charon",
		"Fenrir",
		"Zephyr"
	]).optional()
});
var generateSpeechWithGemini = createServerFn({ method: "POST" }).validator((d) => SpeechInput.parse(d)).handler(createSsrRpc("8722e721790036e6e7cfbbc3765dca67b79ddebd93eb3167cc013af62e44763f"));
var TranscribeInput = objectType({
	audioBase64: stringType(),
	mimeType: stringType().default("audio/webm")
});
var transcribeAudioWithGemini = createServerFn({ method: "POST" }).validator((d) => TranscribeInput.parse(d)).handler(createSsrRpc("21e1b168e48fee00ded8bd5b752b49b1d7de7ee8e4f60ea24ef9d42f4a38a13a"));
var AdaptiveInput = objectType({
	stage: stringType(),
	fieldOrSubject: stringType().optional(),
	interests: stringType().optional(),
	coreAnswers: recordType(unionType([stringType(), arrayType(stringType())]))
});
var generateAdaptiveQuestionsServerFn = createServerFn({ method: "POST" }).validator((d) => AdaptiveInput.parse(d)).handler(createSsrRpc("af1d061b0d5fd75ac3de46046d9ed46f397d9952ef23f60adbe0cc2539e37a3a"));
var CareerDNASynthesisInput = objectType({
	context: objectType({
		stage: stringType(),
		fieldOrSubject: stringType().optional(),
		interests: stringType().optional(),
		region: stringType().optional()
	}),
	coreAnswers: recordType(unionType([stringType(), arrayType(stringType())])),
	adaptiveAnswers: recordType(stringType()).optional(),
	version: numberType().optional().default(1)
});
var generateCareerDNAServerFn = createServerFn({ method: "POST" }).validator((d) => CareerDNASynthesisInput.parse(d)).handler(createSsrRpc("5bd1b30cc7ecf721d44c1d8749203b62b5c0b8dd23c8415268b76adb7954aa1e"));
//#endregion
export { generateCareerDNAServerFn as a, generateAdaptiveQuestionsServerFn as i, askCareerAgent as n, generateSpeechWithGemini as o, evaluateInterviewAnswerWithGemini as r, transcribeAudioWithGemini as s, analyzeResumeWithGemini as t };
