//#region node_modules/.nitro/vite/services/ssr/assets/pathfinder-data-LKyDtySq.js
var ALL_EDUCATION_LEVELS = [
	"Class 10",
	"Class 11",
	"Class 12",
	"Diploma",
	"Undergraduate",
	"Postgraduate",
	"PhD / Research",
	"Competitive Exams",
	"Working Professional"
];
var ALL_ACADEMIC_STREAMS = [
	"Computer Science & IT",
	"AI & Emerging Tech",
	"Science (PCM)",
	"Science (PCB)",
	"Medical & Healthcare",
	"Commerce & Finance",
	"Management & Business",
	"Law & Civil Services",
	"Arts & Humanities",
	"Design & Creative Arts",
	"Engineering (Core)",
	"Essential & Soft Skills"
];
var ALL_COURSES = [
	{
		id: "ai-fundamentals",
		title: "Artificial Intelligence Fundamentals",
		desc: "Core principles of search algorithms, heuristic evaluation, and knowledge representation.",
		duration: "10 hours",
		lessons: 12,
		level: "Beginner",
		skills: [
			"Artificial Intelligence",
			"Problem Solving",
			"Logic"
		],
		goals: ["AI / Machine Learning Specialist", "Full Stack Engineer"],
		bg: "bg-lilac",
		category: "Artificial Intelligence",
		stream: "AI & Emerging Tech",
		educationLevels: [
			"Undergraduate",
			"Postgraduate",
			"Working Professional"
		],
		provider: "MIT OpenCourseWare",
		format: "Self-paced video",
		pricing: "Free",
		url: "https://ocw.mit.edu/courses/6-034-artificial-intelligence-fall-2010/",
		syllabus: [
			"Introduction to Search & State Spaces",
			"Heuristic Search & A* Algorithm",
			"Adversarial Search & Game Playing",
			"Constraint Satisfaction Problems",
			"Knowledge Representation & Logic"
		]
	},
	{
		id: "genai-prompt-eng",
		title: "Generative AI & Prompt Engineering",
		desc: "Master large language models, prompt patterns, few-shot conditioning, and chain-of-thought.",
		duration: "6 hours",
		lessons: 8,
		level: "Beginner",
		skills: [
			"Prompt Engineering",
			"Generative AI",
			"LLM Systems"
		],
		goals: [
			"AI / Machine Learning Specialist",
			"Frontend Developer",
			"Data Analyst"
		],
		bg: "bg-mint",
		category: "Artificial Intelligence",
		stream: "AI & Emerging Tech",
		educationLevels: [
			"Undergraduate",
			"Postgraduate",
			"Working Professional",
			"Competitive Exams"
		],
		provider: "DeepLearning.AI",
		format: "Interactive hands-on",
		pricing: "Free to audit",
		url: "https://www.deeplearning.ai/short-courses/chatgpt-prompt-engineering-for-developers/",
		syllabus: [
			"LLM Architecture & Tokenization Basics",
			"Principles of Clear Prompt Construction",
			"Delimiters & Structured JSON Outputs",
			"Chain-of-Thought & Iterative Refinement",
			"Mitigating Hallucinations in Production"
		]
	},
	{
		id: "ml-python-stanford",
		title: "Machine Learning with Python",
		desc: "Supervised and unsupervised learning, gradient descent, regularisation, and model evaluation.",
		duration: "14 hours",
		lessons: 16,
		level: "Intermediate",
		skills: [
			"Machine Learning",
			"Python",
			"Data Modeling"
		],
		goals: ["AI / Machine Learning Specialist", "Data Analyst"],
		bg: "bg-butter",
		category: "Artificial Intelligence",
		stream: "AI & Emerging Tech",
		educationLevels: [
			"Undergraduate",
			"Postgraduate",
			"Working Professional"
		],
		provider: "Stanford Online",
		format: "Structured course",
		pricing: "Free to audit",
		url: "https://online.stanford.edu/courses/soe-ymcs0001-machine-learning",
		syllabus: [
			"Linear Regression & Gradient Descent",
			"Logistic Regression for Classification",
			"Overfitting & L1/L2 Regularisation",
			"Support Vector Machines & Kernels",
			"Clustering with K-Means & PCA"
		]
	},
	{
		id: "deep-learning-specialization",
		title: "Deep Learning & Neural Networks",
		desc: "Build deep neural networks, backpropagation, hyperparameter tuning, and optimisation algorithms.",
		duration: "16 hours",
		lessons: 18,
		level: "Intermediate",
		skills: [
			"Deep Learning",
			"Neural Networks",
			"TensorFlow"
		],
		goals: ["AI / Machine Learning Specialist"],
		bg: "bg-blush",
		category: "Artificial Intelligence",
		stream: "AI & Emerging Tech",
		educationLevels: [
			"Undergraduate",
			"Postgraduate",
			"PhD / Research"
		],
		provider: "Coursera / DeepLearning.AI",
		format: "Project-based",
		pricing: "Free to audit",
		url: "https://www.coursera.org/specializations/deep-learning",
		syllabus: [
			"Feedforward Neural Network Math",
			"Matrix Vectorization & Activation Functions",
			"Adam, RMSProp & Momentum Optimizers",
			"Batch Normalization & Dropout",
			"Multi-class Softmax Implementation"
		]
	},
	{
		id: "nlp-transformers",
		title: "Natural Language Processing with Transformers",
		desc: "Attention mechanisms, BERT, GPT architectures, fine-tuning, and semantic embeddings.",
		duration: "12 hours",
		lessons: 14,
		level: "Advanced",
		skills: [
			"NLP",
			"Transformers",
			"Python"
		],
		goals: ["AI / Machine Learning Specialist"],
		bg: "bg-lilac",
		category: "Artificial Intelligence",
		stream: "AI & Emerging Tech",
		educationLevels: [
			"Postgraduate",
			"PhD / Research",
			"Working Professional"
		],
		provider: "Stanford Online",
		format: "Structured course",
		pricing: "Free",
		url: "https://web.stanford.edu/class/cs224n/",
		syllabus: [
			"Word Embeddings (Word2Vec & GloVe)",
			"Recurrent Networks vs Self-Attention",
			"The Transformer Encoder-Decoder",
			"BERT Masked Language Models",
			"Fine-tuning on Hugging Face Datasets"
		]
	},
	{
		id: "computer-vision-essentials",
		title: "Computer Vision & Image Processing",
		desc: "Convolutional neural networks, object detection (YOLO), segmentation, and OpenCV fundamentals.",
		duration: "11 hours",
		lessons: 13,
		level: "Intermediate",
		skills: [
			"Computer Vision",
			"OpenCV",
			"Deep Learning"
		],
		goals: ["AI / Machine Learning Specialist"],
		bg: "bg-mint",
		category: "Artificial Intelligence",
		stream: "AI & Emerging Tech",
		educationLevels: [
			"Undergraduate",
			"Postgraduate",
			"Working Professional"
		],
		provider: "edX / IBM",
		format: "Interactive hands-on",
		pricing: "Free to audit",
		url: "https://www.edx.org/learn/computer-vision",
		syllabus: [
			"Digital Image Representation & Filtering",
			"Edge Detection & Feature Extraction",
			"Convolutional Networks for Classification",
			"Bounding Box Regression & YOLO Architecture",
			"Image Segmentation with U-Net"
		]
	},
	{
		id: "applied-datascience-pandas",
		title: "Applied Data Science with Pandas & NumPy",
		desc: "Clean messy tabular data, perform exploratory analysis, handle missing values, and visualize trends.",
		duration: "9 hours",
		lessons: 11,
		level: "Beginner",
		skills: [
			"Data Analysis",
			"Python",
			"Data Structures"
		],
		goals: ["Data Analyst", "AI / Machine Learning Specialist"],
		bg: "bg-butter",
		category: "Artificial Intelligence",
		stream: "Computer Science & IT",
		educationLevels: [
			"Undergraduate",
			"Diploma",
			"Working Professional",
			"Competitive Exams"
		],
		provider: "freeCodeCamp",
		format: "Project-based",
		pricing: "Free",
		url: "https://www.freecodecamp.org/learn/data-analysis-with-python/",
		syllabus: [
			"NumPy Multi-dimensional Arrays",
			"Pandas Series & DataFrames",
			"Data Cleaning & GroupBy Aggregations",
			"Time-Series Data & Pivot Tables",
			"Matplotlib & Seaborn Visualizations"
		]
	},
	{
		id: "reinforcement-learning-nptel",
		title: "Reinforcement Learning & Decision Making",
		desc: "Markov Decision Processes, Q-learning, Policy Gradients, and multi-agent gaming algorithms.",
		duration: "15 hours",
		lessons: 16,
		level: "Advanced",
		skills: [
			"Reinforcement Learning",
			"Mathematics",
			"Python"
		],
		goals: ["AI / Machine Learning Specialist", "Academic Researcher"],
		bg: "bg-blush",
		category: "Artificial Intelligence",
		stream: "AI & Emerging Tech",
		educationLevels: ["Postgraduate", "PhD / Research"],
		provider: "NPTEL / IIT Madras",
		format: "Structured course",
		pricing: "Free",
		url: "https://nptel.ac.in/courses/106106198",
		syllabus: [
			"Markov Decision Processes & Bellman Equations",
			"Dynamic Programming & Value Iteration",
			"Monte Carlo Methods & Temporal Difference",
			"Deep Q-Networks (DQN)",
			"Policy Gradient Methods & Actor-Critic"
		]
	},
	{
		id: "responsible-ai-ethics",
		title: "Responsible AI, Safety & Algorithmic Ethics",
		desc: "Combat bias in training data, ensure privacy compliance, implement explainability, and governance.",
		duration: "5 hours",
		lessons: 7,
		level: "Beginner",
		skills: [
			"AI Ethics",
			"Critical Thinking",
			"Governance"
		],
		goals: [
			"AI / Machine Learning Specialist",
			"Legal Specialist / Corporate Lawyer",
			"Business & Marketing Specialist"
		],
		bg: "bg-lilac",
		category: "Artificial Intelligence",
		stream: "AI & Emerging Tech",
		educationLevels: [
			"Undergraduate",
			"Postgraduate",
			"Working Professional"
		],
		provider: "Google Cloud Skills",
		format: "Self-paced video",
		pricing: "Free",
		url: "https://cloud.google.com/training",
		syllabus: [
			"Identifying Bias in Datasets & Models",
			"Fairness Metrics & Mitigation Strategies",
			"Explainable AI (SHAP & LIME)",
			"Data Privacy & Regulatory Frameworks",
			"Human-in-the-Loop Safeguards"
		]
	},
	{
		id: "edge-ai-iot",
		title: "Embedded Machine Learning & TinyML",
		desc: "Deploy neural networks on low-power microcontrollers and edge hardware with TensorFlow Lite.",
		duration: "10 hours",
		lessons: 12,
		level: "Intermediate",
		skills: [
			"Embedded Systems",
			"Edge AI",
			"C++"
		],
		goals: ["AI / Machine Learning Specialist", "Full Stack Engineer"],
		bg: "bg-mint",
		category: "Artificial Intelligence",
		stream: "Engineering (Core)",
		educationLevels: [
			"Undergraduate",
			"Diploma",
			"Working Professional"
		],
		provider: "Harvard Online / edX",
		format: "Interactive hands-on",
		pricing: "Free to audit",
		url: "https://www.edx.org/course/fundamentals-of-tinyml",
		syllabus: [
			"Microcontroller Constraints & Sensors",
			"Quantization & Model Pruning",
			"TensorFlow Lite for Microcontrollers",
			"Keyword Spotting on Audio Streams",
			"Gesture Recognition with Accelerometers"
		]
	},
	{
		id: "big-data-spark",
		title: "Big Data Processing with Apache Spark",
		desc: "Distributed compute, Resilient Distributed Datasets (RDDs), Spark SQL, and streaming pipelines.",
		duration: "12 hours",
		lessons: 14,
		level: "Intermediate",
		skills: [
			"Big Data",
			"Apache Spark",
			"Data Engineering"
		],
		goals: ["Data Analyst", "Full Stack Engineer"],
		bg: "bg-butter",
		category: "Artificial Intelligence",
		stream: "Computer Science & IT",
		educationLevels: [
			"Undergraduate",
			"Postgraduate",
			"Working Professional"
		],
		provider: "edX / IBM",
		format: "Project-based",
		pricing: "Free to audit",
		url: "https://www.edx.org/learn/apache-spark",
		syllabus: [
			"Distributed Systems Architecture",
			"Spark RDDs & Lazy Evaluation",
			"Spark DataFrames & SQL Optimizations",
			"Structured Streaming with Kafka",
			"Cluster Deployment & Memory Tuning"
		]
	},
	{
		id: "neural-nets-from-scratch",
		title: "Neural Networks from Scratch in Python",
		desc: "Build forward passes, backprop, matrix multiplications, and optimizers using pure NumPy.",
		duration: "8 hours",
		lessons: 10,
		level: "Intermediate",
		skills: [
			"Python",
			"Mathematics",
			"Deep Learning"
		],
		goals: ["AI / Machine Learning Specialist"],
		bg: "bg-blush",
		category: "Artificial Intelligence",
		stream: "AI & Emerging Tech",
		educationLevels: ["Undergraduate", "Postgraduate"],
		provider: "freeCodeCamp",
		format: "Interactive hands-on",
		pricing: "Free",
		url: "https://www.freecodecamp.org/news/neural-networks-from-scratch/",
		syllabus: [
			"Dot Products & Layer Implementations",
			"Derivatives & Chain Rule Calculus",
			"Categorical Cross-Entropy Loss",
			"Backpropagation through Dense Layers",
			"Training a Classifier on MNIST"
		]
	},
	{
		id: "cs50x-harvard",
		title: "CS50: Introduction to Computer Science",
		desc: "Harvard University's flagship entry into algorithmic thinking, C, memory management, and web stacks.",
		duration: "20 hours",
		lessons: 22,
		level: "Beginner",
		skills: [
			"Computer Science",
			"C",
			"Algorithms"
		],
		goals: [
			"Full Stack Engineer",
			"Frontend Developer",
			"Data Analyst"
		],
		bg: "bg-lilac",
		category: "Software Development",
		stream: "Computer Science & IT",
		educationLevels: [
			"Class 11",
			"Class 12",
			"Diploma",
			"Undergraduate",
			"Working Professional"
		],
		provider: "Harvard Online",
		format: "Self-paced video",
		pricing: "Free",
		url: "https://cs50.harvard.edu/x/",
		syllabus: [
			"Computational Thinking & Scratch",
			"C Language, Types & Loops",
			"Pointers & Dynamic Memory Allocation",
			"Data Structures: Stacks, Queues, Trees",
			"Web Technologies: Flask, HTML & SQL"
		]
	},
	{
		id: "react-pro",
		title: "React Pro: Modern Patterns & State Architecture",
		desc: "Hooks, compound components, concurrent rendering, and high-performance frontend state patterns.",
		duration: "6 hours",
		lessons: 7,
		level: "Intermediate",
		skills: [
			"React",
			"Frontend",
			"JavaScript"
		],
		goals: ["Frontend Developer", "Full Stack Engineer"],
		bg: "bg-blush",
		category: "Software Development",
		stream: "Computer Science & IT",
		educationLevels: [
			"Undergraduate",
			"Diploma",
			"Working Professional"
		],
		provider: "Pathfinder / Frontend Track",
		format: "Project-based",
		pricing: "Free",
		url: "https://react.dev/learn",
		syllabus: [
			"Advanced useEffect & Custom Hook Abstractions",
			"Context vs External Store Subscriptions",
			"Compound Components & Polymorphic Props",
			"Performance Optimization with useMemo & Profiler",
			"Error Boundaries & Suspense Architecture"
		]
	},
	{
		id: "web-foundations",
		title: "Web Foundations: HTML5, Modern CSS & JS",
		desc: "Semantic markup, modern flexbox/grid layouts, responsive media queries, and Vanilla JS DOM.",
		duration: "10 hours",
		lessons: 12,
		level: "Beginner",
		skills: [
			"Frontend",
			"JavaScript",
			"Visual Design"
		],
		goals: ["Frontend Developer", "UI/UX Designer"],
		bg: "bg-lilac",
		category: "Software Development",
		stream: "Computer Science & IT",
		educationLevels: [
			"Class 10",
			"Class 11",
			"Class 12",
			"Diploma",
			"Undergraduate"
		],
		provider: "freeCodeCamp",
		format: "Interactive hands-on",
		pricing: "Free",
		url: "https://www.freecodecamp.org/learn/responsive-web-design/",
		syllabus: [
			"Semantic HTML5 & Accessibility Essentials",
			"CSS Box Model, Flexbox & CSS Grid",
			"Responsive Media Queries & Fluid Units",
			"JavaScript DOM Manipulation & Events",
			"Asynchronous Fetch & REST APIs"
		]
	},
	{
		id: "dsa-princeton",
		title: "Algorithms & Data Structures in Java",
		desc: "Elementary data structures, sorting algorithms, priority queues, binary search trees, and graphs.",
		duration: "16 hours",
		lessons: 18,
		level: "Intermediate",
		skills: [
			"Data Structures",
			"Algorithms",
			"Java"
		],
		goals: ["Full Stack Engineer", "Frontend Developer"],
		bg: "bg-mint",
		category: "Software Development",
		stream: "Computer Science & IT",
		educationLevels: [
			"Undergraduate",
			"Postgraduate",
			"Competitive Exams"
		],
		provider: "Princeton University / Coursera",
		format: "Structured course",
		pricing: "Free to audit",
		url: "https://www.coursera.org/learn/algorithms-part1",
		syllabus: [
			"Union-Find & Asymptotic Analysis",
			"Quicksort, Mergesort & Dual-Pivot Algorithms",
			"Heaps & Priority Queues",
			"Balanced Search Trees (Red-Black Trees)",
			"Graph Traversal (DFS, BFS & Dijkstra)"
		]
	},
	{
		id: "nodejs-backend-scale",
		title: "Backend Development with Node.js & Express",
		desc: "RESTful API engineering, middleware architecture, JWT authentication, and database clustering.",
		duration: "11 hours",
		lessons: 13,
		level: "Intermediate",
		skills: [
			"Backend",
			"JavaScript",
			"APIs"
		],
		goals: ["Full Stack Engineer"],
		bg: "bg-butter",
		category: "Software Development",
		stream: "Computer Science & IT",
		educationLevels: [
			"Undergraduate",
			"Diploma",
			"Working Professional"
		],
		provider: "freeCodeCamp",
		format: "Project-based",
		pricing: "Free",
		url: "https://www.freecodecamp.org/learn/back-end-development-and-apis/",
		syllabus: [
			"Node.js Event Loop & Non-Blocking I/O",
			"Express Routing & Middleware Chaining",
			"JWT Authentication & Password Hashing",
			"Connecting MongoDB & PostgreSQL",
			"Rate Limiting, CORS & Error Handling"
		]
	},
	{
		id: "typescript-essentials",
		title: "TypeScript Essentials & Type Systems",
		desc: "Type inference, interfaces, union discrimination, generics, keyof operators, and React typing.",
		duration: "5 hours",
		lessons: 8,
		level: "Intermediate",
		skills: [
			"TypeScript",
			"Frontend",
			"JavaScript"
		],
		goals: ["Frontend Developer", "Full Stack Engineer"],
		bg: "bg-mint",
		category: "Software Development",
		stream: "Computer Science & IT",
		educationLevels: ["Undergraduate", "Working Professional"],
		provider: "Microsoft Learn",
		format: "Interactive hands-on",
		pricing: "Free",
		url: "https://learn.microsoft.com/en-us/training/modules/typescript-get-started/",
		syllabus: [
			"Primitives, Interfaces & Type Aliases",
			"Union Types & Discriminated Unions",
			"Generic Functions & Generic Constraints",
			"Utility Types (Partial, Pick, Omit, Record)",
			"Typing Complex React Components & Hooks"
		]
	},
	{
		id: "sql-perf-stanford",
		title: "Relational Databases & SQL Optimization",
		desc: "Relational algebra, normalization (1NF-3NF), indexing strategies, query execution plans, and ACID.",
		duration: "8 hours",
		lessons: 10,
		level: "Beginner",
		skills: [
			"SQL",
			"Databases",
			"Data Modeling"
		],
		goals: ["Data Analyst", "Full Stack Engineer"],
		bg: "bg-lilac",
		category: "Software Development",
		stream: "Computer Science & IT",
		educationLevels: [
			"Undergraduate",
			"Diploma",
			"Working Professional",
			"Competitive Exams"
		],
		provider: "Stanford Online",
		format: "Self-paced video",
		pricing: "Free",
		url: "https://online.stanford.edu/courses/soe-ydatabases-databases-relational-databases-and-sql",
		syllabus: [
			"Relational Schema Design & Primary Keys",
			"Complex Multi-Table Joins & Subqueries",
			"B-Tree vs Hash Indexes",
			"EXPLAIN ANALYZE & Query Optimization",
			"ACID Transactions & Isolation Levels"
		]
	},
	{
		id: "python-for-everybody",
		title: "Python for Everybody: Programming Fundamentals",
		desc: "Variables, conditional logic, loops, file handling, dictionaries, tuples, and scraping web data.",
		duration: "9 hours",
		lessons: 12,
		level: "Beginner",
		skills: [
			"Python",
			"Algorithms",
			"Problem Solving"
		],
		goals: [
			"Data Analyst",
			"Full Stack Engineer",
			"AI / Machine Learning Specialist"
		],
		bg: "bg-butter",
		category: "Software Development",
		stream: "Computer Science & IT",
		educationLevels: [
			"Class 10",
			"Class 11",
			"Class 12",
			"Undergraduate",
			"Working Professional"
		],
		provider: "University of Michigan / Coursera",
		format: "Self-paced video",
		pricing: "Free to audit",
		url: "https://www.py4e.com/",
		syllabus: [
			"Installing Python & Writing Your First Script",
			"Functions, Scopes & Conditional Execution",
			"Iteration, While Loops & List Comprehensions",
			"Working with Files, JSON & APIs",
			"Object-Oriented Programming Basics"
		]
	},
	{
		id: "system-design-distributed",
		title: "System Design for High Scale Applications",
		desc: "Load balancers, caching tiers, database sharding, message queues, and microservice resiliency.",
		duration: "10 hours",
		lessons: 12,
		level: "Advanced",
		skills: [
			"System Design",
			"Architecture",
			"Scalability"
		],
		goals: ["Full Stack Engineer"],
		bg: "bg-blush",
		category: "Software Development",
		stream: "Computer Science & IT",
		educationLevels: [
			"Undergraduate",
			"Postgraduate",
			"Working Professional"
		],
		provider: "Pathfinder / Engineering Track",
		format: "Project-based",
		pricing: "Free",
		url: "https://github.com/donnemartin/system-design-primer",
		syllabus: [
			"CAP Theorem & Consistency Models",
			"Reverse Proxies & Load Balancing Algorithms",
			"Redis Caching Strategies & Eviction Policies",
			"Message Queues (Kafka & RabbitMQ)",
			"Horizontal Sharding & Microservice Design"
		]
	},
	{
		id: "git-devops-cloud",
		title: "Git, CI/CD & DevOps Automation",
		desc: "Version control branching strategies, GitHub Actions, Docker containerization, and automated deployments.",
		duration: "6 hours",
		lessons: 8,
		level: "Intermediate",
		skills: [
			"DevOps",
			"Git",
			"Docker"
		],
		goals: ["Full Stack Engineer", "Frontend Developer"],
		bg: "bg-mint",
		category: "Software Development",
		stream: "Computer Science & IT",
		educationLevels: [
			"Undergraduate",
			"Diploma",
			"Working Professional"
		],
		provider: "Google Cloud / Coursera",
		format: "Interactive hands-on",
		pricing: "Free to audit",
		url: "https://grow.google/certificates/",
		syllabus: [
			"Git Branching, Rebasing & Merge Conflict Resolution",
			"GitHub Actions & Continuous Integration Workflows",
			"Dockerizing Web Applications",
			"Container Orchestration & Cloud Run Deployment",
			"Environment Variables & Secret Management"
		]
	},
	{
		id: "rust-programming",
		title: "Rust Programming & Memory Safety",
		desc: "Ownership, borrowing, lifetimes, pattern matching, error handling, and memory safe concurrency.",
		duration: "12 hours",
		lessons: 14,
		level: "Intermediate",
		skills: [
			"Rust",
			"Systems Programming",
			"Memory Safety"
		],
		goals: ["Full Stack Engineer"],
		bg: "bg-butter",
		category: "Software Development",
		stream: "Computer Science & IT",
		educationLevels: [
			"Undergraduate",
			"Postgraduate",
			"Working Professional"
		],
		provider: "Rust Foundation / edX",
		format: "Project-based",
		pricing: "Free",
		url: "https://doc.rust-lang.org/book/",
		syllabus: [
			"The Ownership & Borrowing System",
			"Structs, Enums & Pattern Matching",
			"Error Handling with Result and Option",
			"Lifetimes and Trait Bounds",
			"Concurrency without Data Races"
		]
	},
	{
		id: "flutter-mobile-dev",
		title: "Cross-Platform Mobile Apps with Flutter",
		desc: "Dart language syntax, widget tree composition, state management (Bloc/Provider), and native APIs.",
		duration: "10 hours",
		lessons: 12,
		level: "Intermediate",
		skills: [
			"Flutter",
			"Mobile Development",
			"Dart"
		],
		goals: ["Frontend Developer", "Full Stack Engineer"],
		bg: "bg-lilac",
		category: "Software Development",
		stream: "Computer Science & IT",
		educationLevels: [
			"Undergraduate",
			"Diploma",
			"Working Professional"
		],
		provider: "Google Developers",
		format: "Project-based",
		pricing: "Free",
		url: "https://flutter.dev/learn",
		syllabus: [
			"Dart Fundamentals & Object Models",
			"Stateless vs Stateful Widgets",
			"Navigation 2.0 & Routing Patterns",
			"State Management with Provider & Riverpod",
			"Publishing to Android & iOS App Stores"
		]
	},
	{
		id: "uiux-calarts",
		title: "UI/UX Design Fundamentals",
		desc: "Design process from user need analysis, wireframing, and information architecture to interactive prototypes.",
		duration: "8 hours",
		lessons: 10,
		level: "Beginner",
		skills: [
			"Visual Design",
			"User Research",
			"Interaction Design"
		],
		goals: ["UI/UX Designer"],
		bg: "bg-butter",
		category: "Design & Media",
		stream: "Design & Creative Arts",
		educationLevels: [
			"Class 12",
			"Diploma",
			"Undergraduate",
			"Working Professional"
		],
		provider: "CalArts / Coursera",
		format: "Structured course",
		pricing: "Free to audit",
		url: "https://www.coursera.org/specializations/ui-ux-design",
		syllabus: [
			"Empathy Mapping & User Personas",
			"Information Architecture & Sitemap Hierarchy",
			"Low-Fidelity Paper Prototyping",
			"Visual Hierarchy & Layout Grids",
			"Usability Testing & Feedback Loops"
		]
	},
	{
		id: "figma-design-systems",
		title: "Figma Advanced: Components & Design Systems",
		desc: "Auto-layout v5, variables, design tokens, component variants, interactive components, and handoff.",
		duration: "7 hours",
		lessons: 9,
		level: "Intermediate",
		skills: [
			"Visual Design",
			"Interaction Design",
			"Figma"
		],
		goals: ["UI/UX Designer"],
		bg: "bg-mint",
		category: "Design & Media",
		stream: "Design & Creative Arts",
		educationLevels: [
			"Undergraduate",
			"Diploma",
			"Working Professional"
		],
		provider: "Figma Academy",
		format: "Interactive hands-on",
		pricing: "Free",
		url: "https://help.figma.com/hc/en-us/categories/360002051613-Learn-design",
		syllabus: [
			"Auto-Layout: Resizing, Min/Max & Wrapping",
			"Design Tokens: Colors, Spacing & Typography",
			"Component Variants & Component Properties",
			"Prototyping with Variables & Conditionals",
			"Developer Mode & Design-to-Code Handoff"
		]
	},
	{
		id: "ux-research-nng",
		title: "UX Research Methods & Behavioral Synthesis",
		desc: "Conduct generative user interviews, run usability tests, synthesize affinity diagrams, and present findings.",
		duration: "6 hours",
		lessons: 8,
		level: "Beginner",
		skills: [
			"User Research",
			"Product Thinking",
			"Communication"
		],
		goals: ["UI/UX Designer", "Product Manager"],
		bg: "bg-blush",
		category: "Design & Media",
		stream: "Design & Creative Arts",
		educationLevels: [
			"Undergraduate",
			"Postgraduate",
			"Working Professional"
		],
		provider: "Interaction Design Foundation",
		format: "Self-paced video",
		pricing: "Free to audit",
		url: "https://www.interaction-design.org/courses",
		syllabus: [
			"Formulating Non-Leading Research Questions",
			"Conducting 1-on-1 Qualitative Interviews",
			"Moderated vs Unmoderated Usability Testing",
			"Thematic Analysis & Affinity Mapping",
			"Creating Actionable Executive Reports"
		]
	},
	{
		id: "interaction-micro-animations",
		title: "Interaction Design & Micro-animations",
		desc: "Disney principles applied to UI, motion choreography, easing curves, state transitions, and SVG animation.",
		duration: "5 hours",
		lessons: 7,
		level: "Intermediate",
		skills: ["Interaction Design", "Visual Design"],
		goals: ["UI/UX Designer", "Frontend Developer"],
		bg: "bg-lilac",
		category: "Design & Media",
		stream: "Design & Creative Arts",
		educationLevels: ["Undergraduate", "Working Professional"],
		provider: "Designlab",
		format: "Project-based",
		pricing: "Free",
		url: "https://designlab.com/",
		syllabus: [
			"Physics of Motion & Easing Curves",
			"Button & Hover State Transitions",
			"Skeleton Screens & Perceived Performance",
			"Framer Motion for React Web Applications",
			"Accessible Motion & prefers-reduced-motion"
		]
	},
	{
		id: "typography-visual-hierarchy",
		title: "Visual Hierarchy & Typography Mastery",
		desc: "Font pairing, typographic scales, optical alignment, whitespace balancing, and accessibility contrast.",
		duration: "4 hours",
		lessons: 6,
		level: "Beginner",
		skills: ["Visual Design", "Typography"],
		goals: ["UI/UX Designer"],
		bg: "bg-mint",
		category: "Design & Media",
		stream: "Design & Creative Arts",
		educationLevels: [
			"Class 12",
			"Diploma",
			"Undergraduate"
		],
		provider: "Rhode Island School of Design / edX",
		format: "Self-paced video",
		pricing: "Free to audit",
		url: "https://www.edx.org/learn/design",
		syllabus: [
			"Anatomy of Type: Serif, Sans & Monospace",
			"Modular Scales & Line-Height Harmonies",
			"Gestalt Principles: Proximity & Similarity",
			"Color Contrast Ratios & WCAG Guidelines",
			"Responsive Layout Grids & Breakpoints"
		]
	},
	{
		id: "design-leadership",
		title: "Design Leadership & Creative Direction",
		desc: "Design critiques, stakeholder alignment, design advocacy, mentoring junior designers, and roadmap strategy.",
		duration: "4 hours",
		lessons: 7,
		level: "Advanced",
		skills: [
			"Design Leadership",
			"Communication",
			"Product Thinking"
		],
		goals: ["UI/UX Designer"],
		bg: "bg-butter",
		category: "Design & Media",
		stream: "Design & Creative Arts",
		educationLevels: ["Postgraduate", "Working Professional"],
		provider: "Pathfinder / Leadership Track",
		format: "Project-based",
		pricing: "Free",
		url: "https://www.invisionapp.com/inside-design/design-leadership-handbook/",
		syllabus: [
			"Running Constructive Design Critiques",
			"Aligning Product, Engineering & Business",
			"Design Maturity Models & Team Structure",
			"Mentoring Junior Designers & Career Ladders",
			"Measuring Design Impact with Product KPIs"
		]
	},
	{
		id: "mobile-ux-google",
		title: "Mobile App UX Patterns & Guidelines",
		desc: "Touch targets, bottom sheet navigations, thumb-zone ergonomics, gestures, and native Material Design 3.",
		duration: "6 hours",
		lessons: 8,
		level: "Intermediate",
		skills: ["Visual Design", "Interaction Design"],
		goals: ["UI/UX Designer", "Frontend Developer"],
		bg: "bg-blush",
		category: "Design & Media",
		stream: "Design & Creative Arts",
		educationLevels: [
			"Undergraduate",
			"Diploma",
			"Working Professional"
		],
		provider: "Google UX Certificates",
		format: "Self-paced video",
		pricing: "Free to audit",
		url: "https://grow.google/certificates/ux-design/",
		syllabus: [
			"Thumb Zones & Reachability on Large Screens",
			"Bottom Navigation vs Drawer Menus",
			"Form Input Optimization on Mobile Keyboards",
			"Push Notification & Permission UX",
			"Designing for iOS (HIG) vs Android (Material 3)"
		]
	},
	{
		id: "design-systems-scale",
		title: "Design Systems at Scale: Tokens & Tooling",
		desc: "Multi-brand design systems, automated token pipelines (Style Dictionary), Storybook documentation.",
		duration: "8 hours",
		lessons: 10,
		level: "Advanced",
		skills: [
			"Design Systems",
			"Visual Design",
			"Frontend"
		],
		goals: ["UI/UX Designer", "Frontend Developer"],
		bg: "bg-lilac",
		category: "Design & Media",
		stream: "Design & Creative Arts",
		educationLevels: ["Undergraduate", "Working Professional"],
		provider: "Pathfinder / Design Systems",
		format: "Project-based",
		pricing: "Free",
		url: "https://storybook.js.org/tutorials/design-systems-for-developers/",
		syllabus: [
			"Single Source of Truth Design Tokens",
			"Style Dictionary Multi-Platform Export",
			"Storybook Component Isolation & Testing",
			"Semantic Versioning for Component Libraries",
			"Governing Contributions Across Product Teams"
		]
	},
	{
		id: "motion-design-school",
		title: "Motion Graphic Design & 2D Animation",
		desc: "Keyframe timing, anticipation, squash & stretch, SVG vector manipulation, and digital storytelling.",
		duration: "9 hours",
		lessons: 11,
		level: "Intermediate",
		skills: ["Motion Design", "Visual Design"],
		goals: ["UI/UX Designer"],
		bg: "bg-mint",
		category: "Design & Media",
		stream: "Design & Creative Arts",
		educationLevels: ["Diploma", "Undergraduate"],
		provider: "School of Motion",
		format: "Project-based",
		pricing: "Free to audit",
		url: "https://www.schoolofmotion.com/",
		syllabus: [
			"The 12 Classical Animation Principles",
			"Speed Graphs & Value Graphs",
			"Vector Path Animation in Lottie",
			"Choreographing Complex Multi-Element Scenes",
			"Exporting Clean Web-Optimized JSON"
		]
	},
	{
		id: "accessible-design-wcag",
		title: "Digital Accessibility & Inclusive Design (WCAG 2.2)",
		desc: "Design for diverse physical and cognitive abilities, screen reader navigation, color blindness, and focus states.",
		duration: "5 hours",
		lessons: 7,
		level: "Beginner",
		skills: [
			"Accessibility",
			"Visual Design",
			"User Research"
		],
		goals: ["UI/UX Designer", "Frontend Developer"],
		bg: "bg-butter",
		category: "Design & Media",
		stream: "Design & Creative Arts",
		educationLevels: ["Undergraduate", "Working Professional"],
		provider: "W3C / edX",
		format: "Self-paced video",
		pricing: "Free to audit",
		url: "https://www.w3.org/WAI/fundamentals/accessibility-intro/",
		syllabus: [
			"The 4 Principles of WCAG (POUR)",
			"Designing Accessible Color Palettes",
			"Focus Indicators & Keyboard Tab Orders",
			"Alternative Text Strategies for Complex Data",
			"Auditing Interfaces with Automated Tools"
		]
	},
	{
		id: "product-thinking-dschool",
		title: "Product Thinking & Rapid Prototyping",
		desc: "Problem framing, hypothesis validation, rapid MVP scoping, and customer value proposition design.",
		duration: "6 hours",
		lessons: 8,
		level: "Intermediate",
		skills: [
			"Product Thinking",
			"User Research",
			"Problem Solving"
		],
		goals: ["UI/UX Designer", "Product Manager"],
		bg: "bg-blush",
		category: "Design & Media",
		stream: "Management & Business",
		educationLevels: [
			"Undergraduate",
			"Postgraduate",
			"Working Professional"
		],
		provider: "Stanford d.school",
		format: "Interactive hands-on",
		pricing: "Free",
		url: "https://dschool.stanford.edu/resources",
		syllabus: [
			"How Might We (HMW) Problem Reframing",
			"Value Proposition Canvas & Jobs-to-be-Done",
			"Crazy Eights Rapid Ideation",
			"Wizard of Oz & Concierge MVPs",
			"Validating Product Assumptions with Data"
		]
	},
	{
		id: "human-anatomy-physiology",
		title: "Human Anatomy & Physiology Fundamentals",
		desc: "In-depth study of the musculoskeletal, cardiovascular, nervous, respiratory, and endocrine systems.",
		duration: "18 hours",
		lessons: 20,
		level: "Beginner",
		skills: [
			"Human Anatomy",
			"Physiology",
			"Biological Sciences"
		],
		goals: ["Medical & Healthcare Aspirant", "Academic Researcher"],
		bg: "bg-lilac",
		category: "Medical Sciences",
		stream: "Medical & Healthcare",
		educationLevels: [
			"Class 11",
			"Class 12",
			"Undergraduate",
			"Competitive Exams"
		],
		provider: "Khan Academy & Harvard Online",
		format: "Structured course",
		pricing: "Free",
		url: "https://www.khanacademy.org/science/health-and-medicine/human-anatomy-and-physiology",
		syllabus: [
			"Levels of Structural Organization & Homeostasis",
			"Cardiovascular Circulation & Heart Mechanics",
			"Central & Peripheral Nervous Transmission",
			"Respiratory Gas Exchange & Lung Volumes",
			"Renal Function, Filtration & Fluid Balance"
		],
		isMedical: true
	},
	{
		id: "clinical-biochemistry",
		title: "Clinical Biochemistry & Metabolic Pathways",
		desc: "Cellular bioenergetics, enzyme kinetics, glycolysis, Krebs cycle, lipid metabolism, and clinical biomarkers.",
		duration: "14 hours",
		lessons: 16,
		level: "Intermediate",
		skills: [
			"Biochemistry",
			"Metabolism",
			"Laboratory Science"
		],
		goals: ["Medical & Healthcare Aspirant", "Academic Researcher"],
		bg: "bg-mint",
		category: "Medical Sciences",
		stream: "Medical & Healthcare",
		educationLevels: [
			"Undergraduate",
			"Postgraduate",
			"Competitive Exams"
		],
		provider: "MIT OpenCourseWare",
		format: "Self-paced video",
		pricing: "Free",
		url: "https://ocw.mit.edu/courses/7-05-general-biochemistry-spring-2020/",
		syllabus: [
			"Amino Acid Structures & Protein Folding",
			"Enzyme Kinetics & Michaelis-Menten Models",
			"Glycolytic Flux & Citric Acid Cycle",
			"Lipid Transport & Cholesterol Biosynthesis",
			"Serum Electrolytes & Clinical Lab Indicators"
		],
		isMedical: true
	},
	{
		id: "epidemiology-surveillance",
		title: "Foundations of Epidemiology & Disease Surveillance",
		desc: "Outbreak investigation, incidence vs prevalence rates, cohort studies, randomized trials, and bias control.",
		duration: "10 hours",
		lessons: 12,
		level: "Beginner",
		skills: [
			"Epidemiology",
			"Public Health",
			"Data Analysis"
		],
		goals: [
			"Medical & Healthcare Aspirant",
			"Data Analyst",
			"Academic Researcher"
		],
		bg: "bg-butter",
		category: "Medical Sciences",
		stream: "Medical & Healthcare",
		educationLevels: [
			"Undergraduate",
			"Postgraduate",
			"Working Professional"
		],
		provider: "Johns Hopkins University / Coursera",
		format: "Structured course",
		pricing: "Free to audit",
		url: "https://www.coursera.org/learn/epidemiology",
		syllabus: [
			"Measures of Disease Frequency & Risk Ratios",
			"Case-Control vs Prospective Cohort Designs",
			"Confounding Variables & Stratification",
			"Screening Test Sensitivity & Specificity",
			"Outbreak Investigation Step-by-Step"
		],
		isMedical: true
	},
	{
		id: "medical-terminology-pitt",
		title: "Medical Terminology & Clinical Records",
		desc: "Master prefixes, roots, suffixes, anatomical orientations, clinical abbreviations, and medical documentation.",
		duration: "6 hours",
		lessons: 8,
		level: "Beginner",
		skills: ["Medical Terminology", "Clinical Documentation"],
		goals: ["Medical & Healthcare Aspirant"],
		bg: "bg-blush",
		category: "Medical Sciences",
		stream: "Medical & Healthcare",
		educationLevels: [
			"Class 12",
			"Diploma",
			"Undergraduate"
		],
		provider: "University of Pittsburgh / Coursera",
		format: "Self-paced video",
		pricing: "Free to audit",
		url: "https://www.coursera.org/learn/clinical-terminology",
		syllabus: [
			"Word Roots, Combining Forms & Suffixes",
			"Integumentary & Musculoskeletal Terms",
			"Cardiovascular & Respiratory Vocabulary",
			"Diagnostic Imaging & Laboratory Abbreviations",
			"Interpreting Electronic Health Records (EHR)"
		],
		isMedical: true
	},
	{
		id: "principles-of-pharmacology",
		title: "Principles of Pharmacology & Drug Mechanisms",
		desc: "Pharmacokinetics (ADME), receptor agonists/antagonists, therapeutic windows, and drug interactions.",
		duration: "12 hours",
		lessons: 14,
		level: "Advanced",
		skills: [
			"Pharmacology",
			"Drug Mechanisms",
			"Biochemistry"
		],
		goals: ["Medical & Healthcare Aspirant", "Academic Researcher"],
		bg: "bg-lilac",
		category: "Medical Sciences",
		stream: "Medical & Healthcare",
		educationLevels: ["Undergraduate", "Postgraduate"],
		provider: "Harvard Medical School Online",
		format: "Structured course",
		pricing: "Free to audit",
		url: "https://onlinelearning.hms.harvard.edu/",
		syllabus: [
			"Absorption, Distribution, Metabolism & Excretion (ADME)",
			"Dose-Response Curves & Potency vs Efficacy",
			"G-Protein Coupled Receptors & Ion Channels",
			"Antimicrobial Mechanisms & Resistance",
			"Adverse Drug Reactions & Toxicity Profiles"
		],
		isMedical: true
	},
	{
		id: "public-health-crises-who",
		title: "Global Public Health & Emergency Preparedness",
		desc: "Infectious disease tracking, vaccination logistics, community health interventions, and WHO protocols.",
		duration: "8 hours",
		lessons: 10,
		level: "Beginner",
		skills: [
			"Public Health",
			"Emergency Response",
			"Global Health"
		],
		goals: ["Medical & Healthcare Aspirant", "Civil Services / UPSC Aspirant"],
		bg: "bg-mint",
		category: "Medical Sciences",
		stream: "Medical & Healthcare",
		educationLevels: [
			"Undergraduate",
			"Postgraduate",
			"Working Professional"
		],
		provider: "WHO Academy",
		format: "Self-paced video",
		pricing: "Free",
		url: "https://www.who.int/our-work/who-academy",
		syllabus: [
			"International Health Regulations (IHR)",
			"Vaccine Cold-Chain Management",
			"Water, Sanitation and Hygiene (WASH) Standards",
			"Community Risk Communication in Pandemics",
			"Maternal and Child Health Interventions"
		],
		isMedical: true
	},
	{
		id: "patient-communication-ethics",
		title: "Healthcare Ethics & Clinical Communication",
		desc: "Bioethics principles (autonomy, beneficence, justice), informed consent, and empathetic patient dialogue.",
		duration: "6 hours",
		lessons: 8,
		level: "Beginner",
		skills: [
			"Bioethics",
			"Communication",
			"Empathy"
		],
		goals: ["Medical & Healthcare Aspirant"],
		bg: "bg-butter",
		category: "Medical Sciences",
		stream: "Medical & Healthcare",
		educationLevels: ["Undergraduate", "Postgraduate"],
		provider: "Stanford Medicine",
		format: "Interactive hands-on",
		pricing: "Free",
		url: "https://med.stanford.edu/",
		syllabus: [
			"The Four Principles of Biomedical Ethics",
			"Informed Consent & Patient Capacity Assessment",
			"Breaking Bad News with the SPIKES Protocol",
			"Confidentiality & Ethical Dilemmas at End-of-Life",
			"Cultural Competency in Healthcare Delivery"
		],
		isMedical: true
	},
	{
		id: "nursing-fundamentals-swayam",
		title: "Fundamentals of Nursing & Patient Care",
		desc: "Vital signs monitoring, aseptic procedures, patient safety guidelines, wound care basics, and triage.",
		duration: "10 hours",
		lessons: 12,
		level: "Beginner",
		skills: [
			"Patient Care",
			"Vital Signs",
			"Aseptic Technique"
		],
		goals: ["Medical & Healthcare Aspirant"],
		bg: "bg-blush",
		category: "Medical Sciences",
		stream: "Medical & Healthcare",
		educationLevels: ["Diploma", "Undergraduate"],
		provider: "SWAYAM / NPTEL",
		format: "Structured course",
		pricing: "Free",
		url: "https://swayam.gov.in/",
		syllabus: [
			"Infection Control & Hand Hygiene Protocols",
			"Measuring Blood Pressure, Pulse & Oxygen Saturation",
			"Patient Mobility & Ergonomic Transfers",
			"Wound Assessment & Dressing Standards",
			"Emergency Code Response & First Aid"
		],
		isMedical: true
	},
	{
		id: "microbiology-pathogens",
		title: "Medical Microbiology & Infectious Pathogens",
		desc: "Bacterial cell walls, viral replication cycles, fungal infections, antibiotics, and laboratory culture staining.",
		duration: "11 hours",
		lessons: 13,
		level: "Intermediate",
		skills: [
			"Microbiology",
			"Pathology",
			"Laboratory Science"
		],
		goals: ["Medical & Healthcare Aspirant", "Academic Researcher"],
		bg: "bg-lilac",
		category: "Medical Sciences",
		stream: "Medical & Healthcare",
		educationLevels: [
			"Class 12",
			"Undergraduate",
			"Postgraduate",
			"Competitive Exams"
		],
		provider: "Khan Academy",
		format: "Self-paced video",
		pricing: "Free",
		url: "https://www.khanacademy.org/science/biology",
		syllabus: [
			"Gram-Positive vs Gram-Negative Bacteria",
			"Retroviruses & RNA Virus Replication",
			"Antimicrobial Susceptibility Testing",
			"Sterilization & Autoclave Mechanics",
			"Hospital-Acquired Infections (Nosocomial)"
		],
		isMedical: true
	},
	{
		id: "genetics-molecular-medicine",
		title: "Human Genetics & Molecular Diagnostics",
		desc: "Mendelian inheritance, chromosomal karyotyping, PCR amplification, DNA sequencing, and gene therapies.",
		duration: "12 hours",
		lessons: 14,
		level: "Advanced",
		skills: [
			"Genetics",
			"Molecular Biology",
			"DNA Analysis"
		],
		goals: ["Medical & Healthcare Aspirant", "Academic Researcher"],
		bg: "bg-mint",
		category: "Medical Sciences",
		stream: "Science (PCB)",
		educationLevels: [
			"Undergraduate",
			"Postgraduate",
			"PhD / Research"
		],
		provider: "MIT OpenCourseWare",
		format: "Structured course",
		pricing: "Free",
		url: "https://ocw.mit.edu/courses/7-03-genetics-fall-2019/",
		syllabus: [
			"DNA Replication, Transcription & Translation",
			"Pedigree Analysis & Autosomal Disorders",
			"Polymerase Chain Reaction (PCR) Mechanics",
			"Next-Generation Sequencing (NGS) Overview",
			"CRISPR-Cas9 & Gene Editing Horizons"
		],
		isMedical: true
	},
	{
		id: "healthcare-informatics-nptel",
		title: "Healthcare Informatics & Digital Health Systems",
		desc: "Electronic Medical Records (EMR), HL7/FHIR protocols, clinical decision support systems, and tele-health.",
		duration: "9 hours",
		lessons: 11,
		level: "Intermediate",
		skills: [
			"Health Informatics",
			"Databases",
			"Data Standards"
		],
		goals: [
			"Medical & Healthcare Aspirant",
			"Full Stack Engineer",
			"Data Analyst"
		],
		bg: "bg-butter",
		category: "Medical Sciences",
		stream: "Medical & Healthcare",
		educationLevels: [
			"Undergraduate",
			"Postgraduate",
			"Working Professional"
		],
		provider: "NPTEL / IIT Kharagpur",
		format: "Structured course",
		pricing: "Free",
		url: "https://nptel.ac.in/courses/106105216",
		syllabus: [
			"Anatomy of Hospital Information Systems",
			"HL7 & FHIR Interoperability Standards",
			"PACS & DICOM Medical Imaging Formats",
			"Clinical Decision Support Algorithms",
			"Telemedicine Architecture & Security"
		],
		isMedical: true
	},
	{
		id: "human-nutrition-metabolism",
		title: "Human Nutrition & Clinical Dietetics",
		desc: "Macronutrient requirements, micronutrient deficiencies, dietary guidelines, and nutritional physiology.",
		duration: "8 hours",
		lessons: 10,
		level: "Beginner",
		skills: [
			"Nutrition Science",
			"Dietetics",
			"Physiology"
		],
		goals: ["Medical & Healthcare Aspirant"],
		bg: "bg-blush",
		category: "Medical Sciences",
		stream: "Medical & Healthcare",
		educationLevels: [
			"Class 12",
			"Undergraduate",
			"Working Professional"
		],
		provider: "Wageningen University / edX",
		format: "Self-paced video",
		pricing: "Free to audit",
		url: "https://www.edx.org/course/nutrition-and-health-macronutrients-and-overnutrition",
		syllabus: [
			"Carbohydrate Glycemic Index & Fiber Physiology",
			"Essential Fatty Acids & Lipid Profiles",
			"Vitamins & Mineral Deficiency Pathologies",
			"Energy Expenditure & Basal Metabolic Rate",
			"Nutritional Strategies for Metabolic Diseases"
		],
		isMedical: true
	},
	{
		id: "class10-math-foundations",
		title: "Class 10 Mathematics: CBSE / ICSE Board Foundations",
		desc: "Real numbers, polynomials, linear equations, quadratic equations, arithmetic progressions, and trigonometry.",
		duration: "14 hours",
		lessons: 18,
		level: "Beginner",
		skills: [
			"Mathematics",
			"Algebra",
			"Trigonometry"
		],
		goals: ["Secondary School Student (Class 10-12)", "Competitive Exams Aspirant"],
		bg: "bg-lilac",
		category: "School (10th-12th)",
		stream: "Science (PCM)",
		educationLevels: ["Class 10"],
		provider: "Khan Academy",
		format: "Interactive hands-on",
		pricing: "Free",
		url: "https://www.khanacademy.org/math/in-in-class-10th-math-cbse",
		syllabus: [
			"Euclid's Division Lemma & Fundamental Theorem of Arithmetic",
			"Polynomial Roots & Relationship with Coefficients",
			"Pair of Linear Equations in Two Variables",
			"Quadratic Equations & Quadratic Formula",
			"Introduction to Trigonometric Ratios & Identities"
		]
	},
	{
		id: "class10-science-life-chemical",
		title: "Class 10 Science: Chemical Reactions & Life Processes",
		desc: "Balancing chemical equations, acids and bases, metals, life processes (respiration/digestion), light and electricity.",
		duration: "15 hours",
		lessons: 18,
		level: "Beginner",
		skills: [
			"Science",
			"Chemistry",
			"Biology"
		],
		goals: ["Secondary School Student (Class 10-12)"],
		bg: "bg-mint",
		category: "School (10th-12th)",
		stream: "Science (PCB)",
		educationLevels: ["Class 10"],
		provider: "NCERT / SWAYAM",
		format: "Structured course",
		pricing: "Free",
		url: "https://swayam.gov.in/",
		syllabus: [
			"Chemical Reactions, Types & Balancing",
			"Acids, Bases & Salts with pH Scale",
			"Carbon & Its Compounds: Covalent Bonding",
			"Life Processes: Nutrition, Respiration & Excretion",
			"Electricity: Ohm's Law & Circuit Calculations"
		]
	},
	{
		id: "class10-social-science",
		title: "Class 10 Social Science: Democratic Politics & Contemporary India",
		desc: "Nationalism in Europe and India, resource management, federalism, power sharing, and economic development.",
		duration: "10 hours",
		lessons: 12,
		level: "Beginner",
		skills: [
			"Civics",
			"History",
			"Critical Thinking"
		],
		goals: ["Secondary School Student (Class 10-12)", "Civil Services / UPSC Aspirant"],
		bg: "bg-butter",
		category: "School (10th-12th)",
		stream: "Arts & Humanities",
		educationLevels: ["Class 10"],
		provider: "SWAYAM",
		format: "Self-paced video",
		pricing: "Free",
		url: "https://swayam.gov.in/",
		syllabus: [
			"The Rise of Nationalism in Europe",
			"Nationalism in India & Mass Satyagraha",
			"Power Sharing & Federal Structure",
			"Resources and Development Geography",
			"Understanding Economic Development & Sectors"
		]
	},
	{
		id: "class11-physics-mechanics",
		title: "Class 11 Physics: Kinematics & Laws of Motion",
		desc: "Vectors, motion in 1D and 2D, Newton's laws, friction, work-energy theorem, and rotational dynamics.",
		duration: "16 hours",
		lessons: 18,
		level: "Intermediate",
		skills: [
			"Physics",
			"Mechanics",
			"Problem Solving"
		],
		goals: ["Secondary School Student (Class 10-12)", "Competitive Exams Aspirant"],
		bg: "bg-blush",
		category: "School (10th-12th)",
		stream: "Science (PCM)",
		educationLevels: ["Class 11", "Competitive Exams"],
		provider: "NPTEL / Khan Academy",
		format: "Interactive hands-on",
		pricing: "Free",
		url: "https://www.khanacademy.org/science/in-in-class11th-physics",
		syllabus: [
			"Physical World & Vector Algebra (Dot/Cross Products)",
			"Motion in a Straight Line & Constant Acceleration",
			"Projectile Motion & Relative Velocity",
			"Newton's Laws of Motion & Free Body Diagrams",
			"Work-Energy Theorem, Power & Collisions"
		]
	},
	{
		id: "class11-chemistry-atomic",
		title: "Class 11 Chemistry: Structure of Atom & Chemical Bonding",
		desc: "Bohr model, quantum numbers, periodic trends, VSEPR theory, hybridization, and thermodynamics.",
		duration: "15 hours",
		lessons: 17,
		level: "Intermediate",
		skills: [
			"Chemistry",
			"Atomic Structure",
			"Chemical Bonding"
		],
		goals: ["Secondary School Student (Class 10-12)", "Competitive Exams Aspirant"],
		bg: "bg-lilac",
		category: "School (10th-12th)",
		stream: "Science (PCM)",
		educationLevels: ["Class 11", "Competitive Exams"],
		provider: "Khan Academy",
		format: "Structured course",
		pricing: "Free",
		url: "https://www.khanacademy.org/science/in-in-class11th-chemistry",
		syllabus: [
			"Dual Nature of Matter & Heisenberg Uncertainty",
			"Quantum Numbers & Electronic Configurations",
			"Periodic Properties: Ionization & Electronegativity",
			"Valence Bond Theory & Hybridization (sp, sp2, sp3)",
			"First & Second Laws of Chemical Thermodynamics"
		]
	},
	{
		id: "class11-math-calculus-foundations",
		title: "Class 11 Mathematics: Sets, Relations & Calculus Foundations",
		desc: "Set theory, cartesian products, trigonometric functions, mathematical induction, limits, and derivatives.",
		duration: "14 hours",
		lessons: 16,
		level: "Intermediate",
		skills: [
			"Mathematics",
			"Calculus",
			"Logic"
		],
		goals: ["Secondary School Student (Class 10-12)", "Competitive Exams Aspirant"],
		bg: "bg-mint",
		category: "School (10th-12th)",
		stream: "Science (PCM)",
		educationLevels: ["Class 11", "Competitive Exams"],
		provider: "Khan Academy",
		format: "Interactive hands-on",
		pricing: "Free",
		url: "https://www.khanacademy.org/math/in-in-class-11th-math-cbse",
		syllabus: [
			"Sets, Subsets, Venn Diagrams & Operations",
			"Relations, Domain, Range & Functions",
			"Trigonometric Functions & General Solutions",
			"Permutations & Combinations Basics",
			"Limits & First Principle Differentiation"
		]
	},
	{
		id: "class11-biology-cell-diversity",
		title: "Class 11 Biology: Diversity of Life & Cell Structure",
		desc: "Five kingdom classification, plant and animal morphology, cell organelle functions, and cell cycle mitosis/meiosis.",
		duration: "14 hours",
		lessons: 16,
		level: "Intermediate",
		skills: [
			"Biology",
			"Cell Biology",
			"Taxonomy"
		],
		goals: ["Secondary School Student (Class 10-12)", "Medical & Healthcare Aspirant"],
		bg: "bg-butter",
		category: "School (10th-12th)",
		stream: "Science (PCB)",
		educationLevels: ["Class 11", "Competitive Exams"],
		provider: "SWAYAM / NCERT",
		format: "Structured course",
		pricing: "Free",
		url: "https://swayam.gov.in/",
		syllabus: [
			"Biological Classification: Monera, Protista, Fungi",
			"Plant Kingdom: Algae to Angiosperms",
			"Animal Kingdom: Phyla Characteristics",
			"Cell: The Unit of Life (Membranes & Organelles)",
			"Cell Cycle, Mitosis & Meiosis Stages"
		]
	},
	{
		id: "class11-accountancy-principles",
		title: "Class 11 Accountancy: Accounting Principles & Ledger",
		desc: "Double entry bookkeeping, journal entries, ledger posting, trial balance, and bank reconciliation statements.",
		duration: "12 hours",
		lessons: 14,
		level: "Beginner",
		skills: [
			"Accounting",
			"Bookkeeping",
			"Financial Records"
		],
		goals: ["Secondary School Student (Class 10-12)", "Chartered Accountant / Finance Specialist"],
		bg: "bg-blush",
		category: "School (10th-12th)",
		stream: "Commerce & Finance",
		educationLevels: ["Class 11"],
		provider: "CBSE / SWAYAM",
		format: "Structured course",
		pricing: "Free",
		url: "https://swayam.gov.in/",
		syllabus: [
			"Basic Accounting Concepts & Conventions",
			"Source Documents & Preparation of Vouchers",
			"Recording of Transactions in Journal",
			"Posting to Ledger & Balancing Accounts",
			"Preparation of Trial Balance & BRS"
		]
	},
	{
		id: "class11-economics-micro",
		title: "Class 11 Economics: Microeconomics & Economic Statistics",
		desc: "Consumer equilibrium, demand elasticity, production functions, cost curves, and statistical dispersion.",
		duration: "11 hours",
		lessons: 13,
		level: "Beginner",
		skills: [
			"Economics",
			"Statistics",
			"Data Interpretation"
		],
		goals: ["Secondary School Student (Class 10-12)", "Chartered Accountant / Finance Specialist"],
		bg: "bg-lilac",
		category: "School (10th-12th)",
		stream: "Commerce & Finance",
		educationLevels: ["Class 11"],
		provider: "SWAYAM",
		format: "Self-paced video",
		pricing: "Free",
		url: "https://swayam.gov.in/",
		syllabus: [
			"Central Problems of an Economy & PPC",
			"Consumer's Equilibrium: Utility Analysis",
			"Law of Demand & Price Elasticity",
			"Law of Variable Proportions & Cost Curves",
			"Measures of Central Tendency & Dispersion"
		]
	},
	{
		id: "class12-physics-electromagnetism",
		title: "Class 12 Physics: Electrostatics, Current & Magnetism",
		desc: "Coulomb's law, Gauss theorem, electric potential, Kirchhoff's laws, Biot-Savart law, and alternating currents.",
		duration: "16 hours",
		lessons: 18,
		level: "Advanced",
		skills: [
			"Physics",
			"Electromagnetism",
			"Problem Solving"
		],
		goals: ["Secondary School Student (Class 10-12)", "Competitive Exams Aspirant"],
		bg: "bg-mint",
		category: "School (10th-12th)",
		stream: "Science (PCM)",
		educationLevels: ["Class 12", "Competitive Exams"],
		provider: "Khan Academy / NPTEL",
		format: "Interactive hands-on",
		pricing: "Free",
		url: "https://www.khanacademy.org/science/in-in-class12th-physics",
		syllabus: [
			"Electric Charges, Fields & Gauss's Theorem",
			"Capacitance & Energy Stored in Capacitors",
			"Current Electricity & Wheatstone Bridge",
			"Magnetic Effects of Current & Ampere's Law",
			"Electromagnetic Induction & AC Circuits"
		]
	},
	{
		id: "class12-chemistry-organic",
		title: "Class 12 Chemistry: Organic Reaction Mechanisms",
		desc: "Haloalkanes, alcohols, phenols, aldehydes, ketones, carboxylic acids, amines, and reaction naming.",
		duration: "16 hours",
		lessons: 18,
		level: "Advanced",
		skills: [
			"Organic Chemistry",
			"Reactions",
			"Mechanism Analysis"
		],
		goals: [
			"Secondary School Student (Class 10-12)",
			"Competitive Exams Aspirant",
			"Medical & Healthcare Aspirant"
		],
		bg: "bg-butter",
		category: "School (10th-12th)",
		stream: "Science (PCM)",
		educationLevels: ["Class 12", "Competitive Exams"],
		provider: "Khan Academy",
		format: "Structured course",
		pricing: "Free",
		url: "https://www.khanacademy.org/science/in-in-class12th-chemistry",
		syllabus: [
			"SN1 & SN2 Mechanisms in Haloalkanes",
			"Preparation & Acidity of Phenols",
			"Nucleophilic Addition in Aldehydes & Ketones",
			"Carboxylic Acid Derivatives & Decarboxylation",
			"Diazonium Salts & Coupling Reactions"
		]
	},
	{
		id: "class12-math-calculus-vectors",
		title: "Class 12 Mathematics: Differential & Integral Calculus",
		desc: "Continuity, differentiability, max/min applications, definite integrals, differential equations, and 3D vectors.",
		duration: "18 hours",
		lessons: 20,
		level: "Advanced",
		skills: [
			"Mathematics",
			"Calculus",
			"Vector Algebra"
		],
		goals: ["Secondary School Student (Class 10-12)", "Competitive Exams Aspirant"],
		bg: "bg-blush",
		category: "School (10th-12th)",
		stream: "Science (PCM)",
		educationLevels: ["Class 12", "Competitive Exams"],
		provider: "Khan Academy",
		format: "Interactive hands-on",
		pricing: "Free",
		url: "https://www.khanacademy.org/math/in-in-class-12th-math-cbse",
		syllabus: [
			"Chain Rule, Implicit & Parametric Differentiation",
			"Applications of Derivatives: Tangents & Maxima",
			"Indefinite & Definite Integrals by Substitution/Parts",
			"Area Under Curves (Applications of Integrals)",
			"3D Coordinate Geometry & Vectors"
		]
	},
	{
		id: "class12-biology-genetics-ecology",
		title: "Class 12 Biology: Genetics, Biotechnology & Ecology",
		desc: "Mendelian genetics, molecular basis of inheritance, recombinant DNA technology, and ecosystem biodiversity.",
		duration: "15 hours",
		lessons: 17,
		level: "Advanced",
		skills: [
			"Biology",
			"Genetics",
			"Biotechnology"
		],
		goals: ["Secondary School Student (Class 10-12)", "Medical & Healthcare Aspirant"],
		bg: "bg-lilac",
		category: "School (10th-12th)",
		stream: "Science (PCB)",
		educationLevels: ["Class 12", "Competitive Exams"],
		provider: "NCERT / SWAYAM",
		format: "Structured course",
		pricing: "Free",
		url: "https://swayam.gov.in/",
		syllabus: [
			"Principles of Inheritance & Sex Determination",
			"DNA Structure, Replication & Lac Operon",
			"Biotechnology Principles: Restriction Enzymes",
			"Applications of Biotech in Agriculture & Medicine",
			"Organisms, Populations & Ecosystem Cycles"
		]
	},
	{
		id: "class12-accountancy-partnerships",
		title: "Class 12 Accountancy: Partnership Accounts & Company Balance Sheets",
		desc: "Admission/retirement of partners, goodwill valuation, share capital issue, debentures, and cash flow statements.",
		duration: "14 hours",
		lessons: 16,
		level: "Intermediate",
		skills: [
			"Accounting",
			"Financial Statements",
			"Corporate Balance Sheets"
		],
		goals: ["Secondary School Student (Class 10-12)", "Chartered Accountant / Finance Specialist"],
		bg: "bg-mint",
		category: "School (10th-12th)",
		stream: "Commerce & Finance",
		educationLevels: ["Class 12"],
		provider: "SWAYAM",
		format: "Structured course",
		pricing: "Free",
		url: "https://swayam.gov.in/",
		syllabus: [
			"Partnership Deed & Profit and Loss Appropriation",
			"Revaluation Account upon Admission of Partner",
			"Accounting for Share Capital: Forfeiture & Reissue",
			"Redemption of Debentures",
			"Cash Flow Statement as per Accounting Standard 3"
		]
	},
	{
		id: "class12-macroeconomics-national-income",
		title: "Class 12 Macroeconomics: National Income & Fiscal Policy",
		desc: "GDP, GNP calculations, Keynesian multiplier, central banking (RBI instruments), government budget, and foreign exchange.",
		duration: "12 hours",
		lessons: 14,
		level: "Intermediate",
		skills: [
			"Economics",
			"Monetary Policy",
			"National Accounting"
		],
		goals: [
			"Secondary School Student (Class 10-12)",
			"Chartered Accountant / Finance Specialist",
			"Civil Services / UPSC Aspirant"
		],
		bg: "bg-butter",
		category: "School (10th-12th)",
		stream: "Commerce & Finance",
		educationLevels: ["Class 12"],
		provider: "SWAYAM / Khan Academy",
		format: "Self-paced video",
		pricing: "Free",
		url: "https://swayam.gov.in/",
		syllabus: [
			"Circular Flow of Income & Value Added Method",
			"Income & Expenditure Methods for National Income",
			"Aggregate Demand, Aggregate Supply & Multiplier",
			"RBI Monetary Policy: Repo Rate & CRR",
			"Government Budget: Revenue vs Fiscal Deficit"
		]
	},
	{
		id: "class12-pol-science-contemporary",
		title: "Class 12 Political Science: Contemporary World Politics",
		desc: "Cold war era, alternative centers of power, South Asia regional cooperation, international organizations, and globalization.",
		duration: "10 hours",
		lessons: 12,
		level: "Intermediate",
		skills: [
			"Political Science",
			"International Relations",
			"Analysis"
		],
		goals: ["Secondary School Student (Class 10-12)", "Civil Services / UPSC Aspirant"],
		bg: "bg-blush",
		category: "School (10th-12th)",
		stream: "Arts & Humanities",
		educationLevels: ["Class 12"],
		provider: "SWAYAM",
		format: "Self-paced video",
		pricing: "Free",
		url: "https://swayam.gov.in/",
		syllabus: [
			"The End of Bipolarity & Collapse of USSR",
			"Alternative Centers of Power: EU & ASEAN",
			"Contemporary South Asia & SAARC Realities",
			"United Nations Reforms & Security Council",
			"Dimensions of Cultural & Economic Globalization"
		]
	},
	{
		id: "financial-accounting-wharton",
		title: "Financial Accounting & Reporting Standards (IFRS)",
		desc: "Balance sheets, income statements, cash flows, revenue recognition rules, and working capital cycles.",
		duration: "12 hours",
		lessons: 14,
		level: "Beginner",
		skills: [
			"Financial Accounting",
			"Balance Sheets",
			"IFRS"
		],
		goals: ["Chartered Accountant / Finance Specialist", "Business & Marketing Specialist"],
		bg: "bg-lilac",
		category: "Commerce & Finance",
		stream: "Commerce & Finance",
		educationLevels: [
			"Undergraduate",
			"Postgraduate",
			"Working Professional"
		],
		provider: "Wharton School / Coursera",
		format: "Structured course",
		pricing: "Free to audit",
		url: "https://www.coursera.org/learn/wharton-accounting",
		syllabus: [
			"The Fundamental Accounting Equation",
			"Accrual Accounting & Matching Principle",
			"Depreciation Schedules (Straight Line vs DDB)",
			"Inventory Valuation (FIFO, LIFO & Weighted Avg)",
			"Interpreting Footnotes & 10-K Filings"
		]
	},
	{
		id: "corporate-finance-valuation",
		title: "Corporate Finance & DCF Valuation Modeling",
		desc: "Discounted cash flow (DCF), Weighted Average Cost of Capital (WACC), capital budgeting, and leveraged buyouts.",
		duration: "14 hours",
		lessons: 16,
		level: "Intermediate",
		skills: [
			"Corporate Finance",
			"Valuation",
			"Financial Modeling"
		],
		goals: ["Chartered Accountant / Finance Specialist", "Business & Marketing Specialist"],
		bg: "bg-mint",
		category: "Commerce & Finance",
		stream: "Commerce & Finance",
		educationLevels: [
			"Undergraduate",
			"Postgraduate",
			"Working Professional"
		],
		provider: "NYU Stern / edX",
		format: "Project-based",
		pricing: "Free to audit",
		url: "https://www.edx.org/learn/corporate-finance",
		syllabus: [
			"Time Value of Money & Net Present Value (NPV)",
			"Capital Asset Pricing Model (CAPM) & Beta",
			"Calculating WACC: Cost of Debt & Equity",
			"Building a Multi-Year Discounted Cash Flow",
			"Comparable Company Analysis (Trading Multiples)"
		]
	},
	{
		id: "business-analytics-excel",
		title: "Business Analytics & Financial Modeling in Excel",
		desc: "XLOOKUP, INDEX/MATCH, dynamic pivot tables, sensitivity tables, scenario manager, and financial dashboarding.",
		duration: "9 hours",
		lessons: 11,
		level: "Beginner",
		skills: [
			"Excel",
			"Business Analytics",
			"Financial Modeling"
		],
		goals: [
			"Data Analyst",
			"Chartered Accountant / Finance Specialist",
			"Business & Marketing Specialist"
		],
		bg: "bg-butter",
		category: "Commerce & Finance",
		stream: "Commerce & Finance",
		educationLevels: [
			"Diploma",
			"Undergraduate",
			"Postgraduate",
			"Working Professional"
		],
		provider: "Macquarie University / Coursera",
		format: "Interactive hands-on",
		pricing: "Free to audit",
		url: "https://www.coursera.org/specializations/excel-mysql",
		syllabus: [
			"Advanced Lookup Functions & Dynamic Arrays",
			"Multi-Variable Data Tables for Sensitivity",
			"Solver Optimization for Resource Constraints",
			"Financial Functions (XNPV, XIRR, PMT)",
			"Building Interactive Executive Dashboards"
		]
	},
	{
		id: "financial-markets-yale",
		title: "Financial Markets & Behavioral Economics",
		desc: "Equities, bonds, futures, options, insurance markets, behavioral biases, and market efficiency with Nobel Laureate Robert Shiller.",
		duration: "12 hours",
		lessons: 15,
		level: "Beginner",
		skills: [
			"Financial Markets",
			"Investment",
			"Economics"
		],
		goals: ["Chartered Accountant / Finance Specialist", "Business & Marketing Specialist"],
		bg: "bg-blush",
		category: "Commerce & Finance",
		stream: "Commerce & Finance",
		educationLevels: [
			"Undergraduate",
			"Postgraduate",
			"Working Professional"
		],
		provider: "Yale Online / Coursera",
		format: "Self-paced video",
		pricing: "Free to audit",
		url: "https://www.coursera.org/learn/financial-markets-global",
		syllabus: [
			"Stock Exchanges, Market Makers & Liquidity",
			"Bond Pricing, Yield Curves & Credit Default Swaps",
			"Options Contracts & Black-Scholes Overview",
			"Prospect Theory, Herd Mentality & Bubbles",
			"Financial Regulation & Systemic Risk"
		]
	},
	{
		id: "cost-management-accounting-nptel",
		title: "Cost & Management Accounting for Decision Making",
		desc: "Marginal costing, break-even analysis, standard costing, variance analysis, and activity-based costing (ABC).",
		duration: "11 hours",
		lessons: 13,
		level: "Intermediate",
		skills: [
			"Cost Accounting",
			"Variance Analysis",
			"Decision Making"
		],
		goals: ["Chartered Accountant / Finance Specialist", "Business & Marketing Specialist"],
		bg: "bg-lilac",
		category: "Commerce & Finance",
		stream: "Commerce & Finance",
		educationLevels: ["Undergraduate", "Postgraduate"],
		provider: "NPTEL / IIT Bombay",
		format: "Structured course",
		pricing: "Free",
		url: "https://nptel.ac.in/courses/110101132",
		syllabus: [
			"Cost Sheet Preparation & Classification",
			"Marginal Costing & CVP (Cost-Volume-Profit)",
			"Standard Costing & Material/Labor Variances",
			"Activity-Based Costing vs Traditional Overhead",
			"Budgetary Control & Flexible Budgets"
		]
	},
	{
		id: "principles-of-marketing",
		title: "Modern Marketing Management & Brand Strategy",
		desc: "Customer segmentation, targeting and positioning (STP), digital acquisition funnels, and marketing ROI.",
		duration: "8 hours",
		lessons: 10,
		level: "Beginner",
		skills: [
			"Marketing",
			"Brand Strategy",
			"Customer Acquisition"
		],
		goals: ["Business & Marketing Specialist"],
		bg: "bg-mint",
		category: "Commerce & Finance",
		stream: "Management & Business",
		educationLevels: [
			"Diploma",
			"Undergraduate",
			"Postgraduate",
			"Working Professional"
		],
		provider: "Northwestern University / Coursera",
		format: "Structured course",
		pricing: "Free to audit",
		url: "https://www.coursera.org/specializations/digital-marketing",
		syllabus: [
			"Marketing Mix (The 4 Ps & 7 Ps Framework)",
			"Customer Lifetime Value (CLV) & CAC Ratios",
			"Inbound Content Marketing vs Paid Performance",
			"Brand Positioning & Perceptual Mapping",
			"Attribution Modeling Across Omnichannel Touchpoints"
		]
	},
	{
		id: "strategic-management-hbs",
		title: "Strategic Management & Competitive Advantage",
		desc: "Porter's Five Forces, Blue Ocean strategy, core competencies, vertical integration, and merger synergy analysis.",
		duration: "9 hours",
		lessons: 11,
		level: "Intermediate",
		skills: [
			"Strategic Management",
			"Competitive Analysis",
			"Leadership"
		],
		goals: ["Business & Marketing Specialist", "Chartered Accountant / Finance Specialist"],
		bg: "bg-butter",
		category: "Commerce & Finance",
		stream: "Management & Business",
		educationLevels: [
			"Undergraduate",
			"Postgraduate",
			"Working Professional"
		],
		provider: "Harvard Business School Online",
		format: "Project-based",
		pricing: "Free to audit",
		url: "https://online.hbs.edu/",
		syllabus: [
			"Industry Structure & Porter's Five Forces",
			"Resource-Based View & VRIO Framework",
			"Cost Leadership vs Differentiation Trade-offs",
			"Corporate Strategy: Mergers & Diversification",
			"Disruptive Innovation & Digital Transformation"
		]
	},
	{
		id: "supply-chain-mit",
		title: "Operations & Supply Chain Management",
		desc: "Inventory theory, Economic Order Quantity (EOQ), bottleneck analysis, Lean Six Sigma, and global logistics.",
		duration: "13 hours",
		lessons: 15,
		level: "Intermediate",
		skills: [
			"Supply Chain",
			"Operations",
			"Logistics"
		],
		goals: ["Business & Marketing Specialist"],
		bg: "bg-blush",
		category: "Commerce & Finance",
		stream: "Management & Business",
		educationLevels: [
			"Undergraduate",
			"Postgraduate",
			"Working Professional"
		],
		provider: "MIT OpenCourseWare",
		format: "Structured course",
		pricing: "Free",
		url: "https://ocw.mit.edu/courses/15-772j-d-lab-supply-chains-fall-2016/",
		syllabus: [
			"Process Flow Analysis & Little's Law",
			"Safety Stock & Bullwhip Effect Mitigation",
			"Total Quality Management & DMAIC Methodology",
			"Warehousing & Network Routing Optimization",
			"Sustainable Green Supply Chains"
		]
	},
	{
		id: "fintech-blockchain-payments",
		title: "FinTech Innovations, Digital Payments & Crypto",
		desc: "Decentralized ledgers, consensus protocols, smart contracts, UPI infrastructure, and open banking APIs.",
		duration: "8 hours",
		lessons: 10,
		level: "Intermediate",
		skills: [
			"FinTech",
			"Blockchain",
			"Digital Payments"
		],
		goals: ["Chartered Accountant / Finance Specialist", "Full Stack Engineer"],
		bg: "bg-lilac",
		category: "Commerce & Finance",
		stream: "Commerce & Finance",
		educationLevels: [
			"Undergraduate",
			"Postgraduate",
			"Working Professional"
		],
		provider: "HKUST / Coursera",
		format: "Self-paced video",
		pricing: "Free to audit",
		url: "https://www.coursera.org/specializations/fintech",
		syllabus: [
			"Evolution of Payment Rails: SWIFT to Real-Time UPI",
			"Distributed Ledger Technology & Proof of Work/Stake",
			"Smart Contracts & Decentralized Finance (DeFi)",
			"Open Banking & Regulatory Sandboxes",
			"CBDCs (Central Bank Digital Currencies) & Compliance"
		]
	},
	{
		id: "entrepreneurship-venture-building",
		title: "Startup Venture Building & Lean Launchpad",
		desc: "Customer discovery, minimum viable product iterations, cap tables, pitch deck structuring, and seed fundraising.",
		duration: "7 hours",
		lessons: 9,
		level: "Beginner",
		skills: [
			"Entrepreneurship",
			"Venture Building",
			"Fundraising"
		],
		goals: ["Business & Marketing Specialist"],
		bg: "bg-mint",
		category: "Commerce & Finance",
		stream: "Management & Business",
		educationLevels: [
			"Undergraduate",
			"Postgraduate",
			"Diploma",
			"Working Professional"
		],
		provider: "Stanford Online",
		format: "Project-based",
		pricing: "Free",
		url: "https://online.stanford.edu/",
		syllabus: [
			"Validating Market Size (TAM, SAM, SOM)",
			"Building a Low-Code MVP for Pre-Sales",
			"Unit Economics: LTV/CAC, Payback & Churn",
			"Cap Table Math & SAFE Notes Explained",
			"Crafting an Investor-Grade Seed Pitch Deck"
		]
	},
	{
		id: "indian-taxation-gst",
		title: "Indian Direct Taxation & GST Compliance",
		desc: "Income Tax Act provisions, corporate tax slabs, exemptions (Sec 80C/80D), Input Tax Credit (ITC), and GST returns.",
		duration: "10 hours",
		lessons: 12,
		level: "Intermediate",
		skills: [
			"Taxation",
			"GST",
			"Compliance"
		],
		goals: ["Chartered Accountant / Finance Specialist"],
		bg: "bg-butter",
		category: "Commerce & Finance",
		stream: "Commerce & Finance",
		educationLevels: ["Undergraduate", "Postgraduate"],
		provider: "SWAYAM / ICAI",
		format: "Structured course",
		pricing: "Free",
		url: "https://swayam.gov.in/",
		syllabus: [
			"Heads of Income: Salary, House Property & Business",
			"Capital Gains Calculation (Short vs Long Term)",
			"Deductions under Chapter VI-A & Tax Rebates",
			"GST Model: CGST, SGST & IGST Distribution",
			"Input Tax Credit Mechanism & GSTR-1/3B Filings"
		]
	},
	{
		id: "risk-management-banking",
		title: "Credit Risk & Enterprise Risk Management in Banking",
		desc: "Basel III norms, credit default modeling, value at risk (VaR), liquidity coverage ratios, and stress testing.",
		duration: "11 hours",
		lessons: 13,
		level: "Advanced",
		skills: [
			"Risk Management",
			"Banking",
			"Basel III"
		],
		goals: ["Chartered Accountant / Finance Specialist"],
		bg: "bg-blush",
		category: "Commerce & Finance",
		stream: "Commerce & Finance",
		educationLevels: ["Postgraduate", "Working Professional"],
		provider: "New York Institute of Finance / edX",
		format: "Structured course",
		pricing: "Free to audit",
		url: "https://www.edx.org/school/nyif",
		syllabus: [
			"Credit Scoring Models (Altman Z-Score & Logistic)",
			"Market Risk & Parametric Value at Risk (VaR)",
			"Basel III Capital Adequacy & Tier 1/2 Requirements",
			"Liquidity Coverage Ratio (LCR) & Net Stable Funding",
			"Macroeconomic Scenario Stress Testing"
		]
	},
	{
		id: "org-behavior-lbs",
		title: "Organizational Behavior & Team Dynamics",
		desc: "Motivational theories, group decision-making, conflict resolution, psychological safety, and organizational culture.",
		duration: "6 hours",
		lessons: 8,
		level: "Beginner",
		skills: [
			"Leadership",
			"Team Dynamics",
			"Communication"
		],
		goals: ["Business & Marketing Specialist"],
		bg: "bg-lilac",
		category: "Commerce & Finance",
		stream: "Management & Business",
		educationLevels: [
			"Undergraduate",
			"Postgraduate",
			"Working Professional"
		],
		provider: "London Business School",
		format: "Self-paced video",
		pricing: "Free to audit",
		url: "https://www.london.edu/",
		syllabus: [
			"Intrinsic vs Extrinsic Motivation (Self-Determination)",
			"Psychological Safety & High-Performing Teams",
			"Power Dynamics & Organizational Politics",
			"Leading Cultural Change across Distributed Teams",
			"Performance Appraisals & Feedback Loops"
		]
	},
	{
		id: "indian-polity-constitution-nlsiu",
		title: "Indian Constitution & Constitutional Law",
		desc: "Preamble, Fundamental Rights (Part III), Directive Principles, judicial review, writ jurisdiction, and basic structure.",
		duration: "16 hours",
		lessons: 18,
		level: "Intermediate",
		skills: [
			"Constitutional Law",
			"Indian Polity",
			"Legal Analysis"
		],
		goals: ["Legal Specialist / Corporate Lawyer", "Civil Services / UPSC Aspirant"],
		bg: "bg-lilac",
		category: "Law & Governance",
		stream: "Law & Civil Services",
		educationLevels: [
			"Undergraduate",
			"Postgraduate",
			"Competitive Exams",
			"Class 12"
		],
		provider: "NLSIU Bengaluru / NPTEL",
		format: "Structured course",
		pricing: "Free",
		url: "https://nptel.ac.in/courses/109104085",
		syllabus: [
			"Making of Constitution & Preamble Philosophy",
			"Articles 14, 19, 21: Due Process & Right to Privacy",
			"Writ Remedies under Article 32 & Article 226",
			"Federal Division of Powers (Union, State, Concurrent)",
			"Kesavananda Bharati & Basic Structure Doctrine"
		]
	},
	{
		id: "upsc-governance-administrative-system",
		title: "Indian Governance & Public Administration",
		desc: "Civil service structure, accountability mechanisms, CAG, election commission, e-governance, and citizen charters.",
		duration: "14 hours",
		lessons: 16,
		level: "Intermediate",
		skills: [
			"Public Administration",
			"Governance",
			"Policy Analysis"
		],
		goals: ["Civil Services / UPSC Aspirant"],
		bg: "bg-mint",
		category: "Law & Governance",
		stream: "Law & Civil Services",
		educationLevels: [
			"Undergraduate",
			"Postgraduate",
			"Competitive Exams"
		],
		provider: "SWAYAM / LBSNAA",
		format: "Structured course",
		pricing: "Free",
		url: "https://swayam.gov.in/",
		syllabus: [
			"Evolution of Indian Administrative Services",
			"Constitutional Bodies: UPSC, CAG, Election Commission",
			"Right to Information (RTI) & Social Audits",
			"E-Governance Initiatives (Digital India & Direct Benefit Transfer)",
			"Panchayati Raj & Grassroots Democratic Decentralization"
		]
	},
	{
		id: "legal-reasoning-jurisprudence",
		title: "Legal Reasoning, Jurisprudence & Statutory Interpretation",
		desc: "Legal logic, ratio decidendi vs obiter dicta, literal and golden rules of interpretation, and analytical jurisprudence.",
		duration: "10 hours",
		lessons: 12,
		level: "Beginner",
		skills: [
			"Legal Reasoning",
			"Jurisprudence",
			"Critical Thinking"
		],
		goals: ["Legal Specialist / Corporate Lawyer", "Civil Services / UPSC Aspirant"],
		bg: "bg-butter",
		category: "Law & Governance",
		stream: "Law & Civil Services",
		educationLevels: [
			"Class 12",
			"Undergraduate",
			"Competitive Exams"
		],
		provider: "Harvard Law School / edX",
		format: "Self-paced video",
		pricing: "Free to audit",
		url: "https://online-learning.harvard.edu/subject/law",
		syllabus: [
			"Schools of Jurisprudence: Natural, Positivist & Realist",
			"Deconstructing Judicial Precedents (Stare Decisis)",
			"Statutory Interpretation: Literal, Mischief & Purposive",
			"Logical Syllogisms in Legal Argumentation",
			"Analyzing Moot Court Briefs & Oral Arguments"
		]
	},
	{
		id: "international-law-human-rights",
		title: "International Law, Treaties & Human Rights",
		desc: "UN Charter, Geneva Conventions, state sovereignty, International Court of Justice (ICJ), and humanitarian law.",
		duration: "11 hours",
		lessons: 13,
		level: "Intermediate",
		skills: [
			"International Law",
			"Human Rights",
			"Treaty Analysis"
		],
		goals: [
			"Legal Specialist / Corporate Lawyer",
			"Civil Services / UPSC Aspirant",
			"Academic Researcher"
		],
		bg: "bg-blush",
		category: "Law & Governance",
		stream: "Law & Civil Services",
		educationLevels: ["Undergraduate", "Postgraduate"],
		provider: "Geneva Academy / Coursera",
		format: "Structured course",
		pricing: "Free to audit",
		url: "https://www.coursera.org/learn/international-law-in-action",
		syllabus: [
			"Sources of International Law: Treaties & Custom",
			"Sovereignty & State Responsibility in International Disputes",
			"Universal Declaration of Human Rights (UDHR) Machinery",
			"International Criminal Court (ICC) Jurisdiction",
			"Maritime Law & Exclusive Economic Zones (UNCLOS)"
		]
	},
	{
		id: "corporate-contract-law",
		title: "Corporate Law & Commercial Contract Drafting",
		desc: "Indian Contract Act (1872), offer-acceptance, consideration, indemnities, warranties, and Companies Act governance.",
		duration: "12 hours",
		lessons: 14,
		level: "Intermediate",
		skills: [
			"Contract Drafting",
			"Corporate Law",
			"Negotiation"
		],
		goals: ["Legal Specialist / Corporate Lawyer"],
		bg: "bg-lilac",
		category: "Law & Governance",
		stream: "Law & Civil Services",
		educationLevels: [
			"Undergraduate",
			"Postgraduate",
			"Working Professional"
		],
		provider: "NLSIU Bengaluru / SWAYAM",
		format: "Project-based",
		pricing: "Free",
		url: "https://swayam.gov.in/",
		syllabus: [
			"Essentials of a Valid Contract & Void Agreements",
			"Liquidated Damages vs Penalty Clauses",
			"Drafting Non-Disclosure & Shareholder Agreements",
			"Corporate Board Responsibilities under Companies Act 2013",
			"Arbitration & Dispute Resolution Clauses"
		]
	},
	{
		id: "public-policy-analysis-lse",
		title: "Public Policy Analysis, Design & Evaluation",
		desc: "Stakeholder mapping, cost-benefit analysis, regulatory impact assessments, policy design, and program monitoring.",
		duration: "9 hours",
		lessons: 11,
		level: "Intermediate",
		skills: [
			"Policy Analysis",
			"Economics",
			"Governance"
		],
		goals: ["Civil Services / UPSC Aspirant", "Legal Specialist / Corporate Lawyer"],
		bg: "bg-mint",
		category: "Law & Governance",
		stream: "Law & Civil Services",
		educationLevels: [
			"Undergraduate",
			"Postgraduate",
			"Working Professional"
		],
		provider: "London School of Economics / Online",
		format: "Structured course",
		pricing: "Free to audit",
		url: "https://www.lse.ac.uk/",
		syllabus: [
			"Policy Formulation & Problem Definition",
			"Ex-Ante Cost-Benefit & Cost-Effectiveness Calculations",
			"Stakeholder Political Economy Analysis",
			"Randomized Control Trials for Policy Evaluation",
			"Drafting White Papers & Legislative Briefs"
		]
	},
	{
		id: "criminal-law-justice-london",
		title: "Criminal Law & Criminal Justice Administration",
		desc: "Elements of crime (Actus Reus & Mens Rea), Bharatiya Nyaya Sanhita, criminal procedure, bail, and forensic evidence.",
		duration: "13 hours",
		lessons: 15,
		level: "Intermediate",
		skills: [
			"Criminal Law",
			"Evidence Law",
			"Procedure"
		],
		goals: ["Legal Specialist / Corporate Lawyer", "Civil Services / UPSC Aspirant"],
		bg: "bg-butter",
		category: "Law & Governance",
		stream: "Law & Civil Services",
		educationLevels: ["Undergraduate", "Postgraduate"],
		provider: "University of London / Coursera",
		format: "Structured course",
		pricing: "Free to audit",
		url: "https://www.coursera.org/learn/criminal-law",
		syllabus: [
			"Actus Reus, Mens Rea & Strict Liability",
			"Offenses Against the Human Body (Homicide & Assault)",
			"Offenses Against Property (Theft, Extortion, Fraud)",
			"Arrest, Search, Seizure & Constitutional Protections",
			"Admissibility of Digital & Forensic Evidence"
		]
	},
	{
		id: "environmental-law-sustainability",
		title: "Environmental Law & Sustainable Development",
		desc: "Polluter pays principle, precautionary principle, National Green Tribunal (NGT), and climate accords.",
		duration: "8 hours",
		lessons: 10,
		level: "Beginner",
		skills: [
			"Environmental Law",
			"Policy",
			"Sustainability"
		],
		goals: ["Legal Specialist / Corporate Lawyer", "Civil Services / UPSC Aspirant"],
		bg: "bg-blush",
		category: "Law & Governance",
		stream: "Law & Civil Services",
		educationLevels: ["Undergraduate", "Postgraduate"],
		provider: "National Law University / SWAYAM",
		format: "Self-paced video",
		pricing: "Free",
		url: "https://swayam.gov.in/",
		syllabus: [
			"Stockholm to Paris: International Climate Frameworks",
			"Environment Protection Act (1986) & EIA Notifications",
			"National Green Tribunal Powers & Landmark Rulings",
			"Forest Conservation & Tribal Rights Protection",
			"Corporate ESG (Environmental, Social, Governance) Mandates"
		]
	},
	{
		id: "ipr-patent-law-wipo",
		title: "Intellectual Property Rights & Patent Law",
		desc: "Patentability criteria, prior art searching, copyright fair use, trademark distinctiveness, and Trade Secrets.",
		duration: "8 hours",
		lessons: 10,
		level: "Intermediate",
		skills: [
			"Intellectual Property",
			"Patents",
			"Copyright"
		],
		goals: ["Legal Specialist / Corporate Lawyer", "Full Stack Engineer"],
		bg: "bg-lilac",
		category: "Law & Governance",
		stream: "Law & Civil Services",
		educationLevels: [
			"Undergraduate",
			"Postgraduate",
			"Working Professional"
		],
		provider: "WIPO Academy / NPTEL",
		format: "Structured course",
		pricing: "Free",
		url: "https://www.wipo.int/academy/en/",
		syllabus: [
			"Patent Novelty, Inventive Step & Industrial Applicability",
			"Patent Specification Drafting & Claims Scope",
			"Copyright Protection for Software & Generative Content",
			"Trademark Registration & Infringement Remedies",
			"TRIPS Agreement & Compulsory Licensing"
		]
	},
	{
		id: "upsc-indian-economy-core",
		title: "Indian Economy for Civil Services & Policy Makers",
		desc: "Agricultural supply chains, industrial growth, monetary trends, fiscal consolidation, and external sector reserves.",
		duration: "14 hours",
		lessons: 16,
		level: "Intermediate",
		skills: [
			"Indian Economy",
			"Economics",
			"Policy"
		],
		goals: ["Civil Services / UPSC Aspirant"],
		bg: "bg-mint",
		category: "Law & Governance",
		stream: "Commerce & Finance",
		educationLevels: [
			"Undergraduate",
			"Postgraduate",
			"Competitive Exams"
		],
		provider: "SWAYAM / UGC",
		format: "Structured course",
		pricing: "Free",
		url: "https://swayam.gov.in/",
		syllabus: [
			"Post-Independence Economic Reforms & LPG 1991",
			"Agriculture: MSP, Food Subsidy & Cold Storage Chains",
			"Manufacturing & Make in India / PLI Schemes",
			"Banking NPAs, Insolvency & Bankruptcy Code (IBC)",
			"Balance of Payments & Foreign Direct Investment Trends"
		]
	},
	{
		id: "ethics-integrity-lbsnaa",
		title: "Ethics, Integrity & Aptitude for Civil Services (GS IV)",
		desc: "Ethical philosophy, moral dilemmas in public service, probity in governance, emotional intelligence, and case studies.",
		duration: "10 hours",
		lessons: 12,
		level: "Intermediate",
		skills: [
			"Ethics",
			"Emotional Intelligence",
			"Case Study Analysis"
		],
		goals: ["Civil Services / UPSC Aspirant"],
		bg: "bg-butter",
		category: "Law & Governance",
		stream: "Law & Civil Services",
		educationLevels: [
			"Undergraduate",
			"Postgraduate",
			"Competitive Exams"
		],
		provider: "SWAYAM",
		format: "Project-based",
		pricing: "Free",
		url: "https://swayam.gov.in/",
		syllabus: [
			"Ethics in Public & Private Relationships",
			"Contributions of Moral Thinkers (Socrates, Kant, Gandhi)",
			"Emotional Intelligence in Conflict Situations",
			"Code of Conduct vs Code of Ethics for Civil Servants",
			"Deconstructing Complex Administrative Dilemma Cases"
		]
	},
	{
		id: "cyber-law-security-regulations",
		title: "Cyber Law, Digital Personal Data & IT Act",
		desc: "Information Technology Act 2000, Digital Personal Data Protection (DPDP) Act, intermediary liability, and forensics.",
		duration: "7 hours",
		lessons: 9,
		level: "Beginner",
		skills: [
			"Cyber Law",
			"Data Protection",
			"Compliance"
		],
		goals: [
			"Legal Specialist / Corporate Lawyer",
			"Full Stack Engineer",
			"Civil Services / UPSC Aspirant"
		],
		bg: "bg-blush",
		category: "Law & Governance",
		stream: "Law & Civil Services",
		educationLevels: [
			"Undergraduate",
			"Postgraduate",
			"Working Professional"
		],
		provider: "NPTEL / IIT Kharagpur",
		format: "Self-paced video",
		pricing: "Free",
		url: "https://nptel.ac.in/courses/106105195",
		syllabus: [
			"Cybercrimes: Phishing, Identity Theft & Ransomware",
			"Digital Signatures & Electronic Record Admissibility",
			"Intermediary Due Diligence & Safe Harbor Norms",
			"India's DPDP Act: Consent, Data Fiduciaries & Penalties",
			"CERT-In Incident Reporting Guidelines"
		]
	},
	{
		id: "psychology-fundamentals-yale",
		title: "Introduction to Psychology: Mind and Behavior",
		desc: "Perception, memory retention, cognitive biases, child development, mental health, and social psychology with Paul Bloom.",
		duration: "12 hours",
		lessons: 15,
		level: "Beginner",
		skills: [
			"Psychology",
			"Behavioral Science",
			"Cognitive Science"
		],
		goals: ["Psychologist / Behavioral Specialist", "Academic Researcher"],
		bg: "bg-lilac",
		category: "Humanities & Social Sciences",
		stream: "Arts & Humanities",
		educationLevels: [
			"Class 11",
			"Class 12",
			"Undergraduate",
			"Working Professional"
		],
		provider: "Yale Online / Coursera",
		format: "Self-paced video",
		pricing: "Free to audit",
		url: "https://www.coursera.org/learn/introduction-psych",
		syllabus: [
			"Brain Anatomy & Neural Communication",
			"Freud, Skinner & Behavioral Conditioning",
			"Cognitive Development (Piaget & Vygotsky)",
			"Memory Storage, Retrieval & False Memories",
			"Clinical Disorders & Evidence-Based Therapies"
		]
	},
	{
		id: "sociology-social-change",
		title: "Introduction to Sociology: Structure & Social Change",
		desc: "Social stratification, class, caste, gender, institutions of family and religion, urbanization, and social movements.",
		duration: "10 hours",
		lessons: 12,
		level: "Beginner",
		skills: [
			"Sociology",
			"Social Research",
			"Critical Thinking"
		],
		goals: ["Academic Researcher", "Civil Services / UPSC Aspirant"],
		bg: "bg-mint",
		category: "Humanities & Social Sciences",
		stream: "Arts & Humanities",
		educationLevels: [
			"Class 12",
			"Undergraduate",
			"Postgraduate"
		],
		provider: "University of Amsterdam / Coursera",
		format: "Self-paced video",
		pricing: "Free to audit",
		url: "https://www.coursera.org/learn/classical-sociological-theory",
		syllabus: [
			"Classical Foundations: Marx, Weber & Durkheim",
			"Social Stratification: Class, Caste & Privilege",
			"Social Institutions: Kinship, Religion & State",
			"Urbanization, Migration & Slum Communities",
			"Contemporary Social Movements in the Digital Age"
		]
	},
	{
		id: "world-history-civilizations",
		title: "World History: Ancient Roots to Modern Globalization",
		desc: "River valley civilizations, the Silk Road, scientific revolution, industrialization, world wars, and post-colonial nations.",
		duration: "14 hours",
		lessons: 16,
		level: "Beginner",
		skills: [
			"History",
			"Historical Analysis",
			"Global Politics"
		],
		goals: ["Civil Services / UPSC Aspirant", "Academic Researcher"],
		bg: "bg-butter",
		category: "Humanities & Social Sciences",
		stream: "Arts & Humanities",
		educationLevels: [
			"Class 10",
			"Class 11",
			"Class 12",
			"Undergraduate"
		],
		provider: "Columbia University / edX",
		format: "Structured course",
		pricing: "Free to audit",
		url: "https://www.edx.org/learn/history",
		syllabus: [
			"Mesopotamia, Indus Valley & Egyptian Civilizations",
			"The Silk Road & Eurasian Cultural Exchanges",
			"European Enlightenment & Democratic Revolutions",
			"Industrial Revolution & Global Imperialism",
			"Cold War Geopolitics & Decolonization"
		]
	},
	{
		id: "international-relations-sciencespo",
		title: "International Relations: Diplomacy & Geopolitics",
		desc: "Realism, liberalism, constructivism, deterrence theory, global trade pacts, and modern multilateral diplomacy.",
		duration: "11 hours",
		lessons: 13,
		level: "Intermediate",
		skills: [
			"International Relations",
			"Diplomacy",
			"Geopolitics"
		],
		goals: [
			"Civil Services / UPSC Aspirant",
			"Academic Researcher",
			"Legal Specialist / Corporate Lawyer"
		],
		bg: "bg-blush",
		category: "Humanities & Social Sciences",
		stream: "Arts & Humanities",
		educationLevels: [
			"Undergraduate",
			"Postgraduate",
			"Competitive Exams"
		],
		provider: "Sciences Po / Coursera",
		format: "Structured course",
		pricing: "Free to audit",
		url: "https://www.coursera.org/learn/geopolitics",
		syllabus: [
			"Theories of IR: Realism, Neoliberalism & Constructivism",
			"Balance of Power & Nuclear Deterrence Dynamics",
			"Multilateralism & The Future of the United Nations",
			"Energy Geopolitics & Maritime Chokepoints",
			"Cyber Warfare & Non-State Global Actors"
		]
	},
	{
		id: "political-philosophy-plato-rawls",
		title: "Political Philosophy: Justice, Power & Freedom",
		desc: "Plato's Republic, Machiavelli's Prince, social contract theory (Hobbes/Locke/Rousseau), and John Rawls' Veil of Ignorance.",
		duration: "9 hours",
		lessons: 11,
		level: "Intermediate",
		skills: [
			"Political Philosophy",
			"Ethics",
			"Logic"
		],
		goals: [
			"Legal Specialist / Corporate Lawyer",
			"Civil Services / UPSC Aspirant",
			"Academic Researcher"
		],
		bg: "bg-lilac",
		category: "Humanities & Social Sciences",
		stream: "Arts & Humanities",
		educationLevels: ["Undergraduate", "Postgraduate"],
		provider: "Oxford Podcasts / MIT OCW",
		format: "Self-paced video",
		pricing: "Free",
		url: "https://ocw.mit.edu/courses/24-04j-justice-spring-2012/",
		syllabus: [
			"Justice in Plato's Republic & Philosopher Kings",
			"Pragmatic Statecraft in Machiavelli's The Prince",
			"The State of Nature: Hobbes vs Locke vs Rousseau",
			"Marxist Critique of Capitalism & Alienation",
			"John Rawls: Theory of Justice & Difference Principle"
		]
	},
	{
		id: "journalism-digital-reporting",
		title: "Journalism Fundamentals & Digital Investigative Reporting",
		desc: "Source verification, interviewing techniques, freedom of press ethics, data journalism, and multimedia storytelling.",
		duration: "7 hours",
		lessons: 9,
		level: "Beginner",
		skills: [
			"Journalism",
			"Investigative Reporting",
			"Writing"
		],
		goals: ["Academic Researcher", "Communication Specialist"],
		bg: "bg-mint",
		category: "Humanities & Social Sciences",
		stream: "Arts & Humanities",
		educationLevels: [
			"Class 12",
			"Diploma",
			"Undergraduate"
		],
		provider: "Reuters / Coursera",
		format: "Project-based",
		pricing: "Free to audit",
		url: "https://www.coursera.org/learn/journalism-fundamentals",
		syllabus: [
			"The Five Ws and H of News Structuring",
			"Fact-Checking, OSINT & Digital Verification",
			"Cultivating Sources & On/Off the Record Ethics",
			"Freedom of Information Acts (FOIA) & Data Mining",
			"Podcast & Long-form Multimedia Production"
		]
	},
	{
		id: "english-literature-critical-analysis",
		title: "Literary Analysis & Critical Theory",
		desc: "Close reading of poetry and prose, narrative structure, post-colonial theory, and psychoanalytic literary interpretation.",
		duration: "8 hours",
		lessons: 10,
		level: "Intermediate",
		skills: [
			"Literary Analysis",
			"Critical Reading",
			"Academic Writing"
		],
		goals: ["Academic Researcher"],
		bg: "bg-butter",
		category: "Humanities & Social Sciences",
		stream: "Arts & Humanities",
		educationLevels: [
			"Class 11",
			"Class 12",
			"Undergraduate"
		],
		provider: "Oxford University Online",
		format: "Structured course",
		pricing: "Free",
		url: "https://podcasts.ox.ac.uk/series/approaching-literature",
		syllabus: [
			"Techniques of Close Reading & Rhetorical Figures",
			"Modernist Narrative & Stream of Consciousness",
			"Post-Colonial Literature: Voice & Subaltern Agency",
			"Feminist & Marxist Literary Lenses",
			"Structuring Comparative Literature Essays"
		]
	},
	{
		id: "social-research-methods-nptel",
		title: "Qualitative & Quantitative Social Research Methods",
		desc: "Ethnography, participant observation, structured surveys, sample representation, coding interview transcripts, and ethics.",
		duration: "12 hours",
		lessons: 14,
		level: "Intermediate",
		skills: [
			"Research Methods",
			"Data Collection",
			"Qualitative Analysis"
		],
		goals: [
			"Academic Researcher",
			"User Research Specialist",
			"Civil Services / UPSC Aspirant"
		],
		bg: "bg-blush",
		category: "Humanities & Social Sciences",
		stream: "Arts & Humanities",
		educationLevels: [
			"Undergraduate",
			"Postgraduate",
			"PhD / Research"
		],
		provider: "NPTEL / IIT Madras",
		format: "Structured course",
		pricing: "Free",
		url: "https://nptel.ac.in/courses/109106161",
		syllabus: [
			"Formulating Testable Social Hypotheses",
			"Probability vs Non-Probability Sampling Designs",
			"Fieldwork Ethics & Institutional Review Boards (IRB)",
			"Grounded Theory & Thematic Coding in NVivo",
			"Triangulation of Qualitative & Quantitative Findings"
		]
	},
	{
		id: "human-geography-demographics",
		title: "Human Geography, Urbanization & Demography",
		desc: "Malthusian vs demographic transition models, migration patterns, spatial inequalities, smart cities, and mapping GIS.",
		duration: "9 hours",
		lessons: 11,
		level: "Beginner",
		skills: [
			"Geography",
			"Demographics",
			"Spatial Analysis"
		],
		goals: ["Civil Services / UPSC Aspirant", "Academic Researcher"],
		bg: "bg-lilac",
		category: "Humanities & Social Sciences",
		stream: "Arts & Humanities",
		educationLevels: [
			"Class 11",
			"Class 12",
			"Undergraduate",
			"Competitive Exams"
		],
		provider: "University College London / edX",
		format: "Self-paced video",
		pricing: "Free to audit",
		url: "https://www.edx.org/learn/geography",
		syllabus: [
			"The Demographic Transition Model & Population Pyramids",
			"Push-Pull Factors in Rural-Urban Migration",
			"Central Place Theory & Urban Polycentric Hubs",
			"Spatial Inequality & Gentrification Mechanics",
			"GIS (Geographic Information Systems) Basics"
		]
	},
	{
		id: "cultural-anthropology-smithsonian",
		title: "Cultural Anthropology & Human Diversity",
		desc: "Kinship systems, rituals and belief systems, linguistic relativity, material culture, and cross-cultural ethnography.",
		duration: "8 hours",
		lessons: 10,
		level: "Beginner",
		skills: [
			"Anthropology",
			"Cultural Intelligence",
			"Critical Thinking"
		],
		goals: ["Academic Researcher"],
		bg: "bg-mint",
		category: "Humanities & Social Sciences",
		stream: "Arts & Humanities",
		educationLevels: ["Undergraduate", "Postgraduate"],
		provider: "Smithsonian Institution / edX",
		format: "Self-paced video",
		pricing: "Free to audit",
		url: "https://www.edx.org/learn/anthropology",
		syllabus: [
			"The Concept of Culture & Cultural Relativism",
			"Language & the Sapir-Whorf Hypothesis",
			"Ritual, Myth & Symbolic Meaning in Societies",
			"Kinship, Descent & Marital Alliances",
			"Decolonizing Anthropological Fieldwork"
		]
	},
	{
		id: "gender-studies-social-justice",
		title: "Gender Studies, Intersectionality & Social Justice",
		desc: "Historical waves of feminism, gender performativity, intersectionality, wage parity economics, and human rights.",
		duration: "7 hours",
		lessons: 9,
		level: "Beginner",
		skills: [
			"Gender Studies",
			"Intersectionality",
			"Social Justice"
		],
		goals: [
			"Civil Services / UPSC Aspirant",
			"Academic Researcher",
			"Legal Specialist / Corporate Lawyer"
		],
		bg: "bg-butter",
		category: "Humanities & Social Sciences",
		stream: "Arts & Humanities",
		educationLevels: ["Undergraduate", "Postgraduate"],
		provider: "University of London / Coursera",
		format: "Structured course",
		pricing: "Free to audit",
		url: "https://www.coursera.org/learn/gender-studies",
		syllabus: [
			"Sex vs Gender & Judith Butler's Performativity",
			"Intersectionality: Race, Caste, Class & Gender",
			"The Economics of Care Work & Gender Pay Gaps",
			"Global Conventions: CEDAW & Legal Protections",
			"Men & Masculinity Studies: Cultural Conditioning"
		]
	},
	{
		id: "environmental-economics-climate",
		title: "Environmental Economics & Climate Governance",
		desc: "Carbon pricing, cap-and-trade systems, externalities, Tragedy of the Commons, and renewable transition economics.",
		duration: "8 hours",
		lessons: 10,
		level: "Intermediate",
		skills: [
			"Environmental Economics",
			"Public Policy",
			"Climate Science"
		],
		goals: [
			"Civil Services / UPSC Aspirant",
			"Chartered Accountant / Finance Specialist",
			"Academic Researcher"
		],
		bg: "bg-blush",
		category: "Humanities & Social Sciences",
		stream: "Commerce & Finance",
		educationLevels: [
			"Undergraduate",
			"Postgraduate",
			"Working Professional"
		],
		provider: "World Bank Group / edX",
		format: "Self-paced video",
		pricing: "Free to audit",
		url: "https://www.edx.org/school/wbgx",
		syllabus: [
			"Market Failures & Negative Externalities",
			"Pigouvian Taxes vs Cap-and-Trade Markets",
			"Valuing Ecosystem Services (Contingent Valuation)",
			"Renewable Energy Subsidies & Grid Parity",
			"Loss and Damage Funds in Global Climate Treaties"
		]
	},
	{
		id: "speaking-with-confidence",
		title: "Speaking with Confidence & Executive Presence",
		desc: "Structure high-impact talks, eliminate filler words, control vocal pacing, and deliver compelling STAR presentations.",
		duration: "3 hours",
		lessons: 6,
		level: "Beginner",
		skills: [
			"Communication",
			"Public Speaking",
			"Executive Presence"
		],
		goals: [
			"Frontend Developer",
			"UI/UX Designer",
			"Full Stack Engineer",
			"Business & Marketing Specialist",
			"Civil Services / UPSC Aspirant"
		],
		bg: "bg-blush",
		category: "Professional Skills",
		stream: "Essential & Soft Skills",
		educationLevels: [
			"Class 10",
			"Class 11",
			"Class 12",
			"Diploma",
			"Undergraduate",
			"Postgraduate",
			"Working Professional"
		],
		provider: "Pathfinder / Communication Track",
		format: "Interactive hands-on",
		pricing: "Free",
		url: "https://www.toastmasters.org/",
		syllabus: [
			"The Anatomy of Stage Fright & Diaphragmatic Breathing",
			"Structuring Your Speech with the Rule of Three",
			"Using the STAR Framework for Behavioral Stories",
			"Eliminating Fillers ('Um', 'Like', 'You know')",
			"Q&A Deflection & Handling Hostile Inquiries"
		]
	},
	{
		id: "critical-thinking-problem-solving",
		title: "Critical Thinking, Logic & Cognitive Debbiasing",
		desc: "Identify logical fallacies, break down complex root causes with First Principles, and evaluate arguments rigorously.",
		duration: "5 hours",
		lessons: 7,
		level: "Beginner",
		skills: [
			"Critical Thinking",
			"Problem Solving",
			"Logic"
		],
		goals: [
			"Full Stack Engineer",
			"Legal Specialist / Corporate Lawyer",
			"Data Analyst",
			"Civil Services / UPSC Aspirant"
		],
		bg: "bg-mint",
		category: "Professional Skills",
		stream: "Essential & Soft Skills",
		educationLevels: [
			"Class 11",
			"Class 12",
			"Undergraduate",
			"Postgraduate",
			"Competitive Exams"
		],
		provider: "University of Queensland / edX",
		format: "Interactive hands-on",
		pricing: "Free to audit",
		url: "https://www.edx.org/course/critical-thinking",
		syllabus: [
			"Formal vs Informal Logical Fallacies (Ad Hominem, Strawman)",
			"First Principles Thinking (Elon Musk / Aristotle)",
			"Root Cause Analysis: 5 Whys & Fishbone Diagrams",
			"Cognitive Biases (Confirmation, Anchoring, Availability)",
			"Constructing Valid Deductive & Inductive Arguments"
		]
	},
	{
		id: "academic-writing-publishing",
		title: "Academic Writing, Literature Reviews & Publishing",
		desc: "Draft peer-reviewed scientific papers, write crisp abstracts, cite in APA/IEEE, and navigate journal peer reviews.",
		duration: "7 hours",
		lessons: 9,
		level: "Intermediate",
		skills: [
			"Academic Writing",
			"Research",
			"Scientific Communication"
		],
		goals: ["Academic Researcher", "Postgraduate Student"],
		bg: "bg-butter",
		category: "Professional Skills",
		stream: "Essential & Soft Skills",
		educationLevels: [
			"Undergraduate",
			"Postgraduate",
			"PhD / Research"
		],
		provider: "Stanford Online",
		format: "Self-paced video",
		pricing: "Free",
		url: "https://online.stanford.edu/courses/som-y0010-writing-sciences",
		syllabus: [
			"Principles of Clear & Concise Scientific Prose",
			"Structuring IMRaD (Intro, Methods, Results, Discussion)",
			"Writing Compelling Abstracts & Effective Titles",
			"Citation Management with Zotero & Mendeley",
			"Responding to Peer Reviewers' Critique Constructively"
		]
	},
	{
		id: "project-management-google",
		title: "Project Management Foundations (PMP Ready)",
		desc: "Agile, Scrum, sprint planning, Kanban boards, risk registers, stakeholder RACI matrices, and project deliverables.",
		duration: "9 hours",
		lessons: 11,
		level: "Beginner",
		skills: [
			"Project Management",
			"Agile",
			"Scrum"
		],
		goals: [
			"Business & Marketing Specialist",
			"Full Stack Engineer",
			"UI/UX Designer"
		],
		bg: "bg-lilac",
		category: "Professional Skills",
		stream: "Management & Business",
		educationLevels: [
			"Diploma",
			"Undergraduate",
			"Postgraduate",
			"Working Professional"
		],
		provider: "Google Career Certificates",
		format: "Project-based",
		pricing: "Free to audit",
		url: "https://grow.google/certificates/project-management/",
		syllabus: [
			"Project Charters & Triple Constraint (Scope, Time, Cost)",
			"Work Breakdown Structures (WBS) & Gantt Scheduling",
			"Agile Manifesto, User Stories & Fibonacci Story Points",
			"Scrum Ceremonies: Daily Standups, Reviews & Retros",
			"Risk Mitigation Planning & RACI Assignment"
		]
	},
	{
		id: "cross-cultural-collaboration",
		title: "Cross-Cultural Communication in Global Teams",
		desc: "High vs low-context cultures, asynchronous communication etiquette, remote team workflows, and global collaboration.",
		duration: "4 hours",
		lessons: 6,
		level: "Beginner",
		skills: [
			"Communication",
			"Cultural Intelligence",
			"Collaboration"
		],
		goals: [
			"Frontend Developer",
			"Full Stack Engineer",
			"Business & Marketing Specialist"
		],
		bg: "bg-mint",
		category: "Professional Skills",
		stream: "Essential & Soft Skills",
		educationLevels: [
			"Undergraduate",
			"Postgraduate",
			"Working Professional"
		],
		provider: "University of Michigan / Coursera",
		format: "Self-paced video",
		pricing: "Free to audit",
		url: "https://www.coursera.org/learn/communication",
		syllabus: [
			"Hofstede's 6 Cultural Dimensions Explained",
			"High-Context vs Low-Context Communication Nuances",
			"Asynchronous Slack & Email Etiquette across Timezones",
			"Navigating Direct vs Indirect Negative Feedback",
			"Building Trust and Inclusivity in Remote Teams"
		]
	},
	{
		id: "quantitative-reasoning-khan",
		title: "Quantitative Reasoning & Aptitude for Competitive Exams",
		desc: "Ratios, percentages, profit and loss, time and work, speed-distance-time, data sufficiency, and series patterns.",
		duration: "10 hours",
		lessons: 13,
		level: "Beginner",
		skills: [
			"Quantitative Aptitude",
			"Problem Solving",
			"Speed Math"
		],
		goals: [
			"Competitive Exams Aspirant",
			"Civil Services / UPSC Aspirant",
			"Secondary School Student (Class 10-12)"
		],
		bg: "bg-butter",
		category: "Professional Skills",
		stream: "Essential & Soft Skills",
		educationLevels: [
			"Class 10",
			"Class 11",
			"Class 12",
			"Undergraduate",
			"Competitive Exams"
		],
		provider: "Khan Academy",
		format: "Interactive hands-on",
		pricing: "Free",
		url: "https://www.khanacademy.org/math",
		syllabus: [
			"Speed Multiplication & Vedic Math Shortcuts",
			"Percentages, Profit/Loss & Marked Price Calculations",
			"Time, Work & Pipes/Cisterns Principles",
			"Relative Speed & Train/Boat Collision Problems",
			"Data Interpretation: Pie Charts, Bar Graphs & Tables"
		]
	},
	{
		id: "time-management-deep-work",
		title: "Time Management, Deep Work & Focus Habits",
		desc: "Cal Newport's Deep Work rules, time-blocking, Pomodoro techniques, attention management, and reducing burnout.",
		duration: "3 hours",
		lessons: 5,
		level: "Beginner",
		skills: [
			"Time Management",
			"Focus",
			"Personal Productivity"
		],
		goals: [
			"Frontend Developer",
			"Secondary School Student (Class 10-12)",
			"Competitive Exams Aspirant",
			"Academic Researcher"
		],
		bg: "bg-blush",
		category: "Professional Skills",
		stream: "Essential & Soft Skills",
		educationLevels: [
			"Class 10",
			"Class 11",
			"Class 12",
			"Undergraduate",
			"Postgraduate",
			"Working Professional"
		],
		provider: "Pathfinder / Productivity Track",
		format: "Self-paced video",
		pricing: "Free",
		url: "https://calnewport.com/books/deep-work/",
		syllabus: [
			"The Myth of Multitasking & Attention Residue",
			"Calendar Time-Blocking & Daily Shutdown Rituals",
			"Overcoming Procrastination with 5-Minute Rules",
			"Managing Digital Distractions & Dopamine Loops",
			"Energy Audits: Aligning Hard Tasks with Peak Circadian Hours"
		]
	},
	{
		id: "data-storytelling-dashboards",
		title: "Data Storytelling & Executive Visual Presentations",
		desc: "Transform dry metrics into compelling business narratives, choose the right chart types, and present to leadership.",
		duration: "5 hours",
		lessons: 7,
		level: "Intermediate",
		skills: [
			"Data Storytelling",
			"Communication",
			"Data Visualization"
		],
		goals: [
			"Data Analyst",
			"Business & Marketing Specialist",
			"UI/UX Designer"
		],
		bg: "bg-lilac",
		category: "Professional Skills",
		stream: "Essential & Soft Skills",
		educationLevels: [
			"Undergraduate",
			"Postgraduate",
			"Working Professional"
		],
		provider: "Pathfinder / Analytics Track",
		format: "Project-based",
		pricing: "Free",
		url: "https://www.storytellingwithdata.com/",
		syllabus: [
			"The Narrative Arc: Context, Conflict & Resolution",
			"Selecting the Right Chart (Decluttering Pie & Dual-Axis Charts)",
			"Eliminating Clutter & Cognitive Load in Visuals",
			"Focusing Attention with Pre-Attentive Visual Attributes",
			"Pitching Data Insights to C-Level Stakeholders"
		]
	},
	{
		id: "negotiation-conflict-harvard",
		title: "Principled Negotiation & Conflict Resolution",
		desc: "Getting to Yes framework, BATNA analysis, anchoring tactics, integrative bargaining, and emotional composure.",
		duration: "6 hours",
		lessons: 8,
		level: "Intermediate",
		skills: [
			"Negotiation",
			"Conflict Resolution",
			"Communication"
		],
		goals: [
			"Business & Marketing Specialist",
			"Legal Specialist / Corporate Lawyer",
			"Frontend Developer"
		],
		bg: "bg-mint",
		category: "Professional Skills",
		stream: "Essential & Soft Skills",
		educationLevels: [
			"Undergraduate",
			"Postgraduate",
			"Working Professional"
		],
		provider: "Harvard Program on Negotiation / Coursera",
		format: "Interactive hands-on",
		pricing: "Free to audit",
		url: "https://www.pon.harvard.edu/",
		syllabus: [
			"Separate the People from the Problem",
			"Focus on Interests, Not Positions",
			"Determining & Improving Your BATNA",
			"Creating Value Through Multi-Issue Packaging",
			"Salary & Contract Negotiation Simulations"
		]
	},
	{
		id: "interview-prep",
		title: "Technical & Behavioral Interview Mastery",
		desc: "Live coding strategies, system design walkthroughs, STAR behavioral answers, and portfolio presentations.",
		duration: "5 hours",
		lessons: 9,
		level: "Advanced",
		skills: [
			"Communication",
			"Data Structures",
			"Interviewing"
		],
		goals: [
			"Frontend Developer",
			"UI/UX Designer",
			"Data Analyst",
			"Full Stack Engineer"
		],
		bg: "bg-butter",
		category: "Professional Skills",
		stream: "Essential & Soft Skills",
		educationLevels: [
			"Diploma",
			"Undergraduate",
			"Postgraduate",
			"Working Professional"
		],
		provider: "Pathfinder / Career Track",
		format: "Interactive hands-on",
		pricing: "Free",
		url: "https://leetcode.com/explore/",
		syllabus: [
			"Technical Problem Decomposition & Thinking Aloud",
			"Common Behavioral Traps & STAR Framework Mastery",
			"System Design & Architecture Whiteboarding",
			"Salary Negotiation and Asking Insightful Counter-Questions",
			"Post-Interview Follow-Up and Offer Evaluation"
		]
	},
	{
		id: "speed-reading-cognitive-retention",
		title: "Accelerated Learning, Speed Reading & Memory Retention",
		desc: "Subvocalization reduction, spaced repetition (Anki), Feynman technique, mind mapping, and memory palaces.",
		duration: "4 hours",
		lessons: 6,
		level: "Beginner",
		skills: [
			"Accelerated Learning",
			"Memory Techniques",
			"Cognitive Retention"
		],
		goals: [
			"Secondary School Student (Class 10-12)",
			"Competitive Exams Aspirant",
			"Academic Researcher",
			"Medical & Healthcare Aspirant"
		],
		bg: "bg-blush",
		category: "Professional Skills",
		stream: "Essential & Soft Skills",
		educationLevels: [
			"Class 10",
			"Class 11",
			"Class 12",
			"Undergraduate",
			"Competitive Exams"
		],
		provider: "Pathfinder / Cognitive Science Track",
		format: "Self-paced video",
		pricing: "Free",
		url: "https://fs.blog/learning/",
		syllabus: [
			"Visual Pacing & Reducing Vocal Subvocalization",
			"The Feynman Technique: Learn by Teaching Simply",
			"Spaced Repetition & Leitner Flashcard Algorithms",
			"Constructing Method of Loci (Memory Palaces)",
			"Active Recall Testing vs Passive Re-Reading"
		]
	}
];
var jobs = [
	{
		id: 1,
		title: "UI/UX Designer",
		company: "Voxa",
		location: "Bengaluru",
		type: "Full-time",
		salary: "₹12–18 LPA",
		match: 92,
		posted: "2d ago",
		tags: [
			"Figma",
			"Prototyping",
			"User research"
		],
		skills: [
			"Visual Design",
			"User Research",
			"Interaction Design"
		],
		color: "bg-lilac",
		description: "Design end-to-end flows for a consumer voice app, from research to high-fidelity prototypes.",
		eligibility: "0–2 years experience · Portfolio required · Any degree",
		apply: "Submit portfolio link and a short cover note. Demo listing."
	},
	{
		id: 2,
		title: "Frontend Developer",
		company: "Nimbus Labs",
		location: "Remote",
		type: "Full-time",
		salary: "₹10–16 LPA",
		match: 88,
		posted: "1d ago",
		tags: [
			"React",
			"Tailwind",
			"TypeScript"
		],
		skills: [
			"React",
			"TypeScript",
			"Frontend"
		],
		color: "bg-mint",
		description: "Build accessible React interfaces for a cloud dashboard and collaborate with designers on a component library.",
		eligibility: "Freshers welcome · Strong JavaScript & React basics",
		apply: "Share GitHub profile and resume. Demo listing."
	},
	{
		id: 3,
		title: "Product Designer Intern",
		company: "Brightpath",
		location: "Pune",
		type: "Internship",
		salary: "₹30k / month",
		match: 81,
		posted: "5h ago",
		tags: ["Design systems", "Figma"],
		skills: ["Visual Design", "Product Thinking"],
		color: "bg-butter",
		description: "6-month internship supporting the design system team with components, documentation and audits.",
		eligibility: "Final-year students or recent graduates",
		apply: "Resume + 2 case studies. Demo listing."
	},
	{
		id: 4,
		title: "Junior Web Developer",
		company: "Orbit Studio",
		location: "Hyderabad",
		type: "Full-time",
		salary: "₹6–9 LPA",
		match: 76,
		posted: "3d ago",
		tags: [
			"HTML",
			"CSS",
			"JavaScript"
		],
		skills: ["Frontend", "JavaScript"],
		color: "bg-blush",
		description: "Build and maintain marketing websites and landing pages for agency clients.",
		eligibility: "0–1 years · HTML/CSS/JS fundamentals",
		apply: "Resume and one live project link. Demo listing."
	},
	{
		id: 5,
		title: "Team Lead – Design",
		company: "Kite Health",
		location: "Remote",
		type: "Contract",
		salary: "₹20–26 LPA",
		match: 69,
		posted: "1w ago",
		tags: [
			"Leadership",
			"Feedback",
			"UX"
		],
		skills: ["Design Leadership", "Communication"],
		color: "bg-lilac",
		description: "Lead a team of 4 designers on a 12-month health platform contract.",
		eligibility: "4+ years design · 1+ year leading people",
		apply: "Portfolio and references. Demo listing."
	},
	{
		id: 6,
		title: "Tailwind CSS Developer",
		company: "Pixelcraft",
		location: "Mumbai",
		type: "Part-time",
		salary: "₹4–6 LPA",
		match: 85,
		posted: "4d ago",
		tags: ["Tailwind", "Responsive"],
		skills: ["Frontend"],
		color: "bg-mint",
		description: "Part-time role converting designs into responsive Tailwind pages.",
		eligibility: "Any experience · Tailwind portfolio",
		apply: "Share two Tailwind builds. Demo listing."
	}
];
var courses = ALL_COURSES;
var courseById = (id) => {
	const direct = ALL_COURSES.find((c) => c.id === id);
	if (direct) return direct;
	const aliases = {
		typescript: "typescript-essentials",
		dsa: "dsa-princeton",
		communication: "speaking-with-confidence",
		"ux-research": "ux-research-nng",
		"sql-analytics": "sql-perf-stanford",
		"design-systems": "figma-design-systems"
	};
	if (aliases[id]) return ALL_COURSES.find((c) => c.id === aliases[id]);
};
var careerDetails = {
	frontend: {
		goal: "Frontend Developer",
		skills: [
			"Frontend",
			"JavaScript",
			"React",
			"TypeScript",
			"Data Structures",
			"Communication"
		],
		responsibilities: [
			"Build responsive, accessible user interfaces",
			"Turn designs into reusable components",
			"Work with APIs and manage app state",
			"Review code and fix performance issues"
		],
		jobs: [
			2,
			4,
			6
		]
	},
	uiux: {
		goal: "UI/UX Designer",
		skills: [
			"Visual Design",
			"User Research",
			"Interaction Design",
			"Product Thinking",
			"Design Leadership",
			"Communication"
		],
		responsibilities: [
			"Research user needs and pain points",
			"Create wireframes and prototypes",
			"Maintain a design system",
			"Test designs with real users"
		],
		jobs: [
			1,
			3,
			5
		]
	},
	data: {
		goal: "Data Analyst",
		skills: [
			"Data Analysis",
			"SQL",
			"Python",
			"Data Structures",
			"Communication"
		],
		responsibilities: [
			"Clean and analyse datasets",
			"Build dashboards and reports",
			"Share insights with stakeholders",
			"Define and track key metrics"
		],
		jobs: []
	},
	ai_ml: {
		goal: "AI / Machine Learning Specialist",
		skills: [
			"Artificial Intelligence",
			"Machine Learning",
			"Python",
			"Deep Learning",
			"Mathematics"
		],
		responsibilities: [
			"Design and train machine learning models",
			"Fine-tune generative AI architectures and prompt flows",
			"Evaluate algorithmic bias and model safety",
			"Deploy scalable inference endpoints on edge/cloud"
		],
		jobs: []
	},
	fullstack: {
		goal: "Full Stack Engineer",
		skills: [
			"Frontend",
			"Backend",
			"APIs",
			"JavaScript",
			"TypeScript",
			"System Design"
		],
		responsibilities: [
			"Architect end-to-end web architectures",
			"Build scalable REST/GraphQL APIs and services",
			"Design relational schemas and optimization queries",
			"Manage CI/CD deployment pipelines"
		],
		jobs: [2, 4]
	},
	medical: {
		goal: "Medical & Healthcare Aspirant",
		skills: [
			"Human Anatomy",
			"Physiology",
			"Biochemistry",
			"Biology",
			"Medical Terminology"
		],
		responsibilities: [
			"Master foundational anatomical and physiological systems",
			"Understand clinical biochemistry pathways and biomarkers",
			"Prepare for medical entrance examinations (NEET / MCAT)",
			"Study patient safety protocols and bioethics"
		],
		jobs: []
	},
	school_student: {
		goal: "Secondary School Student (Class 10-12)",
		skills: [
			"Mathematics",
			"Physics",
			"Chemistry",
			"Biology",
			"Problem Solving"
		],
		responsibilities: [
			"Master core board curriculum standards (CBSE/ICSE/State)",
			"Build foundational conceptual clarity in science & math",
			"Prepare for board exams and competitive entrance tests",
			"Explore diverse career disciplines and future options"
		],
		jobs: []
	},
	commerce: {
		goal: "Chartered Accountant / Finance Specialist",
		skills: [
			"Financial Accounting",
			"Corporate Finance",
			"Taxation",
			"Economics",
			"Excel"
		],
		responsibilities: [
			"Analyze balance sheets, P&L statements, and cash flows",
			"Perform DCF valuation modeling and capital budgeting",
			"Ensure statutory direct tax and GST compliance",
			"Prepare for professional accounting credentials (CA, CFA, CPA)"
		],
		jobs: []
	},
	civil_services: {
		goal: "Civil Services / UPSC Aspirant",
		skills: [
			"Indian Polity",
			"Constitutional Law",
			"Governance",
			"Economics",
			"Ethics"
		],
		responsibilities: [
			"Master constitutional provisions and democratic governance",
			"Analyze national macroeconomics and budget policies",
			"Develop structured answer writing for public policy challenges",
			"Cultivate high ethical standards and administrative acumen"
		],
		jobs: []
	},
	lawyer: {
		goal: "Legal Specialist / Corporate Lawyer",
		skills: [
			"Constitutional Law",
			"Contract Drafting",
			"Legal Reasoning",
			"Corporate Law",
			"Jurisprudence"
		],
		responsibilities: [
			"Draft commercial contracts and shareholder agreements",
			"Conduct statutory compliance and regulatory analysis",
			"Interpret judicial precedents and statutory frameworks",
			"Analyze corporate disputes and intellectual property rights"
		],
		jobs: []
	},
	researcher: {
		goal: "Academic Researcher",
		skills: [
			"Academic Writing",
			"Research Methods",
			"Data Analysis",
			"Critical Thinking",
			"Qualitative Analysis"
		],
		responsibilities: [
			"Design rigorous scientific and social methodologies",
			"Conduct comprehensive peer-reviewed literature reviews",
			"Collect and analyze primary quantitative/qualitative data",
			"Publish discoveries in international journals"
		],
		jobs: []
	},
	business: {
		goal: "Business & Marketing Specialist",
		skills: [
			"Marketing",
			"Brand Strategy",
			"Strategic Management",
			"Project Management",
			"Leadership"
		],
		responsibilities: [
			"Develop go-to-market and user acquisition funnels",
			"Formulate competitive positioning and brand messaging",
			"Lead cross-functional agile project delivery",
			"Measure customer lifetime value and unit economics"
		],
		jobs: []
	}
};
var goalSkills = (goal) => {
	return Object.values(careerDetails).find((c) => c.goal.toLowerCase() === goal.toLowerCase() || goal.toLowerCase().includes(c.goal.toLowerCase()))?.skills ?? [];
};
/** Recommend courses for goal, ranked by educational background, stream, and skill gap size. */
function recommend(goal, skills, exclude = [], profile) {
	const need = goalSkills(goal);
	const userStream = (profile?.stream || "").toLowerCase();
	const userLevel = profile?.educationLevel || "";
	return ALL_COURSES.filter((c) => !exclude.includes(c.id)).map((c) => {
		let score = 0;
		let reason = "";
		const directGoal = c.goals.some((g) => g.toLowerCase().includes(goal.toLowerCase()) || goal.toLowerCase().includes(g.toLowerCase()));
		if (directGoal) score += 45;
		if (userStream && (c.stream.toLowerCase().includes(userStream) || userStream.includes(c.stream.toLowerCase()))) score += 35;
		if (userLevel && c.educationLevels.includes(userLevel)) score += 25;
		const matchingSkills = c.skills.filter((s) => need.includes(s) || skills[s] !== void 0);
		if (matchingSkills.length > 0) {
			const worst = matchingSkills.map((s) => ({
				s,
				v: skills[s] ?? 0
			})).sort((a, b) => a.v - b.v)[0];
			if (worst) {
				const gap = Math.max(0, 100 - worst.v);
				score += Math.round(gap * .4);
				reason = `Your ${worst.s} is at ${worst.v}% — this closes that gap for ${goal}.`;
			}
		}
		if (!reason) if (userLevel && c.educationLevels.includes(userLevel)) reason = `Specially curated for ${userLevel} students pursuing ${c.stream}.`;
		else if (userStream && c.stream.toLowerCase().includes(userStream)) reason = `Essential foundation for your ${c.stream} specialization.`;
		else if (directGoal) reason = `Recommended curriculum for your ${goal} target.`;
		else reason = `Strengthens core competency in ${c.skills[0] || c.category}.`;
		return {
			course: c,
			score,
			reason
		};
	}).sort((a, b) => b.score - a.score);
}
var testBank = {
	JavaScript: {
		skills: ["JavaScript", "Frontend"],
		questions: [
			{
				q: "What does `typeof null` return?",
				options: [
					"'null'",
					"'object'",
					"'undefined'",
					"'number'"
				],
				answer: 1,
				explain: "A historical quirk: typeof null is 'object'."
			},
			{
				q: "Which method creates a new array with transformed items?",
				options: [
					"forEach",
					"map",
					"reduce",
					"find"
				],
				answer: 1,
				explain: "map returns a new array of the callback results."
			},
			{
				q: "`===` compares…",
				options: [
					"Value only",
					"Type only",
					"Value and type",
					"References only"
				],
				answer: 2,
				explain: "Strict equality checks both value and type, no coercion."
			},
			{
				q: "Which keyword declares a block-scoped constant?",
				options: [
					"var",
					"let",
					"const",
					"static"
				],
				answer: 2,
				explain: "const is block-scoped and cannot be reassigned."
			},
			{
				q: "What does `Promise.all` do if one promise rejects?",
				options: [
					"Ignores it",
					"Rejects immediately",
					"Waits for all then resolves",
					"Retries"
				],
				answer: 1,
				explain: "Promise.all rejects as soon as any input rejects."
			}
		]
	},
	React: {
		skills: ["React", "Frontend"],
		questions: [
			{
				q: "Which hook stores local component state?",
				options: [
					"useEffect",
					"useState",
					"useMemo",
					"useRef"
				],
				answer: 1,
				explain: "useState returns a value and a setter."
			},
			{
				q: "Keys in lists help React…",
				options: [
					"Style items",
					"Identify items between renders",
					"Sort items",
					"Fetch data"
				],
				answer: 1,
				explain: "Keys let React match elements across renders."
			},
			{
				q: "useEffect with an empty dependency array runs…",
				options: [
					"Every render",
					"Never",
					"Once after mount",
					"Before mount"
				],
				answer: 2,
				explain: "[] means run after the first render only."
			},
			{
				q: "Props are…",
				options: [
					"Mutable by child",
					"Read-only inputs",
					"Global state",
					"CSS classes"
				],
				answer: 1,
				explain: "Children should treat props as read-only."
			},
			{
				q: "Which avoids recalculating an expensive value?",
				options: [
					"useMemo",
					"useState",
					"useId",
					"useContext"
				],
				answer: 0,
				explain: "useMemo caches a computed value between renders."
			}
		]
	},
	"Data Structures": {
		skills: ["Data Structures"],
		questions: [
			{
				q: "Average lookup time in a hash map?",
				options: [
					"O(n)",
					"O(log n)",
					"O(1)",
					"O(n²)"
				],
				answer: 2,
				explain: "Hash maps give constant average lookup."
			},
			{
				q: "A stack follows…",
				options: [
					"FIFO",
					"LIFO",
					"Random order",
					"Priority order"
				],
				answer: 1,
				explain: "Last in, first out."
			},
			{
				q: "Binary search requires…",
				options: [
					"A sorted array",
					"A linked list",
					"A hash map",
					"Duplicates"
				],
				answer: 0,
				explain: "It halves a sorted range each step."
			},
			{
				q: "Which is best for BFS?",
				options: [
					"Stack",
					"Queue",
					"Heap",
					"Set"
				],
				answer: 1,
				explain: "BFS processes nodes in queue order."
			}
		]
	},
	"Visual Design": {
		skills: ["Visual Design", "Interaction Design"],
		questions: [
			{
				q: "Minimum WCAG AA contrast for body text?",
				options: [
					"2:1",
					"3:1",
					"4.5:1",
					"7:1"
				],
				answer: 2,
				explain: "AA requires 4.5:1 for normal text."
			},
			{
				q: "Visual hierarchy is mainly created by…",
				options: [
					"Size, weight and contrast",
					"Only colour",
					"Animations",
					"Fonts count"
				],
				answer: 0,
				explain: "Size, weight and contrast guide attention."
			},
			{
				q: "An 8pt grid helps with…",
				options: [
					"Consistent spacing",
					"Colour choice",
					"Copywriting",
					"Accessibility only"
				],
				answer: 0,
				explain: "It keeps spacing consistent and predictable."
			},
			{
				q: "Gestalt 'proximity' means…",
				options: [
					"Close items feel related",
					"Similar colours",
					"Closed shapes",
					"Symmetry"
				],
				answer: 0,
				explain: "Items placed together are perceived as a group."
			}
		]
	},
	Communication: {
		skills: ["Communication"],
		questions: [
			{
				q: "STAR stands for…",
				options: [
					"Skill, Task, Action, Result",
					"Situation, Task, Action, Result",
					"Story, Talk, Answer, Review",
					"Situation, Team, Action, Reason"
				],
				answer: 1,
				explain: "Situation, Task, Action, Result."
			},
			{
				q: "Best way to start a project walkthrough?",
				options: [
					"Tech stack",
					"The problem and goal",
					"Your title",
					"Tools used"
				],
				answer: 1,
				explain: "Lead with the problem so listeners have context."
			},
			{
				q: "When you don't know an answer, you should…",
				options: [
					"Guess confidently",
					"Stay silent",
					"Say so and reason aloud",
					"Change the topic"
				],
				answer: 2,
				explain: "Honest reasoning shows how you think."
			},
			{
				q: "Good feedback is…",
				options: [
					"Vague",
					"Specific and actionable",
					"Only positive",
					"Delivered publicly"
				],
				answer: 1,
				explain: "Specific, actionable feedback helps people improve."
			}
		]
	},
	Physics: {
		skills: [
			"Physics",
			"Mechanics",
			"Problem Solving"
		],
		questions: [
			{
				q: "What is the SI unit of work and energy?",
				options: [
					"Newton",
					"Watt",
					"Joule",
					"Pascal"
				],
				answer: 2,
				explain: "The Joule (J) is the SI unit of work and energy (1 J = 1 N·m)."
			},
			{
				q: "Which law states that induced EMF opposes the change in magnetic flux?",
				options: [
					"Ohm's Law",
					"Lenz's Law",
					"Ampere's Law",
					"Coulomb's Law"
				],
				answer: 1,
				explain: "Lenz's law provides the direction of induced electromotive force."
			},
			{
				q: "When a projectile reaches its maximum height, its vertical velocity is…",
				options: [
					"Maximum",
					"Zero",
					"Equal to initial horizontal velocity",
					"Negative"
				],
				answer: 1,
				explain: "At the peak, vertical velocity momentarily equals zero before reversing."
			},
			{
				q: "Capacitance of a parallel plate capacitor increases when…",
				options: [
					"Plate area decreases",
					"Distance between plates increases",
					"A dielectric slab is inserted",
					"Voltage is removed"
				],
				answer: 2,
				explain: "Inserting a dielectric of constant K multiplies capacitance by K."
			}
		]
	},
	Chemistry: {
		skills: [
			"Chemistry",
			"Atomic Structure",
			"Chemical Bonding"
		],
		questions: [
			{
				q: "What is the hybridisation of carbon in methane (CH₄)?",
				options: [
					"sp",
					"sp²",
					"sp³",
					"sp³d"
				],
				answer: 2,
				explain: "Carbon forms four equivalent single sigma bonds in a tetrahedral sp³ geometry."
			},
			{
				q: "A solution with pH = 3 is how many times more acidic than pH = 5?",
				options: [
					"2 times",
					"10 times",
					"100 times",
					"1000 times"
				],
				answer: 2,
				explain: "The pH scale is logarithmic: ΔpH of 2 corresponds to a 10² = 100-fold increase."
			},
			{
				q: "Which quantum number specifies the orientation of an orbital in space?",
				options: [
					"Principal (n)",
					"Azimuthal (l)",
					"Magnetic (m)",
					"Spin (s)"
				],
				answer: 2,
				explain: "Magnetic quantum number m determines the spatial orientation."
			},
			{
				q: "Which element has the highest electronegativity on the Pauling scale?",
				options: [
					"Oxygen",
					"Chlorine",
					"Fluorine",
					"Nitrogen"
				],
				answer: 2,
				explain: "Fluorine has the highest electronegativity at 3.98."
			}
		]
	},
	Biology: {
		skills: [
			"Biology",
			"Cell Biology",
			"Genetics"
		],
		questions: [
			{
				q: "Which organelle is known as the powerhouse of eukaryotic cells?",
				options: [
					"Ribosome",
					"Mitochondria",
					"Golgi apparatus",
					"Lysosome"
				],
				answer: 1,
				explain: "Mitochondria generate the majority of cellular adenosine triphosphate (ATP)."
			},
			{
				q: "DNA replication is described as…",
				options: [
					"Conservative",
					"Semi-conservative",
					"Dispersive",
					"Random"
				],
				answer: 1,
				explain: "Meselson & Stahl demonstrated that each new double helix contains one old and one new strand."
			},
			{
				q: "In which phase of mitosis do sister chromatids separate toward opposite poles?",
				options: [
					"Prophase",
					"Metaphase",
					"Anaphase",
					"Telophase"
				],
				answer: 2,
				explain: "During anaphase, centromeres split and sister chromatids are pulled apart."
			},
			{
				q: "Which blood type is considered the universal red blood cell donor?",
				options: [
					"O Negative",
					"AB Positive",
					"A Positive",
					"O Positive"
				],
				answer: 0,
				explain: "O Negative lacks A, B, and Rh surface antigens, preventing immune rejection."
			}
		]
	},
	Mathematics: {
		skills: [
			"Mathematics",
			"Calculus",
			"Algebra"
		],
		questions: [
			{
				q: "What is the derivative of f(x) = ln(x) with respect to x?",
				options: [
					"eˣ",
					"1/x",
					"x",
					"1/x²"
				],
				answer: 1,
				explain: "d/dx [ln(x)] = 1/x for all x > 0."
			},
			{
				q: "The value of sin²(θ) + cos²(θ) is always…",
				options: [
					"0",
					"1",
					"tan(θ)",
					"2"
				],
				answer: 1,
				explain: "This is the fundamental Pythagorean trigonometric identity."
			},
			{
				q: "What is the limit of (sin x)/x as x approaches 0?",
				options: [
					"0",
					"1",
					"Infinity",
					"Undefined"
				],
				answer: 1,
				explain: "By L'Hôpital's rule or geometric definition, lim_{x→0} (sin x)/x = 1."
			},
			{
				q: "If two vectors are perpendicular, their dot product equals…",
				options: [
					"1",
					"-1",
					"0",
					"Their cross product"
				],
				answer: 2,
				explain: "u · v = |u||v|cos(90°) = 0."
			}
		]
	},
	"Financial Accounting": {
		skills: [
			"Financial Accounting",
			"Accounting",
			"Financial Records"
		],
		questions: [
			{
				q: "According to the fundamental accounting equation, Assets equal…",
				options: [
					"Liabilities - Equity",
					"Liabilities + Equity",
					"Revenue - Expenses",
					"Cash + Receivables"
				],
				answer: 1,
				explain: "Assets = Liabilities + Owner's Equity."
			},
			{
				q: "Which financial statement reports financial position at a specific point in time?",
				options: [
					"Income Statement",
					"Cash Flow Statement",
					"Balance Sheet",
					"Trial Balance"
				],
				answer: 2,
				explain: "The Balance Sheet is a snapshot of assets, liabilities, and equity on a specific date."
			},
			{
				q: "Under accrual accounting, revenue is recognized when…",
				options: [
					"Cash is deposited in the bank",
					"An order is received",
					"Performance obligation is satisfied / earned",
					"The tax year closes"
				],
				answer: 2,
				explain: "Revenue is recognized when goods/services are delivered, regardless of cash timing."
			}
		]
	},
	"Indian Polity": {
		skills: [
			"Indian Polity",
			"Constitutional Law",
			"Governance"
		],
		questions: [
			{
				q: "Which article of the Indian Constitution is called the 'Heart and Soul' by Dr. B.R. Ambedkar?",
				options: [
					"Article 14",
					"Article 19",
					"Article 21",
					"Article 32"
				],
				answer: 3,
				explain: "Article 32 guarantees the Right to Constitutional Remedies through Supreme Court writs."
			},
			{
				q: "The concept of 'Basic Structure' of the Constitution was established in…",
				options: [
					"Golaknath Case (1967)",
					"Kesavananda Bharati Case (1973)",
					"Minerva Mills Case (1980)",
					"Maneka Gandhi Case (1978)"
				],
				answer: 1,
				explain: "The 13-judge bench in Kesavananda Bharati ruled Parliament cannot alter the basic structure."
			},
			{
				q: "Who is the ex-officio Chairman of the Rajya Sabha?",
				options: [
					"President of India",
					"Prime Minister of India",
					"Vice-President of India",
					"Speaker of Lok Sabha"
				],
				answer: 2,
				explain: "The Vice-President of India serves as ex-officio Chairman of the Rajya Sabha."
			}
		]
	},
	"General Aptitude": {
		skills: [
			"Quantitative Aptitude",
			"Problem Solving",
			"Logic"
		],
		questions: [
			{
				q: "If a car travels 180 km in 3 hours, what is its speed in meters per second?",
				options: [
					"15 m/s",
					"16.67 m/s",
					"20 m/s",
					"25 m/s"
				],
				answer: 1,
				explain: "Speed = 180 km / 3 h = 60 km/h. Convert to m/s: 60 × (5/18) = 16.67 m/s."
			},
			{
				q: "A merchant buys an item for ₹800 and sells it for ₹1000. What is the profit percentage?",
				options: [
					"20%",
					"25%",
					"15%",
					"30%"
				],
				answer: 1,
				explain: "Profit = ₹200. Profit % = (200 / 800) × 100 = 25%."
			},
			{
				q: "What is the next number in the sequence: 2, 6, 12, 20, 30, …?",
				options: [
					"40",
					"42",
					"44",
					"46"
				],
				answer: 1,
				explain: "Differences are +4, +6, +8, +10, so next difference is +12: 30 + 12 = 42 (also n² + n)."
			}
		]
	}
};
var interviewBank = {
	"Frontend Developer": {
		Easy: [
			"Tell me about yourself and why frontend?",
			"What is the difference between let, const and var?",
			"How do you make a page responsive?"
		],
		Medium: [
			"Explain how React decides when to re-render.",
			"How would you improve a slow-loading page?",
			"Describe a bug you fixed and how you found it."
		],
		Hard: [
			"Design the state management for a large dashboard.",
			"How would you build an accessible custom dropdown?",
			"Tell me about a disagreement with a teammate and how you resolved it."
		]
	},
	"UI/UX Designer": {
		Easy: [
			"Walk me through your design process.",
			"What makes a good user interface?",
			"How do you take feedback on your work?"
		],
		Medium: [
			"How do you validate a design decision?",
			"Tell me about a usability test that changed your design.",
			"How do you balance user needs with business goals?"
		],
		Hard: [
			"How would you build a design system from scratch?",
			"Describe leading a project with conflicting stakeholders.",
			"How do you measure the success of a redesign?"
		]
	},
	"Data Analyst": {
		Easy: [
			"Why data analysis?",
			"What is the difference between mean and median?",
			"Which tools do you use daily?"
		],
		Medium: [
			"How do you handle missing data?",
			"Explain a dashboard you built and its impact.",
			"How would you explain a finding to a non-technical manager?"
		],
		Hard: [
			"Design metrics for a new product launch.",
			"How would you detect a drop in user engagement?",
			"Tell me about an analysis that was wrong and what you learned."
		]
	}
};
//#endregion
export { goalSkills as a, recommend as c, courses as i, testBank as l, ALL_EDUCATION_LEVELS as n, interviewBank as o, courseById as r, jobs as s, ALL_ACADEMIC_STREAMS as t };
