//#region node_modules/.nitro/vite/services/ssr/assets/blob-C9HcxTYw.js
var blob_default = "/assets/blob-Df5TiUuQ.png";
//#endregion
export { blob_default as t };
