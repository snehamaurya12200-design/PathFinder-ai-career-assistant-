import { a as TSS_SERVER_FUNCTION, l as createServerFn } from "./createServerFn-DDDJMFWM.mjs";
import { a as generateFallbackCareerDNA, n as FALLBACK_ADAPTIVE_QUESTIONS } from "./career-quest-data-z5Aook2y.mjs";
import { t as GoogleGenAI } from "../_libs/google__genai+p-retry+retry.mjs";
import { a as objectType, c as unionType, i as numberType, n as arrayType, o as recordType, r as enumType, s as stringType, t as anyType } from "../_libs/zod.mjs";
import processModule from "node:process";
//#region node_modules/.nitro/vite/services/ssr/assets/ai.functions-CCLAkPuA.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function getAI() {
	const apiKey = processModule.env.GEMINI_API_KEY;
	if (!apiKey) throw new Error("GEMINI_API_KEY is not configured.");
	return new GoogleGenAI({
		apiKey,
		httpOptions: { headers: { "User-Agent": "aistudio-build" } }
	});
}
/**
* Resilient multi-model execution helper.
* Tries the primary model first, and automatically falls back to secondary models
* if a 503 (high demand) or 429 (rate-limit) or 404 (unavailable) occurs.
*/
async function callGeminiWithFallback(ai, models, params) {
	let lastError = null;
	for (const model of models) try {
		const response = await ai.models.generateContent({
			model,
			contents: params.contents,
			config: params.config
		});
		if (response && (response.text !== void 0 || response.candidates?.length)) return {
			response,
			modelUsed: model
		};
	} catch (err) {
		console.warn(`Model ${model} encounter issue:`, err instanceof Error ? err.message : err);
		lastError = err;
	}
	throw lastError || /* @__PURE__ */ new Error("All Gemini models were unavailable.");
}
var TEXT_MODELS = [
	"gemini-3.8-flash",
	"gemini-3.5-flash-lite",
	"gemini-flash-lite-latest",
	"gemini-flash-latest"
];
var LegacyInput = objectType({
	system: stringType().max(4e3),
	messages: arrayType(objectType({
		role: enumType(["user", "assistant"]),
		content: stringType().max(6e3)
	})).max(40)
});
var askAI_createServerFn_handler = createServerRpc({
	id: "e6ce4f300af1ec33e34c8b840a63975ac94b41ab18b9a6fbe88567a0e0ab07f8",
	name: "askAI",
	filename: "src/lib/ai.functions.ts"
}, (opts) => askAI.__executeServer(opts));
var askAI = createServerFn({ method: "POST" }).validator((d) => LegacyInput.parse(d)).handler(askAI_createServerFn_handler, async ({ data }) => {
	try {
		const { response } = await callGeminiWithFallback(getAI(), TEXT_MODELS, { contents: [`System: ${data.system}`, ...data.messages.map((m) => `${m.role === "user" ? "User" : "Assistant"}: ${m.content}`)].join("\n\n") });
		const text = response.text?.trim() ?? "";
		if (!text) return {
			ok: false,
			error: "The assistant could not answer that request."
		};
		return {
			ok: true,
			text
		};
	} catch (err) {
		return {
			ok: false,
			error: err instanceof Error ? err.message : "AI request failed"
		};
	}
});
var CareerAgentInput = objectType({
	message: stringType(),
	history: arrayType(objectType({
		role: enumType(["user", "assistant"]),
		content: stringType()
	})).optional(),
	userState: objectType({
		name: stringType().optional(),
		email: stringType().optional(),
		education: stringType().optional(),
		educationLevel: stringType().optional(),
		stream: stringType().optional(),
		headline: stringType().optional(),
		goal: stringType().optional(),
		skills: recordType(stringType(), numberType()).optional(),
		enrolledCourses: arrayType(stringType()).optional(),
		lessonsDone: numberType().optional(),
		hours: numberType().optional(),
		cvName: stringType().optional(),
		recentTests: arrayType(anyType()).optional(),
		recentInterviews: arrayType(anyType()).optional()
	}).optional()
});
var askCareerAgent_createServerFn_handler = createServerRpc({
	id: "7e60424a563255576b8b72325f1f02b95839e31de0c6d4492cc2913b3e9c6b28",
	name: "askCareerAgent",
	filename: "src/lib/ai.functions.ts"
}, (opts) => askCareerAgent.__executeServer(opts));
var askCareerAgent = createServerFn({ method: "POST" }).validator((d) => CareerAgentInput.parse(d)).handler(askCareerAgent_createServerFn_handler, async ({ data }) => {
	try {
		const ai = getAI();
		const userName = data.userState?.name ?? "Sneha Maurya";
		const userEducation = data.userState?.education ?? "B.Tech Computer Science (2021-2025)";
		const userEducationLevel = data.userState?.educationLevel ?? "Undergraduate";
		const userStream = data.userState?.stream ?? "Computer Science & IT";
		const systemInstruction = `You are PATHFINDER's Lead Career Intelligence Advisor.
You converse with students, competitive exam aspirants, and job seekers (like ${userName}) across diverse academic disciplines (engineering, sciences, medicine, commerce, law, civil services, and school education) to help them clarify goals, audit skills, bridge learning gaps, build concrete week-by-week roadmaps, and excel in their fields.

USER PROFILE IN CONTEXT:
- Student Name: ${userName}
- Education Level: ${userEducationLevel}
- Academic Stream: ${userStream}
- Education Details: ${userEducation}
- Headline: ${data.userState?.headline ?? "Aspiring Frontend Developer & UI Enthusiast"}
- Target Goal: ${data.userState?.goal ?? "Frontend Developer"}
- Current Skills & Ratings: ${JSON.stringify(data.userState?.skills ?? {})}
- Currently Enrolled Courses: ${JSON.stringify(data.userState?.enrolledCourses ?? [])}
- Uploaded CV: ${data.userState?.cvName ?? "None yet"}
- Completed Lessons: ${data.userState?.lessonsDone ?? 46}
- Practice Tests Taken: ${JSON.stringify(data.userState?.recentTests ?? [])}
- Mock Interviews Taken: ${JSON.stringify(data.userState?.recentInterviews ?? [])}

MULTI-DISCIPLINARY INTELLIGENCE & ADAPTATION:
- Do NOT assume every student is in software engineering or UI design.
- Respect their declared Education Level (${userEducationLevel}) and Stream (${userStream}). For example:
  * If the student is in Class 10/11/12 (Science/Commerce/Arts), focus on board syllabus mastery, foundational concepts, competitive entrance strategy (JEE, NEET, CUET, CLAT), and study schedules.
  * If in Medical & Healthcare, provide rich academic guidance on anatomy, physiology, clinical biochemistry, and entrance prep. (Always clarify that online courses provide academic enrichment and do not substitute for formal clinical licensing).
  * If in Commerce & Finance, advise on accounting standards, DCF financial modeling, corporate governance, and CA/CFA pathways.
  * If in Law or Civil Services, advise on constitutional law, Indian polity, public administration, and GS answer writing.
  * If in Tech / Engineering, provide state-of-the-art software architecture, coding patterns, and system design.
- Provide concrete, detailed responses rather than generic placeholders.
- If asked for a learning roadmap, craft a week-by-week curriculum with realistic deliverables and include a "GENERATE_ROADMAP" action.
- When recommending courses, reference PATHFINDER's catalogue (NPTEL, SWAYAM, MIT OCW, Khan Academy, Coursera, Harvard Online, etc.).

STRUCTURED AGENT ACTIONS:
When appropriate, trigger real platform actions that update the user's dashboard and profile:
- "SET_GOAL": { "goal": string }
- "UPDATE_SKILLS": { "skills": { [skillName]: number 0-100 } }
- "ENROLL_COURSE": { "courseId": string, "title": string }
- "GENERATE_ROADMAP": { "goal": string, "summary": string, "weeks": [ { "week": number, "title": string, "topics": string[], "deliverable": string } ] }
- "RECOMMEND_JOBS": { "jobIds": number[], "rationale": string }
- "OPEN_MOCK_TEST": { "subject": string }
- "OPEN_MOCK_INTERVIEW": { "role": string, "difficulty": "Easy" | "Medium" | "Hard" }

IMPORTANT OUTPUT FORMAT:
Output MUST be strict JSON with this exact structure:
{
  "reply": "Your in-depth, professional, empathetic conversational response formatted with clear paragraphs and bullet points if needed.",
  "actions": [
    { "type": "...", "payload": { ... } }
  ],
  "suggestedChips": ["Short next step tag 1", "Short next step tag 2", "Short next step tag 3"]
}`;
		const contents = [];
		if (data.history && data.history.length > 0) for (const item of data.history) contents.push({
			role: item.role === "user" ? "user" : "model",
			parts: [{ text: item.content }]
		});
		contents.push({
			role: "user",
			parts: [{ text: data.message }]
		});
		const { response } = await callGeminiWithFallback(ai, TEXT_MODELS, {
			contents,
			config: {
				systemInstruction,
				responseMimeType: "application/json"
			}
		});
		const text = response.text?.trim() ?? "{}";
		const parsed = JSON.parse(text);
		if (!parsed.reply) throw new Error("Gemini returned an empty reply payload.");
		return {
			ok: true,
			reply: parsed.reply,
			actions: Array.isArray(parsed.actions) ? parsed.actions : [],
			suggestedChips: Array.isArray(parsed.suggestedChips) ? parsed.suggestedChips : [
				"Skill gaps",
				"Explore careers",
				"Mock interview"
			]
		};
	} catch (err) {
		console.error("askCareerAgent error:", err);
		return {
			ok: false,
			reply: "",
			actions: [],
			suggestedChips: [],
			error: err instanceof Error ? err.message : "Failed to connect with Gemini AI model."
		};
	}
});
var ResumeInput = objectType({
	fileName: stringType(),
	content: stringType(),
	targetGoal: stringType()
});
var analyzeResumeWithGemini_createServerFn_handler = createServerRpc({
	id: "d8df0d55df6c0abc614da7327152fbc6cf79e14660b6a8f13f17d30eb1105087",
	name: "analyzeResumeWithGemini",
	filename: "src/lib/ai.functions.ts"
}, (opts) => analyzeResumeWithGemini.__executeServer(opts));
var analyzeResumeWithGemini = createServerFn({ method: "POST" }).validator((d) => ResumeInput.parse(d)).handler(analyzeResumeWithGemini_createServerFn_handler, async ({ data }) => {
	try {
		const { response } = await callGeminiWithFallback(getAI(), TEXT_MODELS, {
			contents: `Analyze this resume/CV for candidate aspiring to be a "${data.targetGoal}".
File name: ${data.fileName}
Resume Content/Summary:
${data.content.slice(0, 1e4)}

Perform an intelligent skill gap analysis and return JSON:
{
  "candidateName": "Name or Sneha",
  "summary": "2-3 sentence overview of profile strengths and current standing",
  "matchScore": number (0-100),
  "extractedSkills": { "SkillName": number from 0-100 (e.g. JavaScript: 65, React: 55, Communication: 70) },
  "strengths": ["string", "string"],
  "gaps": ["string", "string"],
  "recommendations": ["string", "string"],
  "recommendedCourseId": "react-pro" | "web-foundations" | "typescript" | "dsa" | "communication" | "interview-prep"
}`,
			config: { responseMimeType: "application/json" }
		});
		return {
			ok: true,
			data: JSON.parse(response.text?.trim() ?? "{}")
		};
	} catch (err) {
		console.error("analyzeResume error:", err);
		return {
			ok: false,
			error: err instanceof Error ? err.message : "Resume analysis failed"
		};
	}
});
var InterviewInput = objectType({
	role: stringType(),
	difficulty: stringType(),
	question: stringType(),
	answer: stringType(),
	questionIndex: numberType().optional(),
	totalQuestions: numberType().optional()
});
var evaluateInterviewAnswerWithGemini_createServerFn_handler = createServerRpc({
	id: "b2b7569ca2546f51b50ed2bfd387f09682c66cec60c9f7c96653a733572f5284",
	name: "evaluateInterviewAnswerWithGemini",
	filename: "src/lib/ai.functions.ts"
}, (opts) => evaluateInterviewAnswerWithGemini.__executeServer(opts));
var evaluateInterviewAnswerWithGemini = createServerFn({ method: "POST" }).validator((d) => InterviewInput.parse(d)).handler(evaluateInterviewAnswerWithGemini_createServerFn_handler, async ({ data }) => {
	try {
		const { response } = await callGeminiWithFallback(getAI(), TEXT_MODELS, {
			contents: `You are a senior tech interviewer evaluating an answer for a "${data.role}" (${data.difficulty} difficulty) interview.
Question: "${data.question}"
Candidate Answer: "${data.answer}"

Evaluate on 5 core dimensions (0 to 100 each):
1. technical: Technical accuracy and domain depth
2. problemSolving: Approach, logic, edge-case consideration
3. communication: Conciseness, clarity, flow
4. relevance: Directly addressing the specific question
5. confidence: Conviction, professional tone

Compute an overall score (0-100).
Provide actionable feedback:
- What worked well
- What was missing
- Concrete improvement advice (mentioning STAR method if behavioral).

Return valid JSON:
{
  "score": number,
  "breakdown": {
    "technical": number,
    "problemSolving": number,
    "communication": number,
    "relevance": number,
    "confidence": number
  },
  "feedback": "2-3 constructive sentences covering content, communication and skills",
  "strength": "Key strength noticed",
  "improvement": "Key area to improve",
  "recommendation": "One specific actionable advice"
}`,
			config: { responseMimeType: "application/json" }
		});
		return {
			ok: true,
			data: JSON.parse(response.text?.trim() ?? "{}")
		};
	} catch (err) {
		console.error("evaluateInterview error:", err);
		return {
			ok: false,
			error: err instanceof Error ? err.message : "Evaluation failed"
		};
	}
});
var SpeechInput = objectType({
	text: stringType().max(2e3),
	voiceName: enumType([
		"Kore",
		"Puck",
		"Charon",
		"Fenrir",
		"Zephyr"
	]).optional()
});
var generateSpeechWithGemini_createServerFn_handler = createServerRpc({
	id: "8722e721790036e6e7cfbbc3765dca67b79ddebd93eb3167cc013af62e44763f",
	name: "generateSpeechWithGemini",
	filename: "src/lib/ai.functions.ts"
}, (opts) => generateSpeechWithGemini.__executeServer(opts));
var generateSpeechWithGemini = createServerFn({ method: "POST" }).validator((d) => SpeechInput.parse(d)).handler(generateSpeechWithGemini_createServerFn_handler, async ({ data }) => {
	try {
		const ai = getAI();
		const voice = data.voiceName ?? "Kore";
		const cleanText = data.text.replace(/[*_#`]/g, "").slice(0, 800);
		const base64Audio = (await ai.models.generateContent({
			model: "gemini-3.8-flash-lite-tts",
			contents: [{
				role: "user",
				parts: [{ text: cleanText }]
			}],
			config: {
				responseModalities: ["AUDIO"],
				speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: voice } } }
			}
		})).candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
		if (!base64Audio) return {
			ok: false,
			error: "No audio generated"
		};
		return {
			ok: true,
			audioBase64: base64Audio
		};
	} catch (err) {
		console.error("generateSpeech error:", err);
		return {
			ok: false,
			error: err instanceof Error ? err.message : "Speech generation failed"
		};
	}
});
var TranscribeInput = objectType({
	audioBase64: stringType(),
	mimeType: stringType().default("audio/webm")
});
var transcribeAudioWithGemini_createServerFn_handler = createServerRpc({
	id: "21e1b168e48fee00ded8bd5b752b49b1d7de7ee8e4f60ea24ef9d42f4a38a13a",
	name: "transcribeAudioWithGemini",
	filename: "src/lib/ai.functions.ts"
}, (opts) => transcribeAudioWithGemini.__executeServer(opts));
var transcribeAudioWithGemini = createServerFn({ method: "POST" }).validator((d) => TranscribeInput.parse(d)).handler(transcribeAudioWithGemini_createServerFn_handler, async ({ data }) => {
	try {
		return {
			ok: true,
			text: (await getAI().models.generateContent({
				model: "gemini-3.5-transcribe",
				contents: { parts: [{ inlineData: {
					mimeType: data.mimeType,
					data: data.audioBase64
				} }, { text: "Transcribe the spoken words accurately. Remove non-speech noise, keep the user's intended words including any self-corrections." }] }
			})).text?.trim() ?? ""
		};
	} catch (err) {
		console.error("transcribeAudio error:", err);
		return {
			ok: false,
			error: err instanceof Error ? err.message : "Audio transcription failed"
		};
	}
});
var AdaptiveInput = objectType({
	stage: stringType(),
	fieldOrSubject: stringType().optional(),
	interests: stringType().optional(),
	coreAnswers: recordType(unionType([stringType(), arrayType(stringType())]))
});
var generateAdaptiveQuestionsServerFn_createServerFn_handler = createServerRpc({
	id: "af1d061b0d5fd75ac3de46046d9ed46f397d9952ef23f60adbe0cc2539e37a3a",
	name: "generateAdaptiveQuestionsServerFn",
	filename: "src/lib/ai.functions.ts"
}, (opts) => generateAdaptiveQuestionsServerFn.__executeServer(opts));
var generateAdaptiveQuestionsServerFn = createServerFn({ method: "POST" }).validator((d) => AdaptiveInput.parse(d)).handler(generateAdaptiveQuestionsServerFn_createServerFn_handler, async ({ data }) => {
	try {
		const { response } = await callGeminiWithFallback(getAI(), TEXT_MODELS, {
			contents: `You are the lead psychometric and career intelligence engine for Pathfinder.
A user at stage "${data.stage}" (field: ${data.fieldOrSubject || "General"}, interests: ${data.interests || "None specified"}) has answered 15 core discovery questions across 5 dimensions:
1. The Thinker (creation vs analysis vs systems)
2. The Explorer (hands-on tech, design, science, business, writing)
3. The Decision Maker (intuition vs metrics, solo autonomy vs teamwork)
4. The Hidden Talent (unconventional superpowers)
5. The Future Self (ideal 5-year pride milestone)

Their answers:
${JSON.stringify(data.coreAnswers, null, 2)}

Analyze their patterns, conflicts, or intriguing intersections. Generate exactly 3 targeted follow-up multiple-choice questions to resolve ambiguities before synthesizing their Career DNA.
Respond ONLY with a JSON array conforming to:
[
  {
    "id": "followup_01",
    "question": "Clear, engaging question string (max 20 words)",
    "reason": "Why we are asking this (1 sentence explaining the trade-off or nuance)",
    "dimension": "e.g. tech_orientation | people_dynamic | learning_modality | risk_profile",
    "allowMultiple": false,
    "options": [
      { "id": "a", "text": "Option A text" },
      { "id": "b", "text": "Option B text" },
      { "id": "c", "text": "Option C text" },
      { "id": "d", "text": "Option D text" }
    ]
  }
]`,
			config: {
				responseMimeType: "application/json",
				temperature: .4
			}
		});
		const parsed = JSON.parse(response.text?.trim() ?? "[]");
		if (Array.isArray(parsed) && parsed.length >= 2) return {
			ok: true,
			questions: parsed
		};
		return {
			ok: true,
			questions: FALLBACK_ADAPTIVE_QUESTIONS
		};
	} catch (err) {
		console.warn("generateAdaptiveQuestions fallback activated:", err);
		return {
			ok: true,
			questions: FALLBACK_ADAPTIVE_QUESTIONS
		};
	}
});
var CareerDNASynthesisInput = objectType({
	context: objectType({
		stage: stringType(),
		fieldOrSubject: stringType().optional(),
		interests: stringType().optional(),
		region: stringType().optional()
	}),
	coreAnswers: recordType(unionType([stringType(), arrayType(stringType())])),
	adaptiveAnswers: recordType(stringType()).optional(),
	version: numberType().optional().default(1)
});
var generateCareerDNAServerFn_createServerFn_handler = createServerRpc({
	id: "5bd1b30cc7ecf721d44c1d8749203b62b5c0b8dd23c8415268b76adb7954aa1e",
	name: "generateCareerDNAServerFn",
	filename: "src/lib/ai.functions.ts"
}, (opts) => generateCareerDNAServerFn.__executeServer(opts));
var generateCareerDNAServerFn = createServerFn({ method: "POST" }).validator((d) => CareerDNASynthesisInput.parse(d)).handler(generateCareerDNAServerFn_createServerFn_handler, async ({ data }) => {
	try {
		const { response } = await callGeminiWithFallback(getAI(), TEXT_MODELS, {
			contents: `You are Pathfinder's Master Career Intelligence Synthesizer.
Synthesize a comprehensive, personalized "Career DNA Report" based on the user's discovery responses.

USER PROFILE:
- Stage: ${data.context.stage}
- Field / Subjects: ${data.context.fieldOrSubject || "Open"}
- Interests / Background: ${data.context.interests || "General"}
- Version: ${data.version}

15 CORE DISCOVERY RESPONSES:
${JSON.stringify(data.coreAnswers, null, 2)}

ADAPTIVE FOLLOW-UP RESPONSES:
${JSON.stringify(data.adaptiveAnswers || {}, null, 2)}

REQUIREMENTS:
1. "archetype": Give them an inspiring, precise archetype title (e.g. "The Visionary Systems Architect", "The Quantitative Strategist", "The Creative Product Alchemist", "The Human-Centered Innovator"), a compelling tagline, a 2-3 paragraph identity description celebrating their unique cognitive style, and 4 distinctive traits.
2. "dimensions": Scores from 20 to 98 across 8 dimensions: analytical, creative, technical, leadership, empathy, autonomy, adaptability, socialImpact.
3. "strengths": Array of 8 to 10 distinct strengths across categories ("cognitive", "execution", "creative", "interpersonal", "strategic"). Each strength MUST cite concrete evidence from their actual responses, have a 0-100 score, and include an actionable growth tip.
4. "careerMatches": Top 5 personalized career matches (matchScore descending from 96 to 80). For each match, provide:
   - "id": "match-1" etc.
   - "title": Job or profession title tailored to their stage and potential
   - "domain": Domain name
   - "matchScore": number 80-97
   - "summary": 1-2 sentence role summary
   - "whyMatched": Direct explanation linking to their specific answers
   - "dayInTheLife": Realistic breakdown of a typical day
   - "keySkills": 5 critical modern skills
   - "growthOutlook": Industry growth projections and salary/market demand
   - "starterProject": A concrete, exciting 1-week starter project they can build right now to test the waters
   - "recommendedCourseQuery": Search term for a relevant learning course
5. "unexpectedMatch": A non-obvious, surprising career path that bridges their unconventional strengths, with reason and exploration hook.
6. "actionableNextSteps": 3 structured milestones for Day 1-2, Day 3-4, and Day 5-7.
7. "whatWeStillDontKnow": 3 honest, refreshing admissions of remaining ambiguities that can only be discovered through real action.

Return pure JSON matching this exact structure:
{
  "archetype": {
    "title": "string",
    "tagline": "string",
    "description": "string",
    "traits": ["string", "string", "string", "string"]
  },
  "dimensions": {
    "analytical": number,
    "creative": number,
    "technical": number,
    "leadership": number,
    "empathy": number,
    "autonomy": number,
    "adaptability": number,
    "socialImpact": number
  },
  "strengths": [
    {
      "name": "string",
      "category": "cognitive" | "execution" | "creative" | "interpersonal" | "strategic",
      "score": number,
      "evidence": "string",
      "growthTip": "string"
    }
  ],
  "careerMatches": [
    {
      "id": "match-1",
      "title": "string",
      "domain": "string",
      "matchScore": number,
      "summary": "string",
      "whyMatched": "string",
      "dayInTheLife": "string",
      "keySkills": ["string"],
      "growthOutlook": "string",
      "starterProject": "string",
      "recommendedCourseQuery": "string"
    }
  ],
  "unexpectedMatch": {
    "title": "string",
    "domain": "string",
    "reason": "string",
    "explorationHook": "string"
  },
  "actionableNextSteps": [
    {
      "day": "string",
      "title": "string",
      "action": "string"
    }
  ],
  "whatWeStillDontKnow": ["string", "string", "string"]
}`,
			config: {
				responseMimeType: "application/json",
				temperature: .5
			}
		});
		const parsed = JSON.parse(response.text?.trim() ?? "{}");
		if (parsed.archetype && parsed.careerMatches?.length) return {
			ok: true,
			dna: {
				id: `dna-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
				version: data.version,
				completedAt: (/* @__PURE__ */ new Date()).toLocaleDateString("en-US", {
					month: "short",
					day: "numeric",
					year: "numeric"
				}),
				context: data.context,
				archetype: parsed.archetype,
				dimensions: parsed.dimensions ?? {
					analytical: 85,
					creative: 80,
					technical: 82,
					leadership: 70,
					empathy: 75,
					autonomy: 88,
					adaptability: 82,
					socialImpact: 76
				},
				strengths: parsed.strengths ?? [],
				careerMatches: parsed.careerMatches ?? [],
				unexpectedMatch: parsed.unexpectedMatch ?? {
					title: "Creative Technologist",
					domain: "Design & Technology",
					reason: "Synthesizes creative intuition with engineering precision.",
					explorationHook: "Explore interactive prototyping tools like Three.js and Figma."
				},
				actionableNextSteps: parsed.actionableNextSteps ?? [],
				whatWeStillDontKnow: parsed.whatWeStillDontKnow ?? [],
				answersSummary: {
					...data.coreAnswers,
					...data.adaptiveAnswers || {}
				}
			}
		};
		throw new Error("Invalid DNA schema returned by model");
	} catch (err) {
		console.warn("generateCareerDNA model fallback triggered:", err);
		return {
			ok: true,
			dna: generateFallbackCareerDNA(data.context, data.coreAnswers, data.adaptiveAnswers, data.version)
		};
	}
});
//#endregion
export { analyzeResumeWithGemini_createServerFn_handler, askAI_createServerFn_handler, askCareerAgent_createServerFn_handler, evaluateInterviewAnswerWithGemini_createServerFn_handler, generateAdaptiveQuestionsServerFn_createServerFn_handler, generateCareerDNAServerFn_createServerFn_handler, generateSpeechWithGemini_createServerFn_handler, transcribeAudioWithGemini_createServerFn_handler };
