import { _ as createFileRoute, g as lazyRouteComponent } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as objectType, i as numberType } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/jobs-CfZhqsJj.js
var $$splitComponentImporter = () => import("./jobs-B0_F7b0X.mjs");
var Route = createFileRoute("/jobs")({
	validateSearch: objectType({
		job: numberType().optional(),
		app: numberType().optional()
	}),
	head: () => ({ meta: [
		{ title: "Job Board — Pathfinder" },
		{
			name: "description",
			content: "Browse jobs matched to your skills with AI match scores."
		},
		{
			property: "og:title",
			content: "Job Board — Pathfinder"
		},
		{
			property: "og:description",
			content: "Find roles that fit your skills and roadmap."
		},
		{
			property: "og:type",
			content: "website"
		},
		{
			name: "twitter:card",
			content: "summary_large_image"
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
