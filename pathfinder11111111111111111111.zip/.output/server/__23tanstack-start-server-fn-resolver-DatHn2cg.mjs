//#region node_modules/.nitro/vite/services/ssr/assets/__23tanstack-start-server-fn-resolver-DatHn2cg.js
var manifest = {
	"21e1b168e48fee00ded8bd5b752b49b1d7de7ee8e4f60ea24ef9d42f4a38a13a": {
		functionName: "transcribeAudioWithGemini_createServerFn_handler",
		importer: () => import("./_ssr/ai.functions-CCLAkPuA.mjs")
	},
	"5bd1b30cc7ecf721d44c1d8749203b62b5c0b8dd23c8415268b76adb7954aa1e": {
		functionName: "generateCareerDNAServerFn_createServerFn_handler",
		importer: () => import("./_ssr/ai.functions-CCLAkPuA.mjs")
	},
	"7e60424a563255576b8b72325f1f02b95839e31de0c6d4492cc2913b3e9c6b28": {
		functionName: "askCareerAgent_createServerFn_handler",
		importer: () => import("./_ssr/ai.functions-CCLAkPuA.mjs")
	},
	"8722e721790036e6e7cfbbc3765dca67b79ddebd93eb3167cc013af62e44763f": {
		functionName: "generateSpeechWithGemini_createServerFn_handler",
		importer: () => import("./_ssr/ai.functions-CCLAkPuA.mjs")
	},
	"af1d061b0d5fd75ac3de46046d9ed46f397d9952ef23f60adbe0cc2539e37a3a": {
		functionName: "generateAdaptiveQuestionsServerFn_createServerFn_handler",
		importer: () => import("./_ssr/ai.functions-CCLAkPuA.mjs")
	},
	"b2b7569ca2546f51b50ed2bfd387f09682c66cec60c9f7c96653a733572f5284": {
		functionName: "evaluateInterviewAnswerWithGemini_createServerFn_handler",
		importer: () => import("./_ssr/ai.functions-CCLAkPuA.mjs")
	},
	"d8df0d55df6c0abc614da7327152fbc6cf79e14660b6a8f13f17d30eb1105087": {
		functionName: "analyzeResumeWithGemini_createServerFn_handler",
		importer: () => import("./_ssr/ai.functions-CCLAkPuA.mjs")
	},
	"e6ce4f300af1ec33e34c8b840a63975ac94b41ab18b9a6fbe88567a0e0ab07f8": {
		functionName: "askAI_createServerFn_handler",
		importer: () => import("./_ssr/ai.functions-CCLAkPuA.mjs")
	}
};
async function getServerFnById(id, access) {
	const serverFnInfo = manifest[id];
	if (!serverFnInfo) throw new Error("Server function info not found for " + id);
	const fnModule = serverFnInfo.module ??= await serverFnInfo.importer();
	if (!fnModule) throw new Error("Server function module not resolved for " + id);
	const action = fnModule[serverFnInfo.functionName];
	if (!action) throw new Error("Server function module export not resolved for serverFn ID: " + id);
	return action;
}
//#endregion
export { getServerFnById as t };
