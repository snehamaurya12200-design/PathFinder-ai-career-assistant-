globalThis.__nitro_main__ = import.meta.url;
import { i as defineLazyEventHandler, n as HTTPError, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
import { r as FastResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/apple-touch-icon.png": {
		"type": "image/png",
		"etag": "\"2273-EfBIFb8LY7FAWktMMVcT5FPbTzk\"",
		"mtime": "2026-11-01T14:48:39.559Z",
		"size": 8819,
		"path": "../public/apple-touch-icon.png"
	},
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"2289-kYhAl2xaCb5kmRl8Tb9NsqdBEiI\"",
		"mtime": "2026-11-01T14:48:39.559Z",
		"size": 8841,
		"path": "../public/favicon.ico"
	},
	"/favicon.png": {
		"type": "image/png",
		"etag": "\"2273-EfBIFb8LY7FAWktMMVcT5FPbTzk\"",
		"mtime": "2026-11-01T14:48:39.559Z",
		"size": 8819,
		"path": "../public/favicon.png"
	},
	"/favicon.svg": {
		"type": "image/svg+xml",
		"etag": "\"7c8-rObsJcikrP77DGnz1qo3c5Hlt1Y\"",
		"mtime": "2026-11-01T14:48:39.559Z",
		"size": 1992,
		"path": "../public/favicon.svg"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"a0-CKGXSIe7TSsqDTmGm/nY1t/o5d0\"",
		"mtime": "2026-11-01T14:48:39.559Z",
		"size": 160,
		"path": "../public/robots.txt"
	},
	"/assets/SectionShell-CUT-uN7u.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"396-Kv4jkAXwDec/bYzDwPwmVo1y3J4\"",
		"mtime": "2026-11-01T14:48:37.294Z",
		"size": 918,
		"path": "../public/assets/SectionShell-CUT-uN7u.js"
	},
	"/assets/AppShell-DIWeZJ9h.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3a8ac-+B+Xd9YkouexdX3VrigedheKc+g\"",
		"mtime": "2026-11-01T14:48:37.294Z",
		"size": 239788,
		"path": "../public/assets/AppShell-DIWeZJ9h.js"
	},
	"/assets/ai.functions-27vaNVOv.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"14a5-lPIicXqx02thlQghPkGeGDKEdyE\"",
		"mtime": "2026-11-01T14:48:37.294Z",
		"size": 5285,
		"path": "../public/assets/ai.functions-27vaNVOv.js"
	},
	"/assets/button-wimhSJJe.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"7fb-mVrPUyTNrT7Qf62Bcfv3ynrjNyQ\"",
		"mtime": "2026-11-01T14:48:37.294Z",
		"size": 2043,
		"path": "../public/assets/button-wimhSJJe.js"
	},
	"/assets/calendar-days-Dh2NhuJE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1e6-+bCCpCTDGM2ekF0vkHJhbwhzqg0\"",
		"mtime": "2026-11-01T14:48:37.294Z",
		"size": 486,
		"path": "../public/assets/calendar-days-Dh2NhuJE.js"
	},
	"/assets/clock-BxD6jm1g.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"183-Y3TIl0PEIyLckgXTkYhwQfuKqis\"",
		"mtime": "2026-11-01T14:48:37.294Z",
		"size": 387,
		"path": "../public/assets/clock-BxD6jm1g.js"
	},
	"/assets/createClientRpc-Co71ZMSV.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8720-y58hdjJOgKG5MVlb0ZhVVyhL2bE\"",
		"mtime": "2026-11-01T14:48:37.294Z",
		"size": 34592,
		"path": "../public/assets/createClientRpc-Co71ZMSV.js"
	},
	"/assets/dialogs-Ny8FFvbi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a3f9-RUNJTvHdVS8w8esuri9bpaPWRv4\"",
		"mtime": "2026-11-01T14:48:37.294Z",
		"size": 41977,
		"path": "../public/assets/dialogs-Ny8FFvbi.js"
	},
	"/assets/index-DfBlStyi.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"74a5e-2a90mxW7yImGE734JYwu6cyFMu0\"",
		"mtime": "2026-11-01T14:48:37.294Z",
		"size": 477790,
		"path": "../public/assets/index-DfBlStyi.js"
	},
	"/assets/interviews-Ddgc9SMc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2d2a-1ob2S2L7Q38tcM3ZxI1NcfxEApo\"",
		"mtime": "2026-11-01T14:48:37.294Z",
		"size": 11562,
		"path": "../public/assets/interviews-Ddgc9SMc.js"
	},
	"/assets/jsx-dev-runtime-zBR51VjP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"14e3e-FZ5YYVl4hc1BFzii+XsfwdwoJsQ\"",
		"mtime": "2026-11-01T14:48:37.294Z",
		"size": 85566,
		"path": "../public/assets/jsx-dev-runtime-zBR51VjP.js"
	},
	"/assets/jobs-B7mbg7Km.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2511-u17oozNKwW7JmSoxR1mBuiPRYGo\"",
		"mtime": "2026-11-01T14:48:37.294Z",
		"size": 9489,
		"path": "../public/assets/jobs-B7mbg7Km.js"
	},
	"/assets/blob-Df5TiUuQ.png": {
		"type": "image/png",
		"etag": "\"73992-Y06wPVLVERVw/XJtzWLl6edmPVE\"",
		"mtime": "2026-11-01T14:48:37.296Z",
		"size": 473490,
		"path": "../public/assets/blob-Df5TiUuQ.png"
	},
	"/assets/loader-circle-B68bWvT8.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"88-TapyHCJHJlryjARhnW43Uv2vhDk\"",
		"mtime": "2026-11-01T14:48:37.295Z",
		"size": 136,
		"path": "../public/assets/loader-circle-B68bWvT8.js"
	},
	"/assets/lock-DPzrdnwl.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c6-QOmSHOmK+TFcjrk6vHtF2lPXbjA\"",
		"mtime": "2026-11-01T14:48:37.295Z",
		"size": 198,
		"path": "../public/assets/lock-DPzrdnwl.js"
	},
	"/assets/SkillRadar-Bf6tV6KO.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"87a-2+1cMCU6trOKXst1cV/GJu6GMdg\"",
		"mtime": "2026-11-01T14:48:37.294Z",
		"size": 2170,
		"path": "../public/assets/SkillRadar-Bf6tV6KO.js"
	},
	"/assets/learning-Cy86S9oE.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"8a3b-89HpEtsTF91RFBcjlDg2XwfH+rs\"",
		"mtime": "2026-11-01T14:48:37.294Z",
		"size": 35387,
		"path": "../public/assets/learning-Cy86S9oE.js"
	},
	"/assets/gem-Duh8pW0V.png": {
		"type": "image/png",
		"etag": "\"819d2-P1P8AhptvZtOxy8i6BZyRFbE06M\"",
		"mtime": "2026-11-01T14:48:37.296Z",
		"size": 530898,
		"path": "../public/assets/gem-Duh8pW0V.png"
	},
	"/assets/blob-BTfvu_Jc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"31-jl2IqUU5YTz0uY97nFBYEwUbMVs\"",
		"mtime": "2026-11-01T14:48:37.294Z",
		"size": 49,
		"path": "../public/assets/blob-BTfvu_Jc.js"
	},
	"/assets/assistant-O7ygMNe3.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4229-tCKQwVErGrFnmeN6IDNLx9NBm6g\"",
		"mtime": "2026-11-01T14:48:37.294Z",
		"size": 16937,
		"path": "../public/assets/assistant-O7ygMNe3.js"
	},
	"/assets/mic-Dln2m9Mk.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"e3-Ni96AovZdeHzxQJnreB1WemAi60\"",
		"mtime": "2026-11-01T14:48:37.295Z",
		"size": 227,
		"path": "../public/assets/mic-Dln2m9Mk.js"
	},
	"/assets/networking-BrhmR23b.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"29f8-pi+e99e5ceznep9PldpIuw6sw5Y\"",
		"mtime": "2026-11-01T14:48:37.295Z",
		"size": 10744,
		"path": "../public/assets/networking-BrhmR23b.js"
	},
	"/assets/pathfinder-data-DpkZQNlP.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1cb45-iUU2FzmdWrTCWDTNUPkWKNNvpEg\"",
		"mtime": "2026-11-01T14:48:37.295Z",
		"size": 117573,
		"path": "../public/assets/pathfinder-data-DpkZQNlP.js"
	},
	"/assets/play-BvBa2Ors.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b6-wj1jZUr6qX39wuzJ/Ow4CH1s2Tw\"",
		"mtime": "2026-11-01T14:48:37.295Z",
		"size": 182,
		"path": "../public/assets/play-BvBa2Ors.js"
	},
	"/assets/quest-ExIKuTuv.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1f16d-/pgvt6LFP4BuHdfXxM3Swtv/dTQ\"",
		"mtime": "2026-11-01T14:48:37.295Z",
		"size": 127341,
		"path": "../public/assets/quest-ExIKuTuv.js"
	},
	"/assets/roadmap-CDEt1X7f.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"4b8a-IM0J8/mdaHQrMghYydmw+xl+Wh0\"",
		"mtime": "2026-11-01T14:48:37.295Z",
		"size": 19338,
		"path": "../public/assets/roadmap-CDEt1X7f.js"
	},
	"/assets/rolldown-runtime-CbXtAM7H.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"24d-+aXgvbJ1Wwcp2A8AXKIBByksYC8\"",
		"mtime": "2026-11-01T14:48:37.295Z",
		"size": 589,
		"path": "../public/assets/rolldown-runtime-CbXtAM7H.js"
	},
	"/assets/rotate-ccw-DMIzMiqs.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c0-lV+eCOEpwuFYjQZaKJvyrvZkzTU\"",
		"mtime": "2026-11-01T14:48:37.295Z",
		"size": 192,
		"path": "../public/assets/rotate-ccw-DMIzMiqs.js"
	},
	"/assets/routes-oVhQEhGd.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5ca6-vpw4xWLycT1MyinCIuwXgFYUNsU\"",
		"mtime": "2026-11-01T14:48:37.295Z",
		"size": 23718,
		"path": "../public/assets/routes-oVhQEhGd.js"
	},
	"/assets/shapes-CG5F2UXs.png": {
		"type": "image/png",
		"etag": "\"7a48c-Deu87mZIWSXK2dkJi1eFHRidxKM\"",
		"mtime": "2026-11-01T14:48:37.296Z",
		"size": 500876,
		"path": "../public/assets/shapes-CG5F2UXs.png"
	},
	"/assets/skills-DCyjiYI3.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1a39-lrqZlZHWDnIvSCjDrGHiw9nfKUw\"",
		"mtime": "2026-11-01T14:48:37.295Z",
		"size": 6713,
		"path": "../public/assets/skills-DCyjiYI3.js"
	},
	"/assets/target-CnDJwezK.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"da-FVGGMXLKKB/pbdRMkNNUfNhqwWg\"",
		"mtime": "2026-11-01T14:48:37.295Z",
		"size": 218,
		"path": "../public/assets/target-CnDJwezK.js"
	},
	"/assets/tile-FnTGXmeG.png": {
		"type": "image/png",
		"etag": "\"7f909-eTQY4k5EKTCyrEpGMpy0PiIYLmo\"",
		"mtime": "2026-11-01T14:48:37.297Z",
		"size": 522505,
		"path": "../public/assets/tile-FnTGXmeG.png"
	},
	"/assets/types-BPnhPyKR.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f2eb-X1U4suP/bJZXohvizoQ0QmyWhpw\"",
		"mtime": "2026-11-01T14:48:37.295Z",
		"size": 62187,
		"path": "../public/assets/types-BPnhPyKR.js"
	},
	"/assets/aistudio/1234_53df4301.png": {
		"type": "image/png",
		"etag": "\"48353-VXjH8SPrVuKYykeL1N1pSXYKuIs\"",
		"mtime": "2026-11-01T14:48:39.558Z",
		"size": 295763,
		"path": "../public/assets/aistudio/1234_53df4301.png"
	},
	"/assets/aistudio/123_5d1cb111.png": {
		"type": "image/png",
		"etag": "\"76b81-lHTuP6UE3e1g5mefc2t8/14+QkI\"",
		"mtime": "2026-11-01T14:48:39.559Z",
		"size": 486273,
		"path": "../public/assets/aistudio/123_5d1cb111.png"
	},
	"/assets/styles-Cr20x5Eo.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"1d167-KyoxdaEypSBmXSTgiYVtXRiQHTs\"",
		"mtime": "2026-11-01T14:48:37.296Z",
		"size": 119143,
		"path": "../public/assets/styles-Cr20x5Eo.css"
	},
	"/assets/aistudio/lovable-project-8986ea04-752f-406b-86ad-f779e4b7a1fe-2026-10-31_89fb3343.zip": {
		"type": "application/zip",
		"etag": "\"21e85b-TPQGQwZqC1j5u3oErlmi6rM0we8\"",
		"mtime": "2026-11-01T14:48:39.560Z",
		"size": 2222171,
		"path": "../public/assets/aistudio/lovable-project-8986ea04-752f-406b-86ad-f779e4b7a1fe-2026-10-31_89fb3343.zip"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_6qWkqV = defineLazyEventHandler(() => import("./_chunks/renderer-template.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_6qWkqV
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
