//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CGYvgBkn.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/app/applet/src/routes/__root.tsx",
		children: [
			"/",
			"/assistant",
			"/interviews",
			"/jobs",
			"/learning",
			"/networking",
			"/quest",
			"/roadmap",
			"/skills"
		],
		preloads: [
			"/assets/index-DfBlStyi.js",
			"/assets/rolldown-runtime-CbXtAM7H.js",
			"/assets/jsx-dev-runtime-zBR51VjP.js",
			"/assets/createClientRpc-Co71ZMSV.js",
			"/assets/types-BPnhPyKR.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DfBlStyi.js"
		} }]
	},
	"/": {
		filePath: "/app/applet/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-oVhQEhGd.js",
			"/assets/ai.functions-27vaNVOv.js",
			"/assets/AppShell-DIWeZJ9h.js",
			"/assets/dialogs-Ny8FFvbi.js",
			"/assets/loader-circle-B68bWvT8.js",
			"/assets/play-BvBa2Ors.js",
			"/assets/blob-BTfvu_Jc.js",
			"/assets/pathfinder-data-DpkZQNlP.js"
		]
	},
	"/assistant": {
		filePath: "/app/applet/src/routes/assistant.tsx",
		children: void 0,
		preloads: [
			"/assets/assistant-O7ygMNe3.js",
			"/assets/ai.functions-27vaNVOv.js",
			"/assets/AppShell-DIWeZJ9h.js",
			"/assets/loader-circle-B68bWvT8.js",
			"/assets/mic-Dln2m9Mk.js",
			"/assets/rotate-ccw-DMIzMiqs.js",
			"/assets/blob-BTfvu_Jc.js"
		]
	},
	"/interviews": {
		filePath: "/app/applet/src/routes/interviews.tsx",
		children: void 0,
		preloads: [
			"/assets/interviews-Ddgc9SMc.js",
			"/assets/AppShell-DIWeZJ9h.js",
			"/assets/dialogs-Ny8FFvbi.js",
			"/assets/play-BvBa2Ors.js",
			"/assets/target-CnDJwezK.js",
			"/assets/button-wimhSJJe.js",
			"/assets/SectionShell-CUT-uN7u.js"
		]
	},
	"/jobs": {
		filePath: "/app/applet/src/routes/jobs.tsx",
		children: void 0,
		preloads: [
			"/assets/jobs-B7mbg7Km.js",
			"/assets/AppShell-DIWeZJ9h.js",
			"/assets/clock-BxD6jm1g.js",
			"/assets/dialogs-Ny8FFvbi.js",
			"/assets/pathfinder-data-DpkZQNlP.js",
			"/assets/button-wimhSJJe.js"
		]
	},
	"/learning": {
		filePath: "/app/applet/src/routes/learning.tsx",
		children: void 0,
		preloads: [
			"/assets/learning-Cy86S9oE.js",
			"/assets/AppShell-DIWeZJ9h.js",
			"/assets/clock-BxD6jm1g.js",
			"/assets/dialogs-Ny8FFvbi.js",
			"/assets/calendar-days-Dh2NhuJE.js",
			"/assets/lock-DPzrdnwl.js",
			"/assets/mic-Dln2m9Mk.js",
			"/assets/play-BvBa2Ors.js",
			"/assets/target-CnDJwezK.js",
			"/assets/pathfinder-data-DpkZQNlP.js",
			"/assets/button-wimhSJJe.js",
			"/assets/SectionShell-CUT-uN7u.js",
			"/assets/SkillRadar-Bf6tV6KO.js"
		]
	},
	"/networking": {
		filePath: "/app/applet/src/routes/networking.tsx",
		children: void 0,
		preloads: [
			"/assets/networking-BrhmR23b.js",
			"/assets/AppShell-DIWeZJ9h.js",
			"/assets/calendar-days-Dh2NhuJE.js",
			"/assets/button-wimhSJJe.js"
		]
	},
	"/quest": {
		filePath: "/app/applet/src/routes/quest.tsx",
		children: void 0,
		preloads: [
			"/assets/quest-ExIKuTuv.js",
			"/assets/ai.functions-27vaNVOv.js",
			"/assets/AppShell-DIWeZJ9h.js",
			"/assets/clock-BxD6jm1g.js",
			"/assets/loader-circle-B68bWvT8.js",
			"/assets/rotate-ccw-DMIzMiqs.js",
			"/assets/target-CnDJwezK.js"
		]
	},
	"/roadmap": {
		filePath: "/app/applet/src/routes/roadmap.tsx",
		children: void 0,
		preloads: [
			"/assets/roadmap-CDEt1X7f.js",
			"/assets/AppShell-DIWeZJ9h.js",
			"/assets/clock-BxD6jm1g.js",
			"/assets/lock-DPzrdnwl.js",
			"/assets/play-BvBa2Ors.js",
			"/assets/pathfinder-data-DpkZQNlP.js",
			"/assets/button-wimhSJJe.js",
			"/assets/SectionShell-CUT-uN7u.js"
		]
	},
	"/skills": {
		filePath: "/app/applet/src/routes/skills.tsx",
		children: void 0,
		preloads: [
			"/assets/skills-DCyjiYI3.js",
			"/assets/AppShell-DIWeZJ9h.js",
			"/assets/pathfinder-data-DpkZQNlP.js",
			"/assets/SectionShell-CUT-uN7u.js",
			"/assets/SkillRadar-Bf6tV6KO.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
