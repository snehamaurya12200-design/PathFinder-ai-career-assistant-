import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as require_jsx_dev_runtime } from "../_libs/react.mjs";
import { A as RotateCcw, E as SendHorizontal, R as Mic, St as Check, W as LoaderCircle, i as Volume2, it as FileText, r as VolumeX, u as UserPen, y as Sparkles } from "../_libs/lucide-react.mjs";
import { f as usePathfinder, l as actions, n as AppShell } from "./AppShell-CmHrRTAn.mjs";
import { n as askCareerAgent, o as generateSpeechWithGemini, s as transcribeAudioWithGemini } from "./ai.functions-u7pgug8o.mjs";
import { t as blob_default } from "./blob-C9HcxTYw.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/assistant-DZ-EQyPB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_dev_runtime = require_jsx_dev_runtime();
var _jsxFileName = "/app/applet/src/routes/assistant.tsx?tsr-split=component";
var defaultChips = [
	"Explore careers",
	"Skill gaps",
	"Mock interview",
	"Build roadmap",
	"Resume tips",
	"Internships"
];
function Assistant() {
	const store = usePathfinder((s) => s);
	const msgs = store.chat;
	const [text, setText] = (0, import_react.useState)("");
	const [listening, setListening] = (0, import_react.useState)(false);
	const [processing, setProcessing] = (0, import_react.useState)(false);
	const [speaking, setSpeaking] = (0, import_react.useState)(false);
	const [speakingIdx, setSpeakingIdx] = (0, import_react.useState)(null);
	const [autoSpeak, setAutoSpeak] = (0, import_react.useState)(() => {
		if (typeof window !== "undefined") {
			const fromStore = store.settings?.aiPreferences?.autoSpeak;
			if (typeof fromStore === "boolean") return fromStore;
			return localStorage.getItem("pathfinder_auto_speak") === "true";
		}
		return false;
	});
	(0, import_react.useEffect)(() => {
		if (typeof store.settings?.aiPreferences?.autoSpeak === "boolean") setAutoSpeak(store.settings.aiPreferences.autoSpeak);
	}, [store.settings?.aiPreferences?.autoSpeak]);
	const [activeChips, setActiveChips] = (0, import_react.useState)(defaultChips);
	const [lastActionNotice, setLastActionNotice] = (0, import_react.useState)(null);
	const recognitionRef = (0, import_react.useRef)(null);
	const mediaRecorderRef = (0, import_react.useRef)(null);
	const audioChunksRef = (0, import_react.useRef)([]);
	const currentAudioRef = (0, import_react.useRef)(null);
	const messagesEndRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
	}, [msgs, processing]);
	(0, import_react.useEffect)(() => {
		return () => {
			stopAudio();
			stopListening();
		};
	}, []);
	function toggleAutoSpeak() {
		stopAudio();
		const next = !autoSpeak;
		setAutoSpeak(next);
		if (typeof window !== "undefined") localStorage.setItem("pathfinder_auto_speak", String(next));
		actions.updateSettings({ aiPreferences: {
			...store.settings.aiPreferences,
			autoSpeak: next
		} });
		toast(next ? "Voice response mode enabled" : "Text-only mode (Voice playback off)");
	}
	function stopAudio() {
		if (currentAudioRef.current) {
			currentAudioRef.current.pause();
			currentAudioRef.current.currentTime = 0;
			currentAudioRef.current = null;
		}
		if (typeof window !== "undefined" && window.speechSynthesis) window.speechSynthesis.cancel();
		setSpeaking(false);
		setSpeakingIdx(null);
	}
	function stopListening() {
		if (recognitionRef.current) {
			try {
				recognitionRef.current.stop();
			} catch {}
			recognitionRef.current = null;
		}
		if (mediaRecorderRef.current && mediaRecorderRef.current.state === "recording") {
			try {
				mediaRecorderRef.current.stop();
			} catch {}
			mediaRecorderRef.current = null;
		}
		setListening(false);
	}
	async function speakText(rawText, messageIdx) {
		stopAudio();
		setSpeaking(true);
		if (messageIdx !== void 0) setSpeakingIdx(messageIdx);
		const clean = rawText.replace(/[*_#`]/g, "").replace(/https?:\/\/\S+/g, "").trim();
		try {
			const res = await generateSpeechWithGemini({ data: {
				text: clean.slice(0, 700),
				voiceName: "Kore"
			} });
			if (res.ok && res.audioBase64) {
				const audio = new Audio(`data:audio/wav;base64,${res.audioBase64}`);
				currentAudioRef.current = audio;
				audio.onended = () => {
					setSpeaking(false);
					setSpeakingIdx(null);
					currentAudioRef.current = null;
				};
				audio.onerror = () => {
					fallbackSpeechSynthesis(clean);
				};
				await audio.play();
				return;
			}
		} catch {}
		fallbackSpeechSynthesis(clean);
	}
	function fallbackSpeechSynthesis(clean) {
		if (typeof window !== "undefined" && "speechSynthesis" in window) {
			const utterance = new SpeechSynthesisUtterance(clean);
			utterance.rate = 1;
			utterance.onend = () => {
				setSpeaking(false);
				setSpeakingIdx(null);
			};
			utterance.onerror = () => {
				setSpeaking(false);
				setSpeakingIdx(null);
			};
			window.speechSynthesis.speak(utterance);
		} else {
			setSpeaking(false);
			setSpeakingIdx(null);
		}
	}
	function executeAgentActions(actionList) {
		actionList.forEach((act) => {
			switch (act.type) {
				case "SET_GOAL":
					actions.setGoal(act.payload.goal);
					toast.success(`Career goal updated to ${act.payload.goal}`, { description: "Dashboard, roadmaps, and skills refreshed." });
					setLastActionNotice(`Updated target goal: ${act.payload.goal}`);
					break;
				case "UPDATE_SKILLS":
					actions.updateSkillMap(act.payload.skills);
					toast.success("Skill progress updated", { description: Object.entries(act.payload.skills).map(([k, v]) => `${k}: ${v}%`).join(", ") });
					setLastActionNotice("Skills updated in your profile radar");
					break;
				case "ENROLL_COURSE":
					actions.enroll(act.payload.courseId);
					toast.success(`Enrolled in ${act.payload.title}`, { description: "View lessons in Dashboard and Learning sections." });
					setLastActionNotice(`Enrolled: ${act.payload.title}`);
					break;
				case "RECOMMEND_JOBS":
					toast.info("Matched jobs available", { description: act.payload.rationale });
					setLastActionNotice("Matched opportunities updated in Job Board");
					break;
				case "GENERATE_ROADMAP":
					actions.setCustomRoadmap({
						goal: act.payload.goal,
						summary: act.payload.summary,
						weeks: act.payload.weeks,
						generatedAt: (/* @__PURE__ */ new Date()).toISOString()
					});
					toast.success(`Personalized roadmap generated for ${act.payload.goal}`, { description: "Saved and accessible in Explore Careers & Learning." });
					setLastActionNotice(`Roadmap ready for ${act.payload.goal}`);
					break;
				case "OPEN_MOCK_TEST":
					toast.info(`Mock test recommended: ${act.payload.subject}`);
					break;
				case "OPEN_MOCK_INTERVIEW": toast.info(`Mock interview prepared: ${act.payload.role} (${act.payload.difficulty})`);
			}
		});
	}
	async function send(userQuery) {
		const q = userQuery.trim();
		if (!q || processing) return;
		stopAudio();
		stopListening();
		setText("");
		setLastActionNotice(null);
		const userMsg = {
			me: true,
			t: q
		};
		actions.addChatMessage(userMsg);
		setProcessing(true);
		try {
			const historyPayload = msgs.filter((m) => !m.error).slice(-10).map((m) => ({
				role: m.me ? "user" : "assistant",
				content: m.t
			}));
			const res = await askCareerAgent({ data: {
				message: q,
				history: historyPayload,
				userState: {
					name: store.profile?.name,
					email: store.profile?.email,
					education: store.profile?.education,
					educationLevel: store.profile?.educationLevel,
					stream: store.profile?.stream,
					headline: store.profile?.headline,
					goal: store.goal,
					skills: store.skills,
					enrolledCourses: Object.keys(store.enrolled),
					lessonsDone: store.lessonsDone,
					hours: store.hours,
					cvName: store.cvName,
					recentTests: store.tests.slice(0, 3),
					recentInterviews: store.interviews.slice(0, 3)
				}
			} });
			if (res.ok && res.reply) {
				const assistantMsg = {
					me: false,
					t: res.reply
				};
				actions.addChatMessage(assistantMsg);
				if (res.actions?.length) executeAgentActions(res.actions);
				if (res.suggestedChips?.length) setActiveChips(res.suggestedChips);
				if (autoSpeak) speakText(res.reply);
			} else {
				const errDesc = res.error || "The AI career advisor could not process this request.";
				actions.addChatMessage({
					me: false,
					t: `I was unable to complete your request: ${errDesc}`,
					error: true,
					retryText: q
				});
				toast.error("Career Assistant request failed", { description: errDesc });
			}
		} catch (err) {
			console.error("Assistant send error:", err);
			const msg = err instanceof Error ? err.message : "Connection failed";
			actions.addChatMessage({
				me: false,
				t: `Connection to Gemini failed: ${msg}. Please tap Retry.`,
				error: true,
				retryText: q
			});
			toast.error("AI service error", { description: msg });
		} finally {
			setProcessing(false);
		}
	}
	function startVoiceInput() {
		stopAudio();
		const WindowWithSpeech = window;
		const SpeechClass = WindowWithSpeech.SpeechRecognition ?? WindowWithSpeech.webkitSpeechRecognition;
		if (SpeechClass) try {
			const recognizer = new SpeechClass();
			recognizer.lang = "en-US";
			recognizer.interimResults = true;
			recognizer.continuous = false;
			recognizer.onresult = (event) => {
				const results = event.results;
				let transcript = "";
				for (let i = 0; i < Object.keys(results).length; i++) transcript += results[i]?.[0]?.transcript ?? "";
				if (transcript.trim()) setText(transcript);
			};
			recognizer.onend = () => {
				setListening(false);
				recognitionRef.current = null;
			};
			recognizer.onerror = () => {
				setListening(false);
				recognitionRef.current = null;
			};
			recognitionRef.current = recognizer;
			setListening(true);
			recognizer.start();
			return;
		} catch (e) {
			console.warn("SpeechRecognition fallback to MediaRecorder", e);
		}
		if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) navigator.mediaDevices.getUserMedia({ audio: true }).then((stream) => {
			audioChunksRef.current = [];
			const recorder = new MediaRecorder(stream);
			recorder.ondataavailable = (e) => {
				if (e.data.size > 0) audioChunksRef.current.push(e.data);
			};
			recorder.onstop = async () => {
				const blobData = new Blob(audioChunksRef.current, { type: "audio/webm" });
				stream.getTracks().forEach((track) => track.stop());
				setListening(false);
				mediaRecorderRef.current = null;
				try {
					const reader = new FileReader();
					reader.readAsDataURL(blobData);
					reader.onloadend = async () => {
						const base64 = reader.result.split(",")[1];
						if (base64) {
							setProcessing(true);
							const res = await transcribeAudioWithGemini({ data: {
								audioBase64: base64,
								mimeType: "audio/webm"
							} });
							setProcessing(false);
							if (res.ok && res.text) setText(res.text);
						}
					};
				} catch {
					setProcessing(false);
				}
			};
			mediaRecorderRef.current = recorder;
			setListening(true);
			recorder.start();
		}).catch(() => {
			toast.error("Microphone access denied. Please type your message.");
			setListening(false);
		});
		else toast.error("Voice input is not supported in this browser. Please type your message.");
	}
	function toggleVoice() {
		if (speaking) {
			stopAudio();
			return;
		}
		if (listening) {
			stopListening();
			return;
		}
		startVoiceInput();
	}
	function handlePlayMessage(idx, messageText) {
		if (speaking && speakingIdx === idx) stopAudio();
		else speakText(messageText, idx);
	}
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
		className: "relative mx-auto max-w-2xl overflow-hidden rounded-3xl border bg-card p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("img", {
				src: blob_default,
				alt: "",
				width: 816,
				height: 816,
				className: "pointer-events-none absolute -right-10 -top-10 w-40 opacity-80"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 421,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "flex items-start justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h1", {
					className: "text-3xl font-bold leading-tight",
					children: [
						"Hello",
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("br", {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 425,
							columnNumber: 13
						}, this),
						"Sneha"
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 423,
					columnNumber: 11
				}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
						onClick: () => {
							stopAudio();
							actions.clearChat();
							setActiveChips(defaultChips);
							setLastActionNotice(null);
							toast("New conversation started");
						},
						title: "Start a fresh conversation",
						className: "flex items-center gap-1 rounded-full border bg-muted/60 px-2.5 py-1 text-xs text-muted-foreground transition hover:bg-muted",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(RotateCcw, { className: "h-3.5 w-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 436,
							columnNumber: 15
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: "New Chat" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 437,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 429,
						columnNumber: 13
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
						onClick: toggleAutoSpeak,
						title: autoSpeak ? "Voice auto-playback is ON. Click to mute." : "Voice auto-playback is OFF. Click to enable.",
						className: "flex items-center gap-1 rounded-full border bg-muted/60 px-2.5 py-1 text-xs text-muted-foreground transition hover:bg-muted",
						children: [autoSpeak ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Volume2, { className: "h-3.5 w-3.5 text-violet" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 441,
							columnNumber: 28
						}, this) : /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(VolumeX, { className: "h-3.5 w-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 441,
							columnNumber: 78
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: autoSpeak ? "Voice On" : "Voice Off" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 442,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 440,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 428,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 422,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "mt-4 flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
						onClick: () => send("Show me my course material progress and what lesson is next."),
						className: "flex items-center gap-1 rounded-full bg-lilac px-3 py-1 text-xs transition hover:bg-lilac/80",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(FileText, { className: "h-3 w-3" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 449,
							columnNumber: 13
						}, this), "Course material"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 448,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
						onClick: () => send(`Summarize my profile standing for ${store.goal}.`),
						className: "flex items-center gap-1 rounded-full bg-lilac px-3 py-1 text-xs transition hover:bg-lilac/80",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(UserPen, { className: "h-3 w-3" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 453,
							columnNumber: 13
						}, this), "My profile"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 452,
						columnNumber: 11
					}, this),
					store.cvName && /* @__PURE__ */ (void 0)("span", {
						className: "flex items-center gap-1 rounded-full bg-mint/50 px-3 py-1 text-xs text-primary-foreground",
						children: [
							/* @__PURE__ */ (void 0)(Check, { className: "h-3 w-3" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 457,
								columnNumber: 15
							}, this),
							"CV: ",
							store.cvName
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 456,
						columnNumber: 28
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 447,
				columnNumber: 9
			}, this),
			lastActionNotice && /* @__PURE__ */ (void 0)("div", {
				className: "mt-3 flex items-center gap-1.5 rounded-xl bg-mint/30 px-3 py-1.5 text-xs text-foreground animate-in fade-in",
				children: [/* @__PURE__ */ (void 0)(Check, { className: "h-3.5 w-3.5 text-success" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 463,
					columnNumber: 13
				}, this), /* @__PURE__ */ (void 0)("span", { children: lastActionNotice }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 464,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 462,
				columnNumber: 30
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "mt-6 max-h-[380px] space-y-3 overflow-y-auto pr-1",
				children: [
					msgs.map((m, i) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: `flex gap-2 ${m.me ? "justify-end" : ""}`,
						children: [!m.me && /* @__PURE__ */ (void 0)(Sparkles, { className: "mt-1 h-4 w-4 shrink-0 text-violet" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 469,
							columnNumber: 25
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: `group relative max-w-[80%] rounded-2xl px-4 py-2.5 text-sm ${m.me ? "bg-lilac text-foreground" : m.error ? "border border-destructive/40 bg-destructive/10 text-destructive-foreground" : "bg-muted/70 text-foreground"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
									className: "whitespace-pre-line leading-relaxed",
									children: m.t
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 471,
									columnNumber: 17
								}, this),
								m.error && m.retryText && /* @__PURE__ */ (void 0)("div", {
									className: "mt-2 flex items-center justify-end",
									children: /* @__PURE__ */ (void 0)("button", {
										onClick: () => send(m.retryText),
										className: "rounded-full bg-destructive/20 px-2.5 py-1 text-[11px] font-semibold text-destructive hover:bg-destructive/30",
										children: "Retry"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 474,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 473,
									columnNumber: 44
								}, this),
								!m.me && !m.error && /* @__PURE__ */ (void 0)("div", {
									className: "mt-1 flex items-center justify-end",
									children: /* @__PURE__ */ (void 0)("button", {
										type: "button",
										onClick: () => handlePlayMessage(i, m.t),
										title: speaking && speakingIdx === i ? "Stop speaking" : "Listen to this message",
										"aria-label": "Listen to message",
										className: "rounded-full p-1 text-muted-foreground opacity-60 transition hover:bg-muted hover:opacity-100",
										children: speaking && speakingIdx === i ? /* @__PURE__ */ (void 0)(VolumeX, { className: "h-3.5 w-3.5 text-destructive animate-pulse" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 481,
											columnNumber: 56
										}, this) : /* @__PURE__ */ (void 0)(Volume2, { className: "h-3.5 w-3.5" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 481,
											columnNumber: 125
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 480,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 479,
									columnNumber: 39
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 470,
							columnNumber: 15
						}, this)]
					}, i, true, {
						fileName: _jsxFileName,
						lineNumber: 468,
						columnNumber: 31
					}, this)),
					processing && /* @__PURE__ */ (void 0)("div", {
						className: "flex items-center gap-2 text-xs text-muted-foreground",
						children: [/* @__PURE__ */ (void 0)(Sparkles, { className: "h-4 w-4 animate-spin text-violet" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 488,
							columnNumber: 15
						}, this), /* @__PURE__ */ (void 0)("span", { children: "Pathfinder AI is thinking…" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 489,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 487,
						columnNumber: 26
					}, this),
					speaking && /* @__PURE__ */ (void 0)("div", {
						className: "flex items-center gap-2 text-xs text-violet",
						children: [/* @__PURE__ */ (void 0)(Volume2, { className: "h-4 w-4 animate-pulse text-violet" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 493,
							columnNumber: 15
						}, this), /* @__PURE__ */ (void 0)("span", { children: "Playing audio response… (tap speaker or mic to stop)" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 494,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 492,
						columnNumber: 24
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { ref: messagesEndRef }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 497,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 467,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
				className: "mt-6 text-center text-xs text-muted-foreground",
				children: "Use tags for better assistance"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 500,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "mt-2 flex flex-wrap justify-center gap-2",
				children: activeChips.map((c, i) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
					onClick: () => send(c),
					className: `rounded-full px-3 py-1 text-xs transition hover:scale-105 ${[
						"bg-lilac",
						"bg-blush",
						"bg-butter"
					][i % 3]}`,
					children: c
				}, c, false, {
					fileName: _jsxFileName,
					lineNumber: 504,
					columnNumber: 38
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 503,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "mt-5 flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
					type: "button",
					onClick: toggleVoice,
					"aria-label": "Voice input",
					title: speaking ? "Stop speaking" : listening ? "Stop listening (keep transcription)" : "Start voice input",
					className: `grid h-11 w-11 shrink-0 place-items-center rounded-full bg-ink text-ink-foreground transition ${listening ? "pulse-ring ring-4 ring-violet" : speaking ? "pulse-ring ring-4 ring-mint" : ""}`,
					children: processing ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(LoaderCircle, { className: "h-5 w-5 animate-spin" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 511,
						columnNumber: 27
					}, this) : speaking ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Volume2, { className: "h-5 w-5 text-mint" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 511,
						columnNumber: 85
					}, this) : /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Mic, { className: "h-5 w-5" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 511,
						columnNumber: 129
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 510,
					columnNumber: 11
				}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("form", {
					onSubmit: (e) => {
						e.preventDefault();
						send(text);
					},
					className: "ai-ring flex flex-1 items-center rounded-full px-4 py-2",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("input", {
						value: text,
						onChange: (e) => setText(e.target.value),
						placeholder: listening ? "Listening to your voice… tap mic to stop & edit" : processing ? "Consulting Gemini career advisor…" : speaking ? "Playing audio… (tap mic to stop)" : "Ask me anything… (type or tap mic to speak)",
						className: "flex-1 bg-transparent text-sm outline-none"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 517,
						columnNumber: 13
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
						type: "submit",
						"aria-label": "Send",
						disabled: processing || !text.trim(),
						className: "disabled:opacity-40",
						children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(SendHorizontal, { className: "h-4 w-4" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 519,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 518,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 513,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 509,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 420,
		columnNumber: 7
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 419,
		columnNumber: 10
	}, this);
}
//#endregion
export { Assistant as component };
