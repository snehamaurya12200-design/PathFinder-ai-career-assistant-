import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as require_jsx_dev_runtime } from "../_libs/react.mjs";
import { D as Search, Mt as BookOpen, N as Play, Nt as Bell, R as Mic, Tt as CalendarDays, U as Lock, _t as CircleCheck, dt as Clock, ft as ClipboardCheck, g as Target, n as X, pt as Circle, t as Zap, y as Sparkles, yt as ChevronRight } from "../_libs/lucide-react.mjs";
import { f as usePathfinder, l as actions } from "./AppShell-CmHrRTAn.mjs";
import { t as Button } from "./button-Cp1tlOE-.mjs";
import { c as recommend, i as courses, l as testBank, n as ALL_EDUCATION_LEVELS, t as ALL_ACADEMIC_STREAMS } from "./pathfinder-data-LKyDtySq.mjs";
import { a as MockTestDialog, i as MockInterviewDialog, n as CourseDialog } from "./dialogs-MK7DwIGg.mjs";
import { t as SectionShell } from "./SectionShell-C61_JkBB.mjs";
import { t as Route } from "./learning-BZc-L7MH.mjs";
import { t as SkillRadar } from "./SkillRadar-CVZpZYb5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/learning-CTHPXpuJ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_dev_runtime = require_jsx_dev_runtime();
var leadership_jpg_asset_default = {
	version: 1,
	asset_id: "26cd7f14-5eea-4815-a1b3-a79e37c12283",
	project_id: "8986ea04-752f-406b-86ad-f779e4b7a1fe",
	url: "/__l5e/assets-v1/26cd7f14-5eea-4815-a1b3-a79e37c12283/leadership.jpg",
	r2_key: "a/v1/8986ea04-752f-406b-86ad-f779e4b7a1fe/26cd7f14-5eea-4815-a1b3-a79e37c12283/leadership.jpg",
	original_filename: "leadership.jpg",
	size: 2890,
	content_type: "image/jpeg",
	created_at: "2026-10-31T12:21:48Z"
};
var feedback_jpg_asset_default = {
	version: 1,
	asset_id: "c9008833-f914-4aeb-81d8-f3b29fefae59",
	project_id: "8986ea04-752f-406b-86ad-f779e4b7a1fe",
	url: "/__l5e/assets-v1/c9008833-f914-4aeb-81d8-f3b29fefae59/feedback.jpg",
	r2_key: "a/v1/8986ea04-752f-406b-86ad-f779e4b7a1fe/c9008833-f914-4aeb-81d8-f3b29fefae59/feedback.jpg",
	original_filename: "feedback.jpg",
	size: 2929,
	content_type: "image/jpeg",
	created_at: "2026-10-31T12:21:43Z"
};
var awareness_jpg_asset_default = {
	version: 1,
	asset_id: "5b27b568-e9ff-481b-8149-7ada3cf4fb89",
	project_id: "8986ea04-752f-406b-86ad-f779e4b7a1fe",
	url: "/__l5e/assets-v1/5b27b568-e9ff-481b-8149-7ada3cf4fb89/awareness.jpg",
	r2_key: "a/v1/8986ea04-752f-406b-86ad-f779e4b7a1fe/5b27b568-e9ff-481b-8149-7ada3cf4fb89/awareness.jpg",
	original_filename: "awareness.jpg",
	size: 2637,
	content_type: "image/jpeg",
	created_at: "2026-10-31T12:21:40Z"
};
var practices_jpg_asset_default = {
	version: 1,
	asset_id: "c171f921-a250-4bf9-8ae7-7e248af73fb8",
	project_id: "8986ea04-752f-406b-86ad-f779e4b7a1fe",
	url: "/__l5e/assets-v1/c171f921-a250-4bf9-8ae7-7e248af73fb8/practices.jpg",
	r2_key: "a/v1/8986ea04-752f-406b-86ad-f779e4b7a1fe/c171f921-a250-4bf9-8ae7-7e248af73fb8/practices.jpg",
	original_filename: "practices.jpg",
	size: 1982,
	content_type: "image/jpeg",
	created_at: "2026-10-31T12:21:50Z"
};
var styles_jpg_asset_default = {
	version: 1,
	asset_id: "415cdfb5-b6e2-4988-a7a6-13d040332b42",
	project_id: "8986ea04-752f-406b-86ad-f779e4b7a1fe",
	url: "/__l5e/assets-v1/415cdfb5-b6e2-4988-a7a6-13d040332b42/styles.jpg",
	r2_key: "a/v1/8986ea04-752f-406b-86ad-f779e4b7a1fe/415cdfb5-b6e2-4988-a7a6-13d040332b42/styles.jpg",
	original_filename: "styles.jpg",
	size: 2987,
	content_type: "image/jpeg",
	created_at: "2026-10-31T12:21:52Z"
};
var constructive_jpg_asset_default = {
	version: 1,
	asset_id: "a894528b-5b0c-4298-a5c0-ef120df2c40b",
	project_id: "8986ea04-752f-406b-86ad-f779e4b7a1fe",
	url: "/__l5e/assets-v1/a894528b-5b0c-4298-a5c0-ef120df2c40b/constructive.jpg",
	r2_key: "a/v1/8986ea04-752f-406b-86ad-f779e4b7a1fe/a894528b-5b0c-4298-a5c0-ef120df2c40b/constructive.jpg",
	original_filename: "constructive.jpg",
	size: 2866,
	content_type: "image/jpeg",
	created_at: "2026-10-31T12:21:41Z"
};
var _jsxFileName = "/app/applet/src/routes/learning.tsx?tsr-split=component";
var lessons = [
	{
		title: "Getting started: your first position",
		image: null,
		done: true,
		date: "Mar 16, 2022",
		mins: 5,
		about: "Understand where you stand today as a team member and future leader."
	},
	{
		title: "Giving feedback",
		image: feedback_jpg_asset_default,
		done: true,
		date: "Mar 22, 2022",
		mins: 8,
		about: "Learn simple ways to share feedback that people welcome."
	},
	{
		title: "Learn more about leadership",
		image: awareness_jpg_asset_default,
		done: true,
		date: "Mar 29, 2022",
		mins: 10,
		about: "What leadership really means and why it matters at work."
	},
	{
		title: "Good practices",
		image: practices_jpg_asset_default,
		done: true,
		date: "Apr 5, 2022",
		mins: 7,
		about: "Everyday habits of effective team leaders."
	},
	{
		title: "Leadership styles",
		image: styles_jpg_asset_default,
		done: true,
		date: "Apr 12, 2022",
		mins: 9,
		about: "Discover different leadership styles and when to use each one."
	},
	{
		title: "Constructive feedback",
		image: constructive_jpg_asset_default,
		done: true,
		date: "Apr 19, 2022",
		mins: 8,
		about: "Turn criticism into clear, helpful next steps."
	},
	{
		title: "The leader in detail",
		image: practices_jpg_asset_default,
		done: true,
		date: "Apr 26, 2022",
		mins: 12,
		about: "A closer look at the skills a great leader uses every day."
	},
	{
		title: "The art of feedback",
		image: leadership_jpg_asset_default,
		done: false,
		date: "May 3, 2022",
		mins: 10,
		about: "Master timing, tone and follow-up when giving feedback."
	},
	{
		title: "Putting it into practice",
		image: constructive_jpg_asset_default,
		done: false,
		date: "May 10, 2022",
		mins: 15,
		about: "Apply everything you learned in a real-life scenario."
	}
];
function Learning() {
	const [selected, setSelected] = (0, import_react.useState)(lessons.findIndex((l) => !l.done));
	const [reminder, setReminder] = (0, import_react.useState)(true);
	const [done, setDone] = (0, import_react.useState)(lessons.map((l) => l.done));
	const lesson = lessons[selected];
	const completed = done.filter(Boolean).length;
	const pct = Math.round(completed / lessons.length * 100);
	const nextOpen = done.findIndex((d) => !d);
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(SectionShell, { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
		className: "section-surface",
		children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
			className: "mb-6 flex flex-wrap items-start justify-between gap-4",
			children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h1", {
				className: "flex items-center gap-2 text-2xl font-bold",
				children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(BookOpen, { className: "h-5 w-5" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 95,
					columnNumber: 15
				}, this), "Management in the Workplace"]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 94,
				columnNumber: 13
			}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
				className: "mt-2 flex items-center gap-2 text-xs text-muted-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
						className: "rounded-full bg-mint px-2 py-0.5 font-semibold text-primary-foreground",
						children: "In progress"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 99,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(CalendarDays, { className: "h-3.5 w-3.5" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 102,
						columnNumber: 15
					}, this),
					"Feb 28, 2022 – May 31, 2022"
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 98,
				columnNumber: 13
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 93,
				columnNumber: 11
			}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "min-w-56 rounded-xl border bg-card p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "flex justify-between text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("b", { children: "Your progress" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 108,
							columnNumber: 15
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
							className: "text-muted-foreground",
							children: [
								completed,
								" of ",
								lessons.length,
								" lessons"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 109,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 107,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "mt-2 h-2 rounded-full bg-muted",
						children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "h-full rounded-full bg-mint transition-all",
							style: { width: `${pct}%` }
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 114,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 113,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
						className: "mt-1 text-right text-[10px] font-semibold text-success",
						children: [pct, "% complete"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 118,
						columnNumber: 13
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 106,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 92,
			columnNumber: 9
		}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
			className: "grid items-start gap-6 xl:grid-cols-[1.3fr_1fr]",
			children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("section", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "mb-4 flex items-center gap-3 rounded-xl border bg-card p-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("img", {
						src: leadership_jpg_asset_default.url,
						alt: "Leadership workshop",
						className: "h-12 w-14 rounded-lg object-cover"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 127,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h2", {
						className: "font-semibold",
						children: "Becoming a Leader"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 129,
						columnNumber: 17
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
						className: "text-[11px] text-muted-foreground",
						children: "9 short lessons · about 1.5 hours"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 130,
						columnNumber: 17
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 128,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Button, {
						variant: "ghost",
						size: "sm",
						"aria-pressed": reminder,
						onClick: () => setReminder(!reminder),
						className: "ml-auto rounded-full text-orange",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Bell, { className: reminder ? "fill-orange" : "" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 135,
							columnNumber: 17
						}, this), reminder ? "Reminder on" : "Remind me"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 134,
						columnNumber: 15
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 126,
				columnNumber: 13
			}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("ol", {
				className: "space-y-2",
				children: lessons.map((item, i) => {
					const isDone = done[i], locked = !isDone && i !== nextOpen;
					return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("li", { children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
						disabled: locked,
						onClick: () => setSelected(i),
						className: `flex w-full items-center gap-3 rounded-xl border bg-card p-2 text-left transition ${selected === i ? "border-chart-cyan ring-2 ring-chart-cyan/30" : "hover:bg-muted/50"} ${locked ? "opacity-50" : ""}`,
						children: [
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
								className: "w-5 text-center text-xs font-bold text-muted-foreground",
								children: i + 1
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 146,
								columnNumber: 23
							}, this),
							item.image ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("img", {
								src: item.image.url,
								alt: "",
								className: "h-11 w-11 shrink-0 rounded-lg object-cover"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 149,
								columnNumber: 37
							}, this) : /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
								className: "grid h-11 w-11 shrink-0 place-items-center rounded-lg bg-muted",
								children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Target, { className: "h-5 w-5 text-muted-foreground" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 150,
									columnNumber: 27
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 149,
								columnNumber: 130
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
									className: "block truncate text-sm font-medium",
									children: item.title
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 153,
									columnNumber: 25
								}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
									className: "text-[11px] text-muted-foreground",
									children: [
										item.mins,
										" min · ",
										item.date
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 154,
									columnNumber: 25
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 152,
								columnNumber: 23
							}, this),
							isDone ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(CircleCheck, { className: "h-5 w-5 text-success" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 158,
								columnNumber: 33
							}, this) : locked ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Lock, { className: "h-4 w-4 text-muted-foreground" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 158,
								columnNumber: 94
							}, this) : /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
								className: "rounded-full bg-orange px-2 py-0.5 text-[10px] font-semibold text-primary-foreground",
								children: "Up next"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 158,
								columnNumber: 147
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 145,
						columnNumber: 21
					}, this) }, item.title, false, {
						fileName: _jsxFileName,
						lineNumber: 144,
						columnNumber: 22
					}, this);
				})
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 139,
				columnNumber: 13
			}, this)] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 125,
				columnNumber: 11
			}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("aside", {
				className: "space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "overflow-hidden rounded-xl border bg-card",
					children: [lesson.image && /* @__PURE__ */ (void 0)("img", {
						src: lesson.image.url,
						alt: "",
						className: "h-36 w-full object-cover"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 169,
						columnNumber: 32
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
								className: "text-[11px] text-muted-foreground",
								children: [
									"Lesson ",
									selected + 1,
									" · ",
									lesson.mins,
									" min"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 171,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h2", {
								className: "mt-1 text-lg font-semibold",
								children: lesson.title
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 174,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
								className: "mt-2 text-sm text-muted-foreground",
								children: lesson.about
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 175,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "mt-4 flex gap-2",
								children: [done[selected] ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Button, {
									size: "sm",
									variant: "outline",
									onClick: () => toast(`Replaying: ${lesson.title}`, { description: `${lesson.mins} min lesson` }),
									children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Play, {}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 180,
										columnNumber: 23
									}, this), "Watch again"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 177,
									columnNumber: 37
								}, this) : /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Button, {
									size: "sm",
									onClick: () => {
										const d = [...done];
										d[selected] = true;
										setDone(d);
										actions.lessonComplete();
										actions.boostSkills(["Design Leadership", "Communication"], 2);
										toast.success("Lesson complete", { description: "Leadership & communication progress updated." });
										setSelected(Math.min(selected + 1, lessons.length - 1));
									},
									children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Circle, {}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 193,
										columnNumber: 23
									}, this), "Mark as complete"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 182,
									columnNumber: 33
								}, this), selected < lessons.length - 1 && (done[selected] || selected + 1 === nextOpen) && /* @__PURE__ */ (void 0)(Button, {
									size: "sm",
									variant: "ghost",
									onClick: () => setSelected(selected + 1),
									children: ["Next ", /* @__PURE__ */ (void 0)(ChevronRight, {}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 197,
										columnNumber: 30
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 196,
									columnNumber: 102
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 176,
								columnNumber: 17
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 170,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 168,
					columnNumber: 13
				}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "rounded-xl border bg-card p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h3", {
							className: "text-sm font-semibold",
							children: "Your skills"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 203,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "mt-3 grid grid-cols-3 gap-2 text-center text-[11px]",
							children: [
								[
									Zap,
									`${pct}%`,
									"Success rate"
								],
								[
									Target,
									`${completed}/9`,
									"Skills mastered"
								],
								[
									Clock,
									"52 min",
									"Time spent"
								]
							].map(([Icon, value, label]) => {
								return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: "rounded-lg bg-muted p-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Icon, { className: "mx-auto h-4 w-4 text-chart-cyan" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 208,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("b", {
											className: "mt-1 block text-sm",
											children: String(value)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 209,
											columnNumber: 23
										}, this),
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
											className: "text-muted-foreground",
											children: String(label)
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 210,
											columnNumber: 23
										}, this)
									]
								}, String(label), true, {
									fileName: _jsxFileName,
									lineNumber: 207,
									columnNumber: 24
								}, this);
							})
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 204,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(SkillRadar, {
							compact: true,
							development: true
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 214,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "flex flex-wrap justify-center gap-3 text-[10px]",
							children: [
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
									className: "text-chart-cyan",
									children: "■ Current skill"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 216,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
									className: "text-chart-green",
									children: "■ Theoretical skill"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 217,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
									className: "text-muted-foreground",
									children: "■ Expected skill"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 218,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 215,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
							className: "mt-4 text-xs font-semibold",
							children: "What you will learn"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 220,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("ul", {
							className: "mt-2 space-y-1.5 text-xs text-muted-foreground",
							children: [
								"Give useful feedback to your team",
								"Show confident leadership",
								"Handle crisis situations calmly"
							].map((t) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("li", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(CircleCheck, { className: "h-3.5 w-3.5 shrink-0 text-success" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 223,
									columnNumber: 21
								}, this), t]
							}, t, true, {
								fileName: _jsxFileName,
								lineNumber: 222,
								columnNumber: 129
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 221,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 202,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 167,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 124,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 91,
		columnNumber: 7
	}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(CoursesHub, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 231,
		columnNumber: 7
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 90,
		columnNumber: 10
	}, this);
}
function CoursesHub() {
	const search = Route.useSearch();
	const goal = usePathfinder((s) => s.goal);
	const skills = usePathfinder((s) => s.skills);
	const enrolled = usePathfinder((s) => s.enrolled);
	const list = usePathfinder((s) => s.learningList);
	const tests = usePathfinder((s) => s.tests);
	const interviews = usePathfinder((s) => s.interviews);
	const customRoadmap = usePathfinder((s) => s.customRoadmap);
	const profile = usePathfinder((s) => s.profile);
	const [tab, setTab] = (0, import_react.useState)("All");
	const [searchQuery, setSearchQuery] = (0, import_react.useState)("");
	const [selectedLevel, setSelectedLevel] = (0, import_react.useState)("All");
	const [selectedStream, setSelectedStream] = (0, import_react.useState)("All");
	const [selectedDifficulty, setSelectedDifficulty] = (0, import_react.useState)("All");
	const [selectedPricing, setSelectedPricing] = (0, import_react.useState)("All");
	const [open, setOpen] = (0, import_react.useState)(search.course ? { id: search.course } : null);
	const [testOpen, setTestOpen] = (0, import_react.useState)(search.open === "test");
	const [subject, setSubject] = (0, import_react.useState)();
	const [ivOpen, setIvOpen] = (0, import_react.useState)(search.open === "interview");
	const hasActiveFilters = searchQuery.trim() !== "" || selectedLevel !== "All" || selectedStream !== "All" || selectedDifficulty !== "All" || selectedPricing !== "All";
	const resetFilters = () => {
		setSearchQuery("");
		setSelectedLevel("All");
		setSelectedStream("All");
		setSelectedDifficulty("All");
		setSelectedPricing("All");
	};
	const recs = recommend(goal, skills, Object.keys(enrolled), profile).slice(0, 3);
	const shown = courses.filter((c) => {
		if (tab === "Ongoing" && (enrolled[c.id] === void 0 || enrolled[c.id] >= 100)) return false;
		if (tab === "Completed" && enrolled[c.id] !== 100) return false;
		if (tab === "My list" && !list.includes(c.id)) return false;
		if (searchQuery.trim()) {
			const q = searchQuery.toLowerCase().trim();
			if (!(c.title.toLowerCase().includes(q) || c.desc.toLowerCase().includes(q) || c.provider && c.provider.toLowerCase().includes(q) || c.stream && c.stream.toLowerCase().includes(q) || c.category && c.category.toLowerCase().includes(q) || c.skills.some((s) => s.toLowerCase().includes(q)))) return false;
		}
		if (selectedLevel !== "All") {
			if (!c.educationLevels?.includes(selectedLevel)) return false;
		}
		if (selectedStream !== "All") {
			if (c.stream !== selectedStream) return false;
		}
		if (selectedDifficulty !== "All") {
			if (c.level !== selectedDifficulty) return false;
		}
		if (selectedPricing !== "All") {
			if (c.pricing !== selectedPricing) return false;
		}
		return true;
	});
	const lastIv = interviews[0];
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(import_jsx_dev_runtime.Fragment, { children: [
		customRoadmap && /* @__PURE__ */ (void 0)("div", {
			className: "section-surface mt-6 border border-violet/30 bg-lilac/20",
			children: [/* @__PURE__ */ (void 0)("div", {
				className: "flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ (void 0)("div", { children: [/* @__PURE__ */ (void 0)("h2", {
					className: "flex items-center gap-2 text-lg font-bold text-violet",
					children: [
						/* @__PURE__ */ (void 0)(Sparkles, { className: "h-5 w-5 text-violet" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 308,
							columnNumber: 17
						}, this),
						"Custom AI Roadmap: ",
						customRoadmap.goal
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 307,
					columnNumber: 15
				}, this), /* @__PURE__ */ (void 0)("p", {
					className: "mt-1 text-xs text-muted-foreground",
					children: customRoadmap.summary
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 311,
					columnNumber: 15
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 306,
					columnNumber: 13
				}, this), /* @__PURE__ */ (void 0)("span", {
					className: "rounded-full bg-violet/15 px-3 py-1 text-xs font-semibold text-violet",
					children: "Active Custom Plan"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 313,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 305,
				columnNumber: 11
			}, this), customRoadmap.weeks && customRoadmap.weeks.length > 0 && /* @__PURE__ */ (void 0)("div", {
				className: "mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
				children: customRoadmap.weeks.map((w) => /* @__PURE__ */ (void 0)("div", {
					className: "rounded-xl border bg-card p-3 shadow-xs",
					children: [
						/* @__PURE__ */ (void 0)("span", {
							className: "rounded-full bg-violet px-2 py-0.5 text-[10px] font-bold text-primary-foreground",
							children: ["Week ", w.week]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 320,
							columnNumber: 19
						}, this),
						/* @__PURE__ */ (void 0)("h3", {
							className: "mt-2 text-xs font-bold",
							children: w.title
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 323,
							columnNumber: 19
						}, this),
						w.topics && /* @__PURE__ */ (void 0)("ul", {
							className: "mt-2 space-y-1 text-[11px] text-muted-foreground",
							children: w.topics.slice(0, 3).map((t, idx) => /* @__PURE__ */ (void 0)("li", {
								className: "flex items-center gap-1.5",
								children: [/* @__PURE__ */ (void 0)("span", { className: "h-1 w-1 rounded-full bg-violet shrink-0" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 326,
									columnNumber: 27
								}, this), /* @__PURE__ */ (void 0)("span", { children: t }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 327,
									columnNumber: 27
								}, this)]
							}, idx, true, {
								fileName: _jsxFileName,
								lineNumber: 325,
								columnNumber: 61
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 324,
							columnNumber: 32
						}, this),
						w.deliverable && /* @__PURE__ */ (void 0)("p", {
							className: "mt-2 text-[10px] font-medium text-success",
							children: ["Target: ", w.deliverable]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 330,
							columnNumber: 37
						}, this)
					]
				}, w.week, true, {
					fileName: _jsxFileName,
					lineNumber: 319,
					columnNumber: 45
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 318,
				columnNumber: 69
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 304,
			columnNumber: 25
		}, this),
		/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
			className: "section-surface mt-6 border",
			children: [
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "mb-4 flex flex-wrap items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h2", {
						className: "flex items-center gap-2 text-lg font-bold",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(BookOpen, { className: "h-5 w-5 text-violet" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 342,
							columnNumber: 15
						}, this), "Course Catalogue & Learning Tracks"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 341,
						columnNumber: 13
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
						className: "text-xs text-muted-foreground mt-0.5",
						children: "Comprehensive courses across engineering, sciences, medical, commerce, humanities & civil services."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 345,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 340,
						columnNumber: 11
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "flex flex-wrap items-center gap-2",
						children: [
							"All",
							"Ongoing",
							"Completed",
							"My list"
						].map((t) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Button, {
							size: "sm",
							variant: "outline",
							onClick: () => setTab(t),
							className: tab === t ? "bg-lilac text-violet font-semibold" : "",
							children: t
						}, t, false, {
							fileName: _jsxFileName,
							lineNumber: 351,
							columnNumber: 77
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 350,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 339,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "mb-5 space-y-3 rounded-2xl border border-border/80 bg-background/60 p-3.5",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "flex flex-wrap items-center gap-2.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "relative min-w-[220px] flex-1",
								children: [
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Search, { className: "absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 362,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("input", {
										type: "text",
										value: searchQuery,
										onChange: (e) => setSearchQuery(e.target.value),
										placeholder: "Search by topic, skill, subject, or provider (e.g., Python, Anatomy, Khan, NPTEL)...",
										className: "w-full rounded-xl border border-input bg-card py-2 pl-9 pr-8 text-xs text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 363,
										columnNumber: 15
									}, this),
									searchQuery && /* @__PURE__ */ (void 0)("button", {
										onClick: () => setSearchQuery(""),
										className: "absolute right-2.5 top-2.5 text-muted-foreground hover:text-foreground",
										children: /* @__PURE__ */ (void 0)(X, { className: "h-4 w-4" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 365,
											columnNumber: 19
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 364,
										columnNumber: 31
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 361,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
								className: "rounded-full bg-muted px-2.5 py-1 text-[11px] font-medium text-muted-foreground",
								children: [
									shown.length,
									" ",
									shown.length === 1 ? "course" : "courses"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 370,
								columnNumber: 13
							}, this),
							hasActiveFilters && /* @__PURE__ */ (void 0)("button", {
								onClick: resetFilters,
								className: "flex items-center gap-1 rounded-full border border-border bg-card px-2.5 py-1 text-[11px] font-medium text-foreground transition hover:bg-muted",
								children: [/* @__PURE__ */ (void 0)(X, { className: "h-3 w-3 text-muted-foreground" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 375,
									columnNumber: 17
								}, this), "Reset filters"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 374,
								columnNumber: 34
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 359,
						columnNumber: 11
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "grid grid-cols-2 gap-2 sm:grid-cols-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("label", {
								className: "mb-1 block text-[10px] font-semibold uppercase text-muted-foreground",
								children: "Education Level"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 384,
								columnNumber: 15
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("select", {
								value: selectedLevel,
								onChange: (e) => setSelectedLevel(e.target.value),
								className: "w-full rounded-xl border border-input bg-card px-2.5 py-1.5 text-xs text-foreground focus:outline-none focus:ring-2 focus:ring-ring",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", {
									value: "All",
									children: "All Education Levels"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 388,
									columnNumber: 17
								}, this), ALL_EDUCATION_LEVELS.map((lvl) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", {
									value: lvl,
									children: lvl
								}, lvl, false, {
									fileName: _jsxFileName,
									lineNumber: 389,
									columnNumber: 50
								}, this))]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 387,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 383,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("label", {
								className: "mb-1 block text-[10px] font-semibold uppercase text-muted-foreground",
								children: "Academic Stream"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 397,
								columnNumber: 15
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("select", {
								value: selectedStream,
								onChange: (e) => setSelectedStream(e.target.value),
								className: "w-full rounded-xl border border-input bg-card px-2.5 py-1.5 text-xs text-foreground focus:outline-none focus:ring-2 focus:ring-ring",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", {
									value: "All",
									children: "All Streams"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 401,
									columnNumber: 17
								}, this), ALL_ACADEMIC_STREAMS.map((st) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", {
									value: st,
									children: st
								}, st, false, {
									fileName: _jsxFileName,
									lineNumber: 402,
									columnNumber: 49
								}, this))]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 400,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 396,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("label", {
								className: "mb-1 block text-[10px] font-semibold uppercase text-muted-foreground",
								children: "Difficulty"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 410,
								columnNumber: 15
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("select", {
								value: selectedDifficulty,
								onChange: (e) => setSelectedDifficulty(e.target.value),
								className: "w-full rounded-xl border border-input bg-card px-2.5 py-1.5 text-xs text-foreground focus:outline-none focus:ring-2 focus:ring-ring",
								children: [
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", {
										value: "All",
										children: "All Difficulties"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 414,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", {
										value: "Beginner",
										children: "Beginner"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 415,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", {
										value: "Intermediate",
										children: "Intermediate"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 416,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", {
										value: "Advanced",
										children: "Advanced"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 417,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 413,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 409,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("label", {
								className: "mb-1 block text-[10px] font-semibold uppercase text-muted-foreground",
								children: "Access Type"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 423,
								columnNumber: 15
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("select", {
								value: selectedPricing,
								onChange: (e) => setSelectedPricing(e.target.value),
								className: "w-full rounded-xl border border-input bg-card px-2.5 py-1.5 text-xs text-foreground focus:outline-none focus:ring-2 focus:ring-ring",
								children: [
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", {
										value: "All",
										children: "All Pricing Types"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 427,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", {
										value: "Free",
										children: "100% Free"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 428,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", {
										value: "Free to audit",
										children: "Free to Audit"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 429,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", {
										value: "Paid",
										children: "Paid Credential"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 430,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 426,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 422,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 381,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 358,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "grid gap-4 md:grid-cols-2 xl:grid-cols-3",
					children: [shown.map((c) => {
						const p = enrolled[c.id];
						return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
							onClick: () => setOpen({ id: c.id }),
							className: `rounded-2xl ${c.bg} p-4 text-left transition hover:-translate-y-0.5 hover:shadow-md flex flex-col justify-between`,
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: "flex items-start justify-between gap-2 font-semibold",
									children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
										className: "line-clamp-1 text-sm text-foreground",
										children: c.title
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 445,
										columnNumber: 21
									}, this), p === 100 ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(CircleCheck, { className: "h-4 w-4 shrink-0 text-success" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 446,
										columnNumber: 34
									}, this) : p !== void 0 ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
										className: "shrink-0 rounded-full bg-card/80 px-2 py-0.5 text-[10px] font-medium text-foreground",
										children: [p, "% done"]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 446,
										columnNumber: 113
									}, this) : c.pricing ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
										className: "shrink-0 rounded-full bg-card/80 px-2 py-0.5 text-[10px] font-bold text-success",
										children: c.pricing
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 448,
										columnNumber: 45
									}, this) : null]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 444,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: "mt-1 flex flex-wrap items-center gap-1.5 text-[10px] text-muted-foreground font-medium",
									children: [
										c.provider && /* @__PURE__ */ (void 0)("span", { children: c.provider }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 455,
											columnNumber: 36
										}, this),
										c.provider && c.stream && /* @__PURE__ */ (void 0)("span", { children: "·" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 456,
											columnNumber: 48
										}, this),
										c.stream && /* @__PURE__ */ (void 0)("span", { children: c.stream }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 457,
											columnNumber: 34
										}, this),
										c.isMedical && /* @__PURE__ */ (void 0)("span", {
											className: "rounded-full bg-destructive/10 px-1.5 py-0.2 text-[9px] font-bold text-destructive",
											children: "Academic"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 458,
											columnNumber: 37
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 454,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
									className: "mt-2 text-xs text-muted-foreground line-clamp-2",
									children: c.desc
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 463,
									columnNumber: 19
								}, this)
							] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 443,
								columnNumber: 17
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "mt-3",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: "flex flex-wrap gap-1.5",
									children: [
										`${c.lessons} lessons`,
										c.duration,
										c.level
									].map((t) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
										className: "rounded-full bg-card/70 px-2 py-0.5 text-[10px]",
										children: t
									}, t, false, {
										fileName: _jsxFileName,
										lineNumber: 468,
										columnNumber: 77
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 467,
									columnNumber: 19
								}, this), p !== void 0 && /* @__PURE__ */ (void 0)("div", {
									className: "mt-2.5 h-1.5 rounded-full bg-card/70",
									children: /* @__PURE__ */ (void 0)("div", {
										className: "h-full rounded-full bg-mint",
										style: { width: `${p}%` }
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 473,
										columnNumber: 23
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 472,
									columnNumber: 39
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 466,
								columnNumber: 17
							}, this)]
						}, c.id, true, {
							fileName: _jsxFileName,
							lineNumber: 440,
							columnNumber: 18
						}, this);
					}), shown.length === 0 && /* @__PURE__ */ (void 0)("div", {
						className: "col-span-full py-10 text-center",
						children: [
							/* @__PURE__ */ (void 0)("p", {
								className: "text-sm font-medium text-foreground",
								children: "No courses match your active filters."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 481,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ (void 0)("p", {
								className: "mt-1 text-xs text-muted-foreground",
								children: "Try loosening your search term or resetting stream and education level filters."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 484,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ (void 0)(Button, {
								size: "sm",
								variant: "outline",
								onClick: resetFilters,
								className: "mt-3",
								children: "Clear all filters"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 487,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 480,
						columnNumber: 34
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 437,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 337,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
			className: "section-surface mt-6 border",
			children: [
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h2", {
					className: "mb-1 flex items-center gap-2 text-lg font-bold",
					children: [
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Sparkles, { className: "h-5 w-5 text-violet" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 497,
							columnNumber: 11
						}, this),
						"Recommended for ",
						goal
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 496,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
					className: "mb-4 text-xs text-muted-foreground",
					children: [
						"Tailored to your ",
						profile.educationLevel || "academic",
						" profile in",
						" ",
						profile.stream || goal,
						" and verified skill gap analysis."
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 500,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "grid gap-4 md:grid-cols-3",
					children: [recs.map((r) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "flex flex-col rounded-xl border bg-card p-4",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
							onClick: () => setOpen({
								id: r.course.id,
								reason: r.reason
							}),
							className: "text-left",
							children: [
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: "flex items-center gap-1.5 text-[10px] text-muted-foreground font-medium",
									children: [
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: r.course.provider }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 511,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: "·" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 512,
											columnNumber: 19
										}, this),
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: r.course.stream }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 513,
											columnNumber: 19
										}, this)
									]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 510,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
									className: "font-semibold text-foreground mt-0.5",
									children: r.course.title
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 515,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
									className: "mt-1.5 text-xs text-muted-foreground",
									children: r.reason
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 516,
									columnNumber: 17
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 506,
							columnNumber: 15
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "mt-auto flex gap-2 pt-3",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Button, {
								size: "sm",
								variant: "outline",
								disabled: list.includes(r.course.id),
								onClick: () => {
									actions.addToList(r.course.id);
									toast.success("Added to your learning list");
								},
								children: list.includes(r.course.id) ? "In list" : "Add to list"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 519,
								columnNumber: 17
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Button, {
								size: "sm",
								onClick: () => setOpen({
									id: r.course.id,
									reason: r.reason
								}),
								children: "Details"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 525,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 518,
							columnNumber: 15
						}, this)]
					}, r.course.id, true, {
						fileName: _jsxFileName,
						lineNumber: 505,
						columnNumber: 26
					}, this)), recs.length === 0 && /* @__PURE__ */ (void 0)("p", {
						className: "text-sm text-muted-foreground",
						children: "You're enrolled in every recommended course for your profile."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 533,
						columnNumber: 33
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 504,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 495,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
			className: "mt-6 grid gap-6 md:grid-cols-2",
			children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "section-surface border",
				children: [
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h2", {
						className: "flex items-center gap-2 text-lg font-bold",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(ClipboardCheck, { className: "h-5 w-5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 542,
							columnNumber: 13
						}, this), "Mock tests & Academic Quizzes"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 541,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
						className: "mb-3 text-xs text-muted-foreground",
						children: "Multi-disciplinary timed quizzes across sciences, math, accounting, law, and engineering."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 545,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "flex flex-wrap gap-2",
						children: Object.keys(testBank).map((s) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Button, {
							size: "sm",
							variant: "outline",
							onClick: () => {
								setSubject(s);
								setTestOpen(true);
							},
							children: s
						}, s, false, {
							fileName: _jsxFileName,
							lineNumber: 550,
							columnNumber: 45
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 549,
						columnNumber: 11
					}, this),
					tests.length > 0 && /* @__PURE__ */ (void 0)("ul", {
						className: "mt-4 space-y-1 text-xs text-muted-foreground",
						children: tests.slice(0, 4).map((t, i) => /* @__PURE__ */ (void 0)("li", { children: [
							t.subject,
							":",
							" ",
							/* @__PURE__ */ (void 0)("b", {
								className: "text-foreground",
								children: [
									t.score,
									"/",
									t.total
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 560,
								columnNumber: 19
							}, this),
							" ",
							"· ",
							new Date(t.at).toLocaleDateString()
						] }, i, true, {
							fileName: _jsxFileName,
							lineNumber: 558,
							columnNumber: 48
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 557,
						columnNumber: 32
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 540,
				columnNumber: 9
			}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "section-surface border",
				children: [
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h2", {
						className: "flex items-center gap-2 text-lg font-bold",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Mic, { className: "h-5 w-5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 569,
							columnNumber: 13
						}, this), "Try your Mock Interview"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 568,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
						className: "mb-3 text-xs text-muted-foreground",
						children: "Answer role-specific questions one at a time and get AI feedback."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 572,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Button, {
						onClick: () => setIvOpen(true),
						children: "Start mock interview"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 575,
						columnNumber: 11
					}, this),
					lastIv && /* @__PURE__ */ (void 0)("p", {
						className: "mt-4 text-xs text-muted-foreground",
						children: [
							"Last: ",
							lastIv.role,
							" (",
							lastIv.difficulty,
							") —",
							" ",
							/* @__PURE__ */ (void 0)("b", {
								className: "text-foreground",
								children: [lastIv.score, "%"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 578,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 576,
						columnNumber: 22
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 567,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 539,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(CourseDialog, {
			courseId: open?.id ?? null,
			reason: open?.reason,
			open: open !== null,
			onOpenChange: (o) => !o && setOpen(null)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 583,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(MockTestDialog, {
			open: testOpen,
			initialSubject: subject,
			onOpenChange: (o) => {
				setTestOpen(o);
				if (!o) setSubject(void 0);
			}
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 584,
			columnNumber: 7
		}, this),
		/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(MockInterviewDialog, {
			open: ivOpen,
			onOpenChange: setIvOpen
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 588,
			columnNumber: 7
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 303,
		columnNumber: 10
	}, this);
}
//#endregion
export { Learning as component };
