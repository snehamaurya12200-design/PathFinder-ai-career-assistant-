import { o as __toESM } from "../_runtime.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { t as require_jsx_dev_runtime } from "../_libs/react.mjs";
import { F as NotebookPen, G as Lightbulb, N as Play, Nt as Bell, _t as CircleCheck, bt as ChevronLeft, c as UserRound, g as Target, gt as CircleDot, p as TriangleAlert, y as Sparkles } from "../_libs/lucide-react.mjs";
import { f as usePathfinder } from "./AppShell-CmHrRTAn.mjs";
import { t as Button } from "./button-Cp1tlOE-.mjs";
import { i as MockInterviewDialog } from "./dialogs-MK7DwIGg.mjs";
import { t as SectionShell } from "./SectionShell-C61_JkBB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/interviews-Dmx4bitl.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_dev_runtime = require_jsx_dev_runtime();
var interview_call_jpg_asset_default = {
	version: 1,
	asset_id: "6770ac51-d1e7-43ff-b877-1dc5e4409a8e",
	project_id: "8986ea04-752f-406b-86ad-f779e4b7a1fe",
	url: "/__l5e/assets-v1/6770ac51-d1e7-43ff-b877-1dc5e4409a8e/interview-call.jpg",
	r2_key: "a/v1/8986ea04-752f-406b-86ad-f779e4b7a1fe/6770ac51-d1e7-43ff-b877-1dc5e4409a8e/interview-call.jpg",
	original_filename: "interview-call.jpg",
	size: 43883,
	content_type: "image/jpeg",
	created_at: "2026-10-31T12:21:47Z"
};
var _jsxFileName = "/app/applet/src/routes/interviews.tsx?tsr-split=component";
function Donut({ breakdown }) {
	const r = 60, c = 2 * Math.PI * r, gap = 6;
	let offset = 0;
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("svg", {
		viewBox: "0 0 160 160",
		className: "h-40 w-40",
		children: breakdown.map((s) => {
			const len = s.value / 100 * c - gap;
			const el = /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("circle", {
				cx: "80",
				cy: "80",
				r,
				fill: "none",
				stroke: s.color,
				strokeWidth: "16",
				strokeLinecap: "round",
				strokeDasharray: `${len} ${c}`,
				strokeDashoffset: -offset,
				transform: "rotate(-90 80 80)"
			}, s.label, false, {
				fileName: _jsxFileName,
				lineNumber: 25,
				columnNumber: 18
			}, this);
			offset += s.value / 100 * c;
			return el;
		})
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 22,
		columnNumber: 10
	}, this);
}
function Interviews() {
	const st = usePathfinder((s) => s);
	const [moveOn, setMoveOn] = (0, import_react.useState)("yes");
	const [dialogOpen, setDialogOpen] = (0, import_react.useState)(false);
	const recs = [
		Lightbulb,
		Target,
		UserRound,
		NotebookPen
	];
	const latest = st.detailedInterviews?.[0];
	const interviewScore = latest?.score ?? st.interviews[0]?.score ?? 78;
	const roleTitle = latest?.role ?? st.goal;
	const breakdownData = latest ? [
		{
			label: "Technical",
			value: latest.breakdown.technical,
			color: "var(--chart-cyan)"
		},
		{
			label: "Clarity",
			value: latest.breakdown.relevance,
			color: "var(--chart-green)"
		},
		{
			label: "Emotion",
			value: latest.breakdown.problemSolving,
			color: "var(--sun)"
		},
		{
			label: "Communication",
			value: latest.breakdown.communication,
			color: "var(--chart-pink)"
		},
		{
			label: "Confidence",
			value: latest.breakdown.confidence,
			color: "var(--chart-blue)"
		}
	] : [
		{
			label: "Technical",
			value: 20,
			color: "var(--chart-cyan)"
		},
		{
			label: "Clarity",
			value: 10,
			color: "var(--chart-green)"
		},
		{
			label: "Emotion",
			value: 15,
			color: "var(--sun)"
		},
		{
			label: "Communication",
			value: 25,
			color: "var(--chart-pink)"
		},
		{
			label: "Confidence",
			value: 30,
			color: "var(--chart-blue)"
		}
	];
	const strengthInsight = latest?.strength ?? "You demonstrated good domain fundamentals and composure.";
	const improvementInsight = latest?.improvement ?? "Confidence dropped slightly during behavioral and system design questions.";
	const recommendationInsight = latest?.recommendation ?? "Practice answering behavioral questions using the STAR method for clearer structure.";
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(SectionShell, { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
		className: "rounded-2xl bg-interview-panel p-5",
		children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
			className: "mb-5 flex items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "flex items-center gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Button, {
					asChild: true,
					variant: "outline",
					size: "icon",
					"aria-label": "Back",
					className: "h-8 w-8 bg-card",
					children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Link, {
						to: "/",
						children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(ChevronLeft, {}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 89,
							columnNumber: 17
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 88,
						columnNumber: 15
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 87,
					columnNumber: 13
				}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h1", {
					className: "text-sm font-semibold",
					children: ["Interview for ", roleTitle]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 92,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 86,
				columnNumber: 11
			}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "flex items-center gap-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Button, {
						size: "sm",
						onClick: () => setDialogOpen(true),
						className: "flex items-center gap-1.5 bg-violet text-primary-foreground hover:bg-violet/90",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Play, { className: "h-3.5 w-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 96,
							columnNumber: 15
						}, this), " Start New Mock Interview"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 95,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Bell, { className: "h-5 w-5 text-destructive" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 98,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
						className: "rounded-full border bg-card px-6 py-1.5 text-xs font-semibold",
						children: "Yelena"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 99,
						columnNumber: 13
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 94,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 85,
			columnNumber: 9
		}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
			className: "grid gap-4 lg:grid-cols-[1fr_260px]",
			children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "relative overflow-hidden rounded-2xl",
					children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("img", {
						src: interview_call_jpg_asset_default.url,
						alt: "Interview video call",
						className: "h-64 w-full object-cover"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 108,
						columnNumber: 15
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 107,
					columnNumber: 13
				}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "grid gap-4 md:grid-cols-[1fr_1.5fr]",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "rounded-2xl bg-card p-4 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h2", {
								className: "text-xs font-semibold",
								children: "AI interview score"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 113,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "mx-auto my-4 flex h-28 w-28 items-center justify-center rounded-full border-[6px] border-interview-blue",
								children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
									className: "text-3xl font-extrabold text-interview-blue",
									children: [interviewScore, "%"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 115,
									columnNumber: 19
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 114,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
								className: "text-left text-[11px] text-muted-foreground",
								children: interviewScore >= 75 ? "Strong – mostly ready, keep sharpening edge cases" : "Good – a few specific areas to improve before live rounds"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 119,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "mt-3 flex items-center gap-2 text-[11px]",
								children: ["Move forward?", ["yes", "no"].map((v) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
									onClick: () => setMoveOn(v),
									className: `rounded-full px-3 py-0.5 capitalize ${moveOn === v ? "bg-violet text-primary-foreground" : "bg-muted"}`,
									children: v
								}, v, false, {
									fileName: _jsxFileName,
									lineNumber: 124,
									columnNumber: 54
								}, this))]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 122,
								columnNumber: 17
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 112,
						columnNumber: 15
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "rounded-2xl bg-card p-4",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h2", {
							className: "mx-auto mb-2 w-fit rounded-full bg-muted px-4 py-1 text-xs font-semibold",
							children: "AI Score Breakdown"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 130,
							columnNumber: 17
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "flex items-center justify-center gap-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("ul", {
									className: "space-y-3 text-[11px]",
									children: breakdownData.slice(0, 1).concat(breakdownData.slice(4)).map((s) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("li", { children: [
										s.label,
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("br", {}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 137,
											columnNumber: 27
										}, this),
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("b", { children: [s.value, "%"] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 138,
											columnNumber: 27
										}, this)
									] }, s.label, true, {
										fileName: _jsxFileName,
										lineNumber: 135,
										columnNumber: 88
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 134,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Donut, { breakdown: breakdownData }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 141,
									columnNumber: 19
								}, this),
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("ul", {
									className: "space-y-3 text-right text-[11px]",
									children: breakdownData.slice(1, 4).map((s) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("li", { children: [
										s.label,
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("br", {}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 145,
											columnNumber: 25
										}, this),
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("b", { children: [s.value, "%"] }, void 0, true, {
											fileName: _jsxFileName,
											lineNumber: 146,
											columnNumber: 25
										}, this)
									] }, s.label, true, {
										fileName: _jsxFileName,
										lineNumber: 143,
										columnNumber: 57
									}, this))
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 142,
									columnNumber: 19
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 133,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 129,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 111,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 106,
				columnNumber: 11
			}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "rounded-2xl bg-card p-4",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h2", {
						className: "mx-auto mb-4 w-fit rounded-full bg-muted px-3 py-1 text-xs font-semibold",
						children: "Practice recommendation"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 156,
						columnNumber: 15
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "grid grid-cols-2 gap-4",
						children: recs.map((Icon, i) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
							onClick: () => setDialogOpen(true),
							className: "flex aspect-square items-center justify-center rounded-xl bg-muted shadow-sm transition hover:-translate-y-0.5",
							children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Icon, { className: `h-8 w-8 ${[
								"text-sun",
								"text-destructive",
								"text-interview-blue",
								"text-violet"
							][i]}` }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 161,
								columnNumber: 21
							}, this)
						}, i, false, {
							fileName: _jsxFileName,
							lineNumber: 160,
							columnNumber: 40
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 159,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 155,
					columnNumber: 13
				}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "rounded-2xl bg-card p-4 text-[11px]",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h2", {
						className: "mb-3 flex items-center gap-2 text-sm font-medium",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Sparkles, { className: "h-4 w-4 text-violet" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 167,
							columnNumber: 17
						}, this), "AI Insights"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 166,
						columnNumber: 15
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "space-y-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(CircleCheck, { className: "h-4 w-4 shrink-0 text-success" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 172,
									columnNumber: 19
								}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: [
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("b", { children: "Strength Insight" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 174,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("br", {}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 175,
										columnNumber: 21
									}, this),
									strengthInsight
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 173,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 171,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(TriangleAlert, { className: "h-4 w-4 shrink-0 text-sun" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 180,
									columnNumber: 19
								}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: [
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("b", { children: "Improvement" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 182,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("br", {}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 183,
										columnNumber: 21
									}, this),
									improvementInsight
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 181,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 179,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
								className: "flex gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(CircleDot, { className: "h-4 w-4 shrink-0 text-destructive" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 188,
									columnNumber: 19
								}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: [
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("b", { children: "Actionable Recommendation" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 190,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("br", {}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 191,
										columnNumber: 21
									}, this),
									recommendationInsight
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 189,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 187,
								columnNumber: 17
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 170,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 165,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 154,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 105,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 84,
		columnNumber: 7
	}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(MockInterviewDialog, {
		open: dialogOpen,
		onOpenChange: setDialogOpen
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 200,
		columnNumber: 7
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 83,
		columnNumber: 10
	}, this);
}
//#endregion
export { Interviews as component };
