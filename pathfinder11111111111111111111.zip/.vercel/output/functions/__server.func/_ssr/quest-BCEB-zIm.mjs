import { o as __toESM } from "../_runtime.mjs";
import { b as useNavigate, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as generateFallbackCareerDNA, i as QUEST_STAGES, n as FALLBACK_ADAPTIVE_QUESTIONS, r as QUEST_ROUNDS, t as CORE_QUESTIONS } from "./career-quest-data-z5Aook2y.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { t as require_jsx_dev_runtime } from "../_libs/react.mjs";
import { $ as GraduationCap, A as RotateCcw, Dt as Briefcase, Ft as ArrowLeft, G as Lightbulb, J as Layers, Mt as BookOpen, O as School, Pt as ArrowRight, S as ShieldCheck, St as Check, W as LoaderCircle, Z as History, _t as CircleCheck, b as Shuffle, ct as Copy, dt as Clock, g as Target, ht as CircleQuestionMark, j as Printer, k as Save, kt as Brain, lt as Compass, n as X, rt as Flame, vt as ChevronUp, xt as ChevronDown, y as Sparkles } from "../_libs/lucide-react.mjs";
import { f as usePathfinder, l as actions, n as AppShell } from "./AppShell-CmHrRTAn.mjs";
import { a as generateCareerDNAServerFn, i as generateAdaptiveQuestionsServerFn } from "./ai.functions-u7pgug8o.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/quest-BCEB-zIm.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_dev_runtime = require_jsx_dev_runtime();
var _jsxFileName$8 = "/app/applet/src/components/career-quest/QuestDossierCover.tsx";
function QuestDossierCover({ onStart, onResume, onViewDNA, onOpenEvolution, existingDNA, historyCount = 0, inProgress }) {
	const [hoveredRound, setHoveredRound] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
		className: "relative min-h-[820px] w-full overflow-hidden rounded-3xl bg-[#FAF8F5] border border-stone-200/80 p-4 sm:p-8 md:p-12 shadow-sm font-sans select-none",
		children: [
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "absolute inset-0 pointer-events-none opacity-40",
				style: {
					backgroundImage: `
            linear-gradient(to right, #E8E3DA 1px, transparent 1px),
            linear-gradient(to bottom, #E8E3DA 1px, transparent 1px)
          `,
					backgroundSize: "28px 28px"
				}
			}, void 0, false, {
				fileName: _jsxFileName$8,
				lineNumber: 39,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "absolute top-10 left-10 w-96 h-96 bg-lilac/20 rounded-full blur-3xl pointer-events-none" }, void 0, false, {
				fileName: _jsxFileName$8,
				lineNumber: 51,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "absolute bottom-10 right-10 w-96 h-96 bg-sun/15 rounded-full blur-3xl pointer-events-none" }, void 0, false, {
				fileName: _jsxFileName$8,
				lineNumber: 52,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "relative z-10 flex flex-wrap items-center justify-between gap-4 border-b border-stone-200/80 pb-4",
				children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "flex items-center gap-2 text-xs font-mono tracking-widest text-stone-500 uppercase",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { className: "inline-block w-2 h-2 rounded-full bg-emerald-500 animate-pulse" }, void 0, false, {
						fileName: _jsxFileName$8,
						lineNumber: 57,
						columnNumber: 11
					}, this), "PATHFINDER DOSSIER // REF: QUEST-2026.4"]
				}, void 0, true, {
					fileName: _jsxFileName$8,
					lineNumber: 56,
					columnNumber: 9
				}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "flex items-center gap-3 text-xs text-stone-600 font-medium",
					children: [
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
							className: "rounded-full bg-stone-200/70 px-2.5 py-1",
							children: "5 Discovery Rounds"
						}, void 0, false, {
							fileName: _jsxFileName$8,
							lineNumber: 61,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
							className: "rounded-full bg-stone-200/70 px-2.5 py-1",
							children: "Gemini AI Synthesized"
						}, void 0, false, {
							fileName: _jsxFileName$8,
							lineNumber: 62,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
							className: "rounded-full bg-emerald-100 text-emerald-800 px-2.5 py-1 font-semibold",
							children: "100% Free & Ungraded"
						}, void 0, false, {
							fileName: _jsxFileName$8,
							lineNumber: 63,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName$8,
					lineNumber: 60,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName$8,
				lineNumber: 55,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "relative z-10 mx-auto mt-6 max-w-3xl",
				children: [
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "absolute inset-0 translate-x-3 translate-y-3 rotate-1 rounded-2xl bg-[#EFECE6] border border-stone-300 shadow-md opacity-70 pointer-events-none" }, void 0, false, {
						fileName: _jsxFileName$8,
						lineNumber: 72,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "absolute inset-0 -translate-x-2 translate-y-1.5 -rotate-1 rounded-2xl bg-[#F5F2EB] border border-stone-300 shadow-lg pointer-events-none" }, void 0, false, {
						fileName: _jsxFileName$8,
						lineNumber: 75,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "relative rounded-2xl bg-white border border-stone-200/90 p-6 sm:p-10 md:p-12 shadow-xl",
						children: [
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "absolute -top-4 left-10 sm:left-14 w-6 h-14 pointer-events-none",
								children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("svg", {
									viewBox: "0 0 24 56",
									fill: "none",
									className: "w-full h-full drop-shadow-md",
									children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("path", {
										d: "M 6 12 L 6 42 C 6 49 18 49 18 42 L 18 6 C 18 1 10 1 10 6 L 10 40 C 10 44 14 44 14 40 L 14 16",
										stroke: "#64748b",
										strokeWidth: "2.4",
										strokeLinecap: "round",
										strokeLinejoin: "round",
										fill: "none"
									}, void 0, false, {
										fileName: _jsxFileName$8,
										lineNumber: 82,
										columnNumber: 15
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName$8,
									lineNumber: 81,
									columnNumber: 13
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName$8,
								lineNumber: 80,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "absolute -right-4 top-40 hidden sm:block w-9 h-14 pointer-events-none",
								children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: "relative w-8 h-12 bg-neutral-800 rounded-sm shadow-lg flex items-center justify-center",
									children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "w-4 h-10 border-2 border-slate-300 rounded-t-full -ml-6" }, void 0, false, {
										fileName: _jsxFileName$8,
										lineNumber: 96,
										columnNumber: 15
									}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "w-1.5 h-6 bg-neutral-600 rounded" }, void 0, false, {
										fileName: _jsxFileName$8,
										lineNumber: 97,
										columnNumber: 15
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName$8,
									lineNumber: 95,
									columnNumber: 13
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName$8,
								lineNumber: 94,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "mb-4 inline-flex items-center gap-2 rounded-full border border-orange/40 bg-orange/10 px-3 py-1 text-xs font-semibold tracking-wide text-orange",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { className: "w-1.5 h-1.5 rounded-full bg-orange animate-ping" }, void 0, false, {
									fileName: _jsxFileName$8,
									lineNumber: 103,
									columnNumber: 13
								}, this), "Before You Pick Any Career Path..."]
							}, void 0, true, {
								fileName: _jsxFileName$8,
								lineNumber: 102,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "mt-2 text-stone-900",
								children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h1", {
									className: "font-extrabold tracking-tight text-3xl sm:text-5xl md:text-6xl leading-[1.12]",
									children: [
										"I Ask",
										" ",
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
											className: "relative inline-block mx-1",
											children: [
												/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
													className: "relative z-10 px-2 py-0.5 text-violet",
													children: "These Five"
												}, void 0, false, {
													fileName: _jsxFileName$8,
													lineNumber: 113,
													columnNumber: 17
												}, this),
												/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { className: "absolute inset-0 bg-lilac/50 border border-violet/40 rounded-sm -rotate-0.5" }, void 0, false, {
													fileName: _jsxFileName$8,
													lineNumber: 114,
													columnNumber: 17
												}, this),
												/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { className: "absolute -top-1 -left-1 w-1.5 h-1.5 bg-violet rounded-full" }, void 0, false, {
													fileName: _jsxFileName$8,
													lineNumber: 115,
													columnNumber: 17
												}, this),
												/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { className: "absolute -bottom-1 -right-1 w-1.5 h-1.5 bg-violet rounded-full" }, void 0, false, {
													fileName: _jsxFileName$8,
													lineNumber: 116,
													columnNumber: 17
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName$8,
											lineNumber: 111,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("br", {}, void 0, false, {
											fileName: _jsxFileName$8,
											lineNumber: 118,
											columnNumber: 15
										}, this),
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
											className: "relative inline-block my-1.5",
											children: [
												/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
													className: "relative z-10 px-3 py-0.5 text-orange",
													children: "Questions"
												}, void 0, false, {
													fileName: _jsxFileName$8,
													lineNumber: 121,
													columnNumber: 17
												}, this),
												/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { className: "absolute inset-0 bg-blush/60 border border-orange/50 rounded-sm rotate-0.5" }, void 0, false, {
													fileName: _jsxFileName$8,
													lineNumber: 122,
													columnNumber: 17
												}, this),
												/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { className: "absolute -top-1 -left-1 w-1.5 h-1.5 bg-orange rounded-full" }, void 0, false, {
													fileName: _jsxFileName$8,
													lineNumber: 123,
													columnNumber: 17
												}, this),
												/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { className: "absolute -top-1 -right-1 w-1.5 h-1.5 bg-orange rounded-full" }, void 0, false, {
													fileName: _jsxFileName$8,
													lineNumber: 124,
													columnNumber: 17
												}, this),
												/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { className: "absolute -bottom-1 -left-1 w-1.5 h-1.5 bg-orange rounded-full" }, void 0, false, {
													fileName: _jsxFileName$8,
													lineNumber: 125,
													columnNumber: 17
												}, this),
												/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { className: "absolute -bottom-1 -right-1 w-1.5 h-1.5 bg-orange rounded-full" }, void 0, false, {
													fileName: _jsxFileName$8,
													lineNumber: 126,
													columnNumber: 17
												}, this)
											]
										}, void 0, true, {
											fileName: _jsxFileName$8,
											lineNumber: 119,
											columnNumber: 15
										}, this),
										" ",
										"First."
									]
								}, void 0, true, {
									fileName: _jsxFileName$8,
									lineNumber: 109,
									columnNumber: 13
								}, this)
							}, void 0, false, {
								fileName: _jsxFileName$8,
								lineNumber: 108,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
								className: "mt-4 text-base sm:text-lg text-stone-600 font-normal leading-relaxed max-w-xl",
								children: [
									"A career without self-direction is just guesswork. Career Quest is a thoughtful, 5-round discovery adventure that maps your instincts, superpowers, and deep motivations into a personalized ",
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("strong", {
										className: "text-stone-900 font-semibold",
										children: "Career DNA"
									}, void 0, false, {
										fileName: _jsxFileName$8,
										lineNumber: 136,
										columnNumber: 26
									}, this),
									" ",
									"report."
								]
							}, void 0, true, {
								fileName: _jsxFileName$8,
								lineNumber: 133,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "my-6 inline-block rotate-[-0.5deg] rounded bg-[#EAE5D9] px-4 py-1.5 text-xs sm:text-sm text-stone-700 font-mono shadow-inner border border-stone-300",
								children: "📌 15 Core Questions • 3-5 Adaptive AI Follow-ups • 6 Minutes • Zero Judgments"
							}, void 0, false, {
								fileName: _jsxFileName$8,
								lineNumber: 141,
								columnNumber: 11
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "mt-2 grid grid-cols-1 sm:grid-cols-5 gap-2",
								children: QUEST_ROUNDS.map((r) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									onMouseEnter: () => setHoveredRound(r.number),
									onMouseLeave: () => setHoveredRound(null),
									className: `cursor-default rounded-xl border p-2.5 transition-all text-left ${hoveredRound === r.number ? "border-stone-900 bg-stone-900 text-white shadow-md scale-105" : "border-stone-200 bg-stone-50/70 hover:bg-stone-100/80 text-stone-800"}`,
									children: [
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "text-[10px] font-mono font-bold opacity-70",
											children: ["ROUND 0", r.number]
										}, void 0, true, {
											fileName: _jsxFileName$8,
											lineNumber: 158,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "text-xs font-bold truncate mt-0.5",
											children: r.title.replace("THE ", "")
										}, void 0, false, {
											fileName: _jsxFileName$8,
											lineNumber: 159,
											columnNumber: 17
										}, this),
										/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "text-[10px] opacity-75 line-clamp-1 mt-0.5",
											children: r.subtitle
										}, void 0, false, {
											fileName: _jsxFileName$8,
											lineNumber: 162,
											columnNumber: 17
										}, this)
									]
								}, r.id, true, {
									fileName: _jsxFileName$8,
									lineNumber: 148,
									columnNumber: 15
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName$8,
								lineNumber: 146,
								columnNumber: 11
							}, this),
							inProgress && /* @__PURE__ */ (void 0)("div", {
								className: "mt-6 flex items-center justify-between gap-3 rounded-xl border border-violet/30 bg-lilac/25 p-3.5 text-sm",
								children: [/* @__PURE__ */ (void 0)("div", {
									className: "flex items-center gap-2 text-stone-800 font-medium",
									children: [/* @__PURE__ */ (void 0)("span", { className: "flex h-2 w-2 rounded-full bg-violet animate-pulse" }, void 0, false, {
										fileName: _jsxFileName$8,
										lineNumber: 171,
										columnNumber: 17
									}, this), /* @__PURE__ */ (void 0)("span", { children: [
										"You have an unfinished quest session (",
										Object.keys(inProgress.coreAnswers || {}).length,
										"/15 answered)"
									] }, void 0, true, {
										fileName: _jsxFileName$8,
										lineNumber: 172,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName$8,
									lineNumber: 170,
									columnNumber: 15
								}, this), onResume && /* @__PURE__ */ (void 0)("button", {
									onClick: onResume,
									className: "rounded-lg bg-ink px-3 py-1.5 text-xs font-semibold text-white hover:bg-black transition-colors",
									children: "Resume Quest"
								}, void 0, false, {
									fileName: _jsxFileName$8,
									lineNumber: 178,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName$8,
								lineNumber: 169,
								columnNumber: 13
							}, this),
							existingDNA && !inProgress && /* @__PURE__ */ (void 0)("div", {
								className: "mt-6 flex flex-wrap items-center justify-between gap-3 rounded-xl border border-emerald-200 bg-emerald-50/70 p-3.5 text-sm",
								children: [/* @__PURE__ */ (void 0)("div", {
									className: "flex items-center gap-2 text-emerald-900",
									children: [/* @__PURE__ */ (void 0)(CircleCheck, { className: "h-4 w-4 text-emerald-600 shrink-0" }, void 0, false, {
										fileName: _jsxFileName$8,
										lineNumber: 191,
										columnNumber: 17
									}, this), /* @__PURE__ */ (void 0)("div", { children: [
										/* @__PURE__ */ (void 0)("span", {
											className: "font-bold",
											children: "Career DNA active:"
										}, void 0, false, {
											fileName: _jsxFileName$8,
											lineNumber: 193,
											columnNumber: 19
										}, this),
										" ",
										existingDNA.archetype.title,
										" (v",
										existingDNA.version,
										")"
									] }, void 0, true, {
										fileName: _jsxFileName$8,
										lineNumber: 192,
										columnNumber: 17
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName$8,
									lineNumber: 190,
									columnNumber: 15
								}, this), /* @__PURE__ */ (void 0)("div", {
									className: "flex items-center gap-2",
									children: [onViewDNA && /* @__PURE__ */ (void 0)("button", {
										onClick: onViewDNA,
										className: "rounded-lg bg-emerald-700 px-3 py-1.5 text-xs font-semibold text-white hover:bg-emerald-800 transition-colors",
										children: "View Report"
									}, void 0, false, {
										fileName: _jsxFileName$8,
										lineNumber: 199,
										columnNumber: 19
									}, this), historyCount > 1 && onOpenEvolution && /* @__PURE__ */ (void 0)("button", {
										onClick: onOpenEvolution,
										className: "flex items-center gap-1 rounded-lg border border-emerald-300 bg-white px-2.5 py-1.5 text-xs font-semibold text-emerald-800 hover:bg-emerald-50",
										children: [
											/* @__PURE__ */ (void 0)(History, { className: "h-3.5 w-3.5" }, void 0, false, {
												fileName: _jsxFileName$8,
												lineNumber: 211,
												columnNumber: 21
											}, this),
											"Evolution (",
											historyCount,
											")"
										]
									}, void 0, true, {
										fileName: _jsxFileName$8,
										lineNumber: 207,
										columnNumber: 19
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName$8,
									lineNumber: 197,
									columnNumber: 15
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName$8,
								lineNumber: 189,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "mt-8 flex flex-col sm:flex-row items-center gap-3 pt-4 border-t border-stone-200/80",
								children: [
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
										onClick: onStart,
										className: "group relative w-full sm:w-auto inline-flex items-center justify-center gap-2.5 rounded-xl bg-ink px-7 py-3.5 text-base font-bold text-white shadow-lg shadow-black/10 hover:bg-black hover:scale-[1.01] active:scale-[0.99] transition-all",
										children: [
											/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Compass, { className: "h-5 w-5 text-sun group-hover:rotate-45 transition-transform" }, void 0, false, {
												fileName: _jsxFileName$8,
												lineNumber: 225,
												columnNumber: 15
											}, this),
											/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: existingDNA ? "Retake Career Quest" : "Start Career Quest" }, void 0, false, {
												fileName: _jsxFileName$8,
												lineNumber: 226,
												columnNumber: 15
											}, this),
											/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(ArrowRight, { className: "h-4 w-4 group-hover:translate-x-1 transition-transform" }, void 0, false, {
												fileName: _jsxFileName$8,
												lineNumber: 227,
												columnNumber: 15
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName$8,
										lineNumber: 221,
										columnNumber: 13
									}, this),
									existingDNA && onViewDNA && /* @__PURE__ */ (void 0)("button", {
										onClick: onViewDNA,
										className: "w-full sm:w-auto inline-flex items-center justify-center gap-2 rounded-xl border border-stone-300 bg-white px-5 py-3.5 text-sm font-semibold text-stone-700 hover:bg-stone-50 transition-colors shadow-sm",
										children: [/* @__PURE__ */ (void 0)(Layers, { className: "h-4 w-4 text-violet" }, void 0, false, {
											fileName: _jsxFileName$8,
											lineNumber: 235,
											columnNumber: 17
										}, this), "View My Career DNA"]
									}, void 0, true, {
										fileName: _jsxFileName$8,
										lineNumber: 231,
										columnNumber: 15
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "sm:ml-auto flex items-center gap-1.5 text-xs text-stone-500 font-medium",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(ShieldCheck, { className: "h-4 w-4 text-emerald-600" }, void 0, false, {
											fileName: _jsxFileName$8,
											lineNumber: 241,
											columnNumber: 15
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: "No account required • Auto-saved locally" }, void 0, false, {
											fileName: _jsxFileName$8,
											lineNumber: 242,
											columnNumber: 15
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName$8,
										lineNumber: 240,
										columnNumber: 13
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName$8,
								lineNumber: 220,
								columnNumber: 11
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName$8,
						lineNumber: 78,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName$8,
				lineNumber: 70,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "relative z-10 mx-auto mt-8 max-w-xl text-center text-xs text-stone-500 font-mono",
				children: "“You don’t discover what you love by thinking about it. You discover it by noticing what energizes you.”"
			}, void 0, false, {
				fileName: _jsxFileName$8,
				lineNumber: 249,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName$8,
		lineNumber: 37,
		columnNumber: 5
	}, this);
}
var _jsxFileName$7 = "/app/applet/src/components/career-quest/QuestContextStep.tsx";
var STAGE_ICONS = {
	"School student — Classes 8–9": School,
	"Class 10": BookOpen,
	"Class 11–12": BookOpen,
	"Undergraduate student": GraduationCap,
	"Postgraduate student": GraduationCap,
	"Graduate / Fresh graduate": Sparkles,
	"Working professional": Briefcase,
	"Exploring a career change": Shuffle,
	"Other / Still figuring it out": CircleQuestionMark
};
var STAGE_SUBTITLES = {
	"School student — Classes 8–9": "Early exploration of passions and curiosity",
	"Class 10": "Crucial stream selection and subject orientation",
	"Class 11–12": "Targeting competitive exams, colleges, and core tracks",
	"Undergraduate student": "Building marketable skills, internships, and domains",
	"Postgraduate student": "Specialization, research, or executive transition",
	"Graduate / Fresh graduate": "Transitioning from campus to early career launch",
	"Working professional": "Skill acceleration, leveling up, and leadership",
	"Exploring a career change": "Pivoting to a new industry or discovering fresh alignment",
	"Other / Still figuring it out": "Open canvas exploration with zero predefined boxes"
};
function QuestContextStep({ initialContext, onContinue, onBack }) {
	const [selectedStage, setSelectedStage] = (0, import_react.useState)(initialContext?.stage || "Undergraduate student");
	const [fieldOrSubject, setFieldOrSubject] = (0, import_react.useState)(initialContext?.fieldOrSubject || "");
	const [interests, setInterests] = (0, import_react.useState)(initialContext?.interests || "");
	const handleNext = () => {
		onContinue({
			stage: selectedStage,
			fieldOrSubject: fieldOrSubject.trim() || void 0,
			interests: interests.trim() || void 0
		});
	};
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
		className: "relative mx-auto max-w-3xl overflow-hidden rounded-3xl bg-white border border-stone-200/90 p-5 sm:p-10 shadow-xl font-sans",
		children: [
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "flex items-center justify-between border-b border-stone-200/80 pb-4",
				children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
					onClick: onBack,
					className: "inline-flex items-center gap-1.5 text-xs font-semibold text-stone-500 hover:text-stone-900 transition-colors",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(ArrowLeft, { className: "h-4 w-4" }, void 0, false, {
						fileName: _jsxFileName$7,
						lineNumber: 71,
						columnNumber: 11
					}, this), "Back to Dossier"]
				}, void 0, true, {
					fileName: _jsxFileName$7,
					lineNumber: 67,
					columnNumber: 9
				}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "text-xs font-mono tracking-widest text-stone-400 uppercase",
					children: "STEP 01 OF 02 // CONTEXT"
				}, void 0, false, {
					fileName: _jsxFileName$7,
					lineNumber: 74,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName$7,
				lineNumber: 66,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "mt-6 text-center sm:text-left",
				children: [
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "inline-flex items-center gap-1.5 rounded-full bg-violet/10 px-3 py-1 text-xs font-semibold text-violet",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Compass, { className: "h-3.5 w-3.5" }, void 0, false, {
							fileName: _jsxFileName$7,
							lineNumber: 81,
							columnNumber: 11
						}, this), "Personalizing Your Quest"]
					}, void 0, true, {
						fileName: _jsxFileName$7,
						lineNumber: 80,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h2", {
						className: "mt-3 text-2xl sm:text-3xl font-extrabold text-stone-900 tracking-tight",
						children: "Where are you in your journey right now?"
					}, void 0, false, {
						fileName: _jsxFileName$7,
						lineNumber: 84,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
						className: "mt-1.5 text-sm sm:text-base text-stone-600",
						children: "Career Quest personalizes question framing, follow-ups, and career recommendations to meet you exactly where you stand."
					}, void 0, false, {
						fileName: _jsxFileName$7,
						lineNumber: 87,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName$7,
				lineNumber: 79,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "mt-6 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3",
				children: QUEST_STAGES.map((stg) => {
					const Icon = STAGE_ICONS[stg] || Compass;
					const isSelected = selectedStage === stg;
					return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
						type: "button",
						onClick: () => setSelectedStage(stg),
						className: `group relative flex flex-col justify-between rounded-xl border p-4 text-left transition-all ${isSelected ? "border-violet bg-lilac/30 shadow-md ring-2 ring-violet/20" : "border-stone-200/90 bg-stone-50/50 hover:bg-stone-100/70 hover:border-stone-300"}`,
						children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "flex items-center justify-between",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: `grid h-8 w-8 place-items-center rounded-lg transition-colors ${isSelected ? "bg-violet text-white" : "bg-stone-200/70 text-stone-700"}`,
									children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Icon, { className: "h-4 w-4" }, void 0, false, {
										fileName: _jsxFileName$7,
										lineNumber: 116,
										columnNumber: 21
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName$7,
									lineNumber: 111,
									columnNumber: 19
								}, this), isSelected && /* @__PURE__ */ (void 0)("div", {
									className: "grid h-5 w-5 place-items-center rounded-full bg-violet text-white",
									children: /* @__PURE__ */ (void 0)(Check, { className: "h-3 w-3 stroke-[3]" }, void 0, false, {
										fileName: _jsxFileName$7,
										lineNumber: 120,
										columnNumber: 23
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName$7,
									lineNumber: 119,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName$7,
								lineNumber: 110,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "mt-3 font-bold text-stone-900 text-sm leading-snug",
								children: stg
							}, void 0, false, {
								fileName: _jsxFileName$7,
								lineNumber: 124,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "mt-1 text-xs text-stone-500 line-clamp-2",
								children: STAGE_SUBTITLES[stg]
							}, void 0, false, {
								fileName: _jsxFileName$7,
								lineNumber: 125,
								columnNumber: 17
							}, this)
						] }, void 0, true, {
							fileName: _jsxFileName$7,
							lineNumber: 109,
							columnNumber: 15
						}, this)
					}, stg, false, {
						fileName: _jsxFileName$7,
						lineNumber: 99,
						columnNumber: 13
					}, this);
				})
			}, void 0, false, {
				fileName: _jsxFileName$7,
				lineNumber: 94,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "mt-6 rounded-2xl border border-stone-200 bg-stone-50/80 p-4 sm:p-5 space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "text-xs font-mono uppercase tracking-wider text-stone-500 font-bold",
					children: "Optional Details (Enhances AI accuracy)"
				}, void 0, false, {
					fileName: _jsxFileName$7,
					lineNumber: 136,
					columnNumber: 9
				}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("label", {
						className: "block text-xs font-bold text-stone-700 mb-1",
						children: "Current stream or field (e.g. Science PCM, Commerce, CS, Design, Humanities):"
					}, void 0, false, {
						fileName: _jsxFileName$7,
						lineNumber: 141,
						columnNumber: 13
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("input", {
						type: "text",
						value: fieldOrSubject,
						onChange: (e) => setFieldOrSubject(e.target.value),
						placeholder: "e.g. Computer Science, Grade 10, Biology...",
						className: "w-full rounded-xl border border-stone-300 bg-white px-3 py-2 text-sm text-stone-900 placeholder:text-stone-400 focus:border-violet focus:outline-none focus:ring-1 focus:ring-violet"
					}, void 0, false, {
						fileName: _jsxFileName$7,
						lineNumber: 144,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName$7,
						lineNumber: 140,
						columnNumber: 11
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("label", {
						className: "block text-xs font-bold text-stone-700 mb-1",
						children: "Topics or curiosities currently pulling your attention:"
					}, void 0, false, {
						fileName: _jsxFileName$7,
						lineNumber: 153,
						columnNumber: 13
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("input", {
						type: "text",
						value: interests,
						onChange: (e) => setInterests(e.target.value),
						placeholder: "e.g. AI tools, psychology, game design, climate...",
						className: "w-full rounded-xl border border-stone-300 bg-white px-3 py-2 text-sm text-stone-900 placeholder:text-stone-400 focus:border-violet focus:outline-none focus:ring-1 focus:ring-violet"
					}, void 0, false, {
						fileName: _jsxFileName$7,
						lineNumber: 156,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName$7,
						lineNumber: 152,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName$7,
					lineNumber: 139,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName$7,
				lineNumber: 135,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "mt-8 flex items-center justify-between pt-4 border-t border-stone-200/80",
				children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
					type: "button",
					onClick: onBack,
					className: "rounded-xl px-4 py-2.5 text-sm font-semibold text-stone-600 hover:text-stone-900 transition-colors",
					children: "Cancel"
				}, void 0, false, {
					fileName: _jsxFileName$7,
					lineNumber: 169,
					columnNumber: 9
				}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
					type: "button",
					onClick: handleNext,
					className: "inline-flex items-center gap-2 rounded-xl bg-ink px-6 py-3 text-sm font-bold text-white shadow-md hover:bg-black transition-all",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: "Continue to Briefing" }, void 0, false, {
						fileName: _jsxFileName$7,
						lineNumber: 182,
						columnNumber: 11
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(ArrowRight, { className: "h-4 w-4" }, void 0, false, {
						fileName: _jsxFileName$7,
						lineNumber: 183,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName$7,
					lineNumber: 177,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName$7,
				lineNumber: 168,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName$7,
		lineNumber: 64,
		columnNumber: 5
	}, this);
}
var _jsxFileName$6 = "/app/applet/src/components/career-quest/QuestIntroStep.tsx";
function QuestIntroStep({ context, onBegin, onBack }) {
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
		className: "relative mx-auto max-w-3xl overflow-hidden rounded-3xl bg-white border border-stone-200/90 p-5 sm:p-10 shadow-xl font-sans",
		children: [
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "flex items-center justify-between border-b border-stone-200/80 pb-4",
				children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
					onClick: onBack,
					className: "inline-flex items-center gap-1.5 text-xs font-semibold text-stone-500 hover:text-stone-900 transition-colors",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(ArrowLeft, { className: "h-4 w-4" }, void 0, false, {
						fileName: _jsxFileName$6,
						lineNumber: 28,
						columnNumber: 11
					}, this), "Edit Stage"]
				}, void 0, true, {
					fileName: _jsxFileName$6,
					lineNumber: 24,
					columnNumber: 9
				}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
						className: "rounded-full bg-violet/10 px-2.5 py-0.5 text-xs font-semibold text-violet",
						children: context.stage
					}, void 0, false, {
						fileName: _jsxFileName$6,
						lineNumber: 32,
						columnNumber: 11
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
						className: "text-xs font-mono text-stone-400",
						children: "QUEST DOSSIER"
					}, void 0, false, {
						fileName: _jsxFileName$6,
						lineNumber: 35,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName$6,
					lineNumber: 31,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName$6,
				lineNumber: 23,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "mt-6 text-center sm:text-left",
				children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h2", {
					className: "text-2xl sm:text-3xl font-extrabold text-stone-900 tracking-tight",
					children: "How Career Quest Works"
				}, void 0, false, {
					fileName: _jsxFileName$6,
					lineNumber: 40,
					columnNumber: 9
				}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
					className: "mt-1.5 text-sm sm:text-base text-stone-600",
					children: "This is not an exam, a personality box, or a standard aptitude quiz. It is an iterative discovery engine designed to surface how your mind operates when free from expectations."
				}, void 0, false, {
					fileName: _jsxFileName$6,
					lineNumber: 43,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName$6,
				lineNumber: 39,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "mt-6 grid grid-cols-1 sm:grid-cols-3 gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "rounded-2xl border border-stone-200 bg-stone-50/70 p-4",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "flex items-center gap-2 text-stone-900 font-bold text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Clock, { className: "h-4 w-4 text-orange" }, void 0, false, {
								fileName: _jsxFileName$6,
								lineNumber: 53,
								columnNumber: 13
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: "5 to 7 Minutes" }, void 0, false, {
								fileName: _jsxFileName$6,
								lineNumber: 54,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName$6,
							lineNumber: 52,
							columnNumber: 11
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
							className: "mt-1 text-xs text-stone-500",
							children: "15 core scenario questions plus 3 adaptive follow-ups tailored by Gemini."
						}, void 0, false, {
							fileName: _jsxFileName$6,
							lineNumber: 56,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName$6,
						lineNumber: 51,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "rounded-2xl border border-stone-200 bg-stone-50/70 p-4",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "flex items-center gap-2 text-stone-900 font-bold text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(ShieldCheck, { className: "h-4 w-4 text-emerald-600" }, void 0, false, {
								fileName: _jsxFileName$6,
								lineNumber: 63,
								columnNumber: 13
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: "Zero Judgments" }, void 0, false, {
								fileName: _jsxFileName$6,
								lineNumber: 64,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName$6,
							lineNumber: 62,
							columnNumber: 11
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
							className: "mt-1 text-xs text-stone-500",
							children: "No right or wrong answers. Contradictions are welcomed and explored."
						}, void 0, false, {
							fileName: _jsxFileName$6,
							lineNumber: 66,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName$6,
						lineNumber: 61,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "rounded-2xl border border-stone-200 bg-stone-50/70 p-4",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "flex items-center gap-2 text-stone-900 font-bold text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Sparkles, { className: "h-4 w-4 text-violet" }, void 0, false, {
								fileName: _jsxFileName$6,
								lineNumber: 73,
								columnNumber: 13
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: "Rich Career DNA" }, void 0, false, {
								fileName: _jsxFileName$6,
								lineNumber: 74,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName$6,
							lineNumber: 72,
							columnNumber: 11
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
							className: "mt-1 text-xs text-stone-500",
							children: "Generates your Archetype, 10 Strengths, Top 5 Matches & Starter Projects."
						}, void 0, false, {
							fileName: _jsxFileName$6,
							lineNumber: 76,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName$6,
						lineNumber: 71,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName$6,
				lineNumber: 50,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "mt-8",
				children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "text-xs font-mono uppercase tracking-widest text-stone-500 font-bold mb-3",
					children: "The 5 Discovery Rounds"
				}, void 0, false, {
					fileName: _jsxFileName$6,
					lineNumber: 84,
					columnNumber: 9
				}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "space-y-2.5",
					children: QUEST_ROUNDS.map((round) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "flex items-start gap-3.5 rounded-2xl border border-stone-200 bg-white p-3.5 sm:p-4 hover:border-stone-300 transition-colors",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: `grid h-8 w-8 shrink-0 place-items-center rounded-xl font-mono text-xs font-bold ${round.accentBg} ${round.accentText} border ${round.accentBorder}`,
							children: ["0", round.number]
						}, void 0, true, {
							fileName: _jsxFileName$6,
							lineNumber: 94,
							columnNumber: 15
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "min-w-0 flex-1",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
									className: "font-bold text-stone-900 text-sm",
									children: round.title
								}, void 0, false, {
									fileName: _jsxFileName$6,
									lineNumber: 101,
									columnNumber: 19
								}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
									className: "text-[10px] font-mono text-stone-400",
									children: "3 Questions"
								}, void 0, false, {
									fileName: _jsxFileName$6,
									lineNumber: 102,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName$6,
								lineNumber: 100,
								columnNumber: 17
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
								className: "text-xs text-stone-600 mt-0.5 leading-relaxed",
								children: round.subtitle
							}, void 0, false, {
								fileName: _jsxFileName$6,
								lineNumber: 104,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName$6,
							lineNumber: 99,
							columnNumber: 15
						}, this)]
					}, round.id, true, {
						fileName: _jsxFileName$6,
						lineNumber: 90,
						columnNumber: 13
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName$6,
					lineNumber: 88,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName$6,
				lineNumber: 83,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "mt-6 rounded-2xl bg-amber-50/80 border border-amber-200/80 p-3.5 text-xs text-amber-900 flex items-start gap-2.5",
				children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Brain, { className: "h-4 w-4 text-amber-700 shrink-0 mt-0.5" }, void 0, false, {
					fileName: _jsxFileName$6,
					lineNumber: 113,
					columnNumber: 9
				}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("strong", { children: "Pro-tip:" }, void 0, false, {
					fileName: _jsxFileName$6,
					lineNumber: 115,
					columnNumber: 11
				}, this), " Go with your initial, uncensored gut instinct. Don't pick what sounds prestigious or expected by others — pick what genuinely pulls you."] }, void 0, true, {
					fileName: _jsxFileName$6,
					lineNumber: 114,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName$6,
				lineNumber: 112,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "mt-8 flex items-center justify-between pt-4 border-t border-stone-200/80",
				children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
					type: "button",
					onClick: onBack,
					className: "rounded-xl px-4 py-2.5 text-sm font-semibold text-stone-600 hover:text-stone-900 transition-colors",
					children: "Back"
				}, void 0, false, {
					fileName: _jsxFileName$6,
					lineNumber: 122,
					columnNumber: 9
				}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
					type: "button",
					onClick: onBegin,
					className: "inline-flex items-center gap-2 rounded-xl bg-ink px-6 py-3 text-sm font-bold text-white shadow-lg shadow-black/10 hover:bg-black transition-all hover:scale-[1.01]",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: "Begin Round 1: The Thinker" }, void 0, false, {
						fileName: _jsxFileName$6,
						lineNumber: 135,
						columnNumber: 11
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(ArrowRight, { className: "h-4 w-4" }, void 0, false, {
						fileName: _jsxFileName$6,
						lineNumber: 136,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName$6,
					lineNumber: 130,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName$6,
				lineNumber: 121,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName$6,
		lineNumber: 21,
		columnNumber: 5
	}, this);
}
var _jsxFileName$5 = "/app/applet/src/components/career-quest/QuestQuestionCard.tsx";
function QuestQuestionCard({ question, currentAnswer, onSelectOption, onNext, onPrev, onSaveAndExit, canGoBack, totalQuestions, currentQuestionNumber }) {
	const round = QUEST_ROUNDS.find((r) => r.number === question.roundId) ?? QUEST_ROUNDS[0];
	const isMulti = !!question.allowMultiple;
	const selectedList = Array.isArray(currentAnswer) ? currentAnswer : currentAnswer ? [currentAnswer] : [];
	const hasSelection = selectedList.length > 0;
	const progressPercent = Math.round(currentQuestionNumber / totalQuestions * 100);
	const renderHighlightedHeadline = () => {
		const text = question.question;
		const highlightWords = question.highlightWords || [];
		if (!highlightWords.length) return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: text }, void 0, false, {
			fileName: _jsxFileName$5,
			lineNumber: 47,
			columnNumber: 14
		}, this);
		const primaryPhrase = highlightWords[0];
		const parts = text.split(primaryPhrase);
		if (parts.length === 2) return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: [
			parts[0],
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
				className: "relative inline-block mx-1 my-0.5",
				children: [
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
						className: "relative z-10 px-2 py-0.5 text-stone-900 font-extrabold",
						children: primaryPhrase
					}, void 0, false, {
						fileName: _jsxFileName$5,
						lineNumber: 60,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { className: `absolute inset-0 rounded-sm opacity-80 ${question.roundId === 1 ? "bg-lilac/60 border border-violet/40" : question.roundId === 2 ? "bg-mint/60 border border-success/40" : question.roundId === 3 ? "bg-butter border border-sun/50" : question.roundId === 4 ? "bg-blush/70 border border-orange/40" : "bg-sun/60 border border-sun"}` }, void 0, false, {
						fileName: _jsxFileName$5,
						lineNumber: 63,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { className: "absolute -top-1 -left-1 w-1.5 h-1.5 bg-stone-800 rounded-full" }, void 0, false, {
						fileName: _jsxFileName$5,
						lineNumber: 77,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { className: "absolute -top-1 -right-1 w-1.5 h-1.5 bg-stone-800 rounded-full" }, void 0, false, {
						fileName: _jsxFileName$5,
						lineNumber: 78,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { className: "absolute -bottom-1 -left-1 w-1.5 h-1.5 bg-stone-800 rounded-full" }, void 0, false, {
						fileName: _jsxFileName$5,
						lineNumber: 79,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { className: "absolute -bottom-1 -right-1 w-1.5 h-1.5 bg-stone-800 rounded-full" }, void 0, false, {
						fileName: _jsxFileName$5,
						lineNumber: 80,
						columnNumber: 13
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName$5,
				lineNumber: 58,
				columnNumber: 11
			}, this),
			parts[1]
		] }, void 0, true, {
			fileName: _jsxFileName$5,
			lineNumber: 56,
			columnNumber: 9
		}, this);
		return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: text }, void 0, false, {
			fileName: _jsxFileName$5,
			lineNumber: 87,
			columnNumber: 12
		}, this);
	};
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
		className: "relative mx-auto max-w-2xl overflow-hidden rounded-3xl bg-white border border-stone-200/90 shadow-2xl font-sans",
		children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
			className: "w-full bg-stone-100 h-1.5",
			children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "h-full bg-ink transition-all duration-300 ease-out",
				style: { width: `${progressPercent}%` }
			}, void 0, false, {
				fileName: _jsxFileName$5,
				lineNumber: 94,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName$5,
			lineNumber: 93,
			columnNumber: 7
		}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
			className: "relative p-6 sm:p-10 md:p-12",
			style: {
				backgroundImage: "radial-gradient(#d1d5db 1.2px, transparent 1.2px)",
				backgroundSize: "20px 20px"
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "flex items-center justify-between text-xs text-stone-500 font-mono mb-4",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
						className: "tracking-widest uppercase",
						children: "@pathfinder.quest"
					}, void 0, false, {
						fileName: _jsxFileName$5,
						lineNumber: 110,
						columnNumber: 11
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
						className: "font-semibold text-stone-700",
						children: [
							"Round ",
							question.roundId,
							" of 5: ",
							round.title
						]
					}, void 0, true, {
						fileName: _jsxFileName$5,
						lineNumber: 111,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName$5,
					lineNumber: 109,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "flex justify-center my-3",
					children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "grid h-16 w-16 place-items-center rounded-full border-2 border-stone-800 bg-white font-extrabold text-stone-900 text-xl tracking-tight shadow-sm",
						children: question.questionNumber < 10 ? `0${question.questionNumber}` : question.questionNumber
					}, void 0, false, {
						fileName: _jsxFileName$5,
						lineNumber: 118,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName$5,
					lineNumber: 117,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "text-center mt-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h2", {
							className: "text-2xl sm:text-3xl md:text-4xl font-extrabold tracking-tight text-stone-900 leading-tight",
							children: renderHighlightedHeadline()
						}, void 0, false, {
							fileName: _jsxFileName$5,
							lineNumber: 125,
							columnNumber: 11
						}, this),
						question.subtext && /* @__PURE__ */ (void 0)("p", {
							className: "mt-3 text-sm sm:text-base text-stone-600 font-normal max-w-lg mx-auto",
							children: question.subtext
						}, void 0, false, {
							fileName: _jsxFileName$5,
							lineNumber: 131,
							columnNumber: 13
						}, this),
						question.promptNote && /* @__PURE__ */ (void 0)("div", {
							className: "mt-2 inline-flex items-center gap-1 text-xs sm:text-sm font-semibold text-orange tracking-wide",
							children: question.promptNote
						}, void 0, false, {
							fileName: _jsxFileName$5,
							lineNumber: 137,
							columnNumber: 13
						}, this),
						isMulti && /* @__PURE__ */ (void 0)("div", {
							className: "mt-2 text-xs font-mono font-bold text-violet uppercase tracking-wider",
							children: "✦ Multi-Select: Choose any and all options that appeal to you"
						}, void 0, false, {
							fileName: _jsxFileName$5,
							lineNumber: 143,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName$5,
					lineNumber: 124,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "mt-8 space-y-3",
					children: question.options.map((opt) => {
						const isSelected = selectedList.includes(opt.id);
						return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
							type: "button",
							onClick: () => onSelectOption(opt.id),
							className: `group relative flex w-full items-start gap-3.5 rounded-2xl border p-4 text-left transition-all ${isSelected ? "border-stone-900 bg-stone-900 text-white shadow-md scale-[1.01]" : "border-stone-200/90 bg-white/95 hover:bg-stone-50 hover:border-stone-400 text-stone-900 shadow-sm"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: `grid h-7 w-7 shrink-0 place-items-center rounded-xl font-mono text-xs font-bold transition-colors ${isSelected ? "bg-white text-stone-900" : "bg-stone-100 text-stone-700 group-hover:bg-stone-200"}`,
									children: opt.id
								}, void 0, false, {
									fileName: _jsxFileName$5,
									lineNumber: 165,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: "min-w-0 flex-1 pt-0.5",
									children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: `text-sm sm:text-base font-medium leading-relaxed ${isSelected ? "text-white" : "text-stone-900"}`,
										children: opt.label
									}, void 0, false, {
										fileName: _jsxFileName$5,
										lineNumber: 176,
										columnNumber: 19
									}, this), opt.tagline && /* @__PURE__ */ (void 0)("div", {
										className: `text-xs mt-1 ${isSelected ? "text-stone-300" : "text-stone-500"}`,
										children: opt.tagline
									}, void 0, false, {
										fileName: _jsxFileName$5,
										lineNumber: 182,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName$5,
									lineNumber: 175,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: `grid h-5 w-5 shrink-0 place-items-center rounded-md border transition-colors mt-0.5 ${isSelected ? "border-white bg-white text-stone-900" : "border-stone-300 bg-transparent group-hover:border-stone-400"}`,
									children: isSelected && /* @__PURE__ */ (void 0)(Check, { className: "h-3.5 w-3.5 stroke-[3]" }, void 0, false, {
										fileName: _jsxFileName$5,
										lineNumber: 198,
										columnNumber: 34
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName$5,
									lineNumber: 191,
									columnNumber: 17
								}, this)
							]
						}, opt.id, true, {
							fileName: _jsxFileName$5,
							lineNumber: 154,
							columnNumber: 15
						}, this);
					})
				}, void 0, false, {
					fileName: _jsxFileName$5,
					lineNumber: 150,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "mt-8 flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-stone-200/80",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "flex items-center gap-2",
						children: [canGoBack && /* @__PURE__ */ (void 0)("button", {
							type: "button",
							onClick: onPrev,
							className: "inline-flex items-center gap-1.5 rounded-xl border border-stone-300 bg-white px-3.5 py-2 text-xs font-semibold text-stone-700 hover:bg-stone-50 transition-colors",
							children: [/* @__PURE__ */ (void 0)(ArrowLeft, { className: "h-3.5 w-3.5" }, void 0, false, {
								fileName: _jsxFileName$5,
								lineNumber: 214,
								columnNumber: 17
							}, this), "Previous"]
						}, void 0, true, {
							fileName: _jsxFileName$5,
							lineNumber: 209,
							columnNumber: 15
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
							type: "button",
							onClick: onSaveAndExit,
							className: "inline-flex items-center gap-1 text-xs text-stone-500 hover:text-stone-800 transition-colors px-2 py-1",
							title: "Save current progress and return to dashboard",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Save, { className: "h-3.5 w-3.5" }, void 0, false, {
								fileName: _jsxFileName$5,
								lineNumber: 225,
								columnNumber: 15
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: "Save & Exit" }, void 0, false, {
								fileName: _jsxFileName$5,
								lineNumber: 226,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName$5,
							lineNumber: 219,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName$5,
						lineNumber: 207,
						columnNumber: 11
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "flex items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
							className: "text-xs text-stone-400 font-mono",
							children: [
								currentQuestionNumber,
								" / ",
								totalQuestions
							]
						}, void 0, true, {
							fileName: _jsxFileName$5,
							lineNumber: 231,
							columnNumber: 13
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
							type: "button",
							onClick: onNext,
							disabled: !hasSelection,
							className: `inline-flex items-center gap-2 rounded-xl px-6 py-2.5 text-sm font-bold transition-all shadow-md ${hasSelection ? "bg-ink text-white hover:bg-black hover:scale-[1.02] cursor-pointer" : "bg-stone-200 text-stone-400 cursor-not-allowed shadow-none"}`,
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: currentQuestionNumber === totalQuestions ? "Review Signals" : "Continue" }, void 0, false, {
								fileName: _jsxFileName$5,
								lineNumber: 245,
								columnNumber: 15
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(ArrowRight, { className: "h-4 w-4" }, void 0, false, {
								fileName: _jsxFileName$5,
								lineNumber: 248,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName$5,
							lineNumber: 235,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName$5,
						lineNumber: 230,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName$5,
					lineNumber: 206,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName$5,
			lineNumber: 101,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName$5,
		lineNumber: 91,
		columnNumber: 5
	}, this);
}
var _jsxFileName$4 = "/app/applet/src/components/career-quest/QuestAdaptiveStep.tsx";
function QuestAdaptiveStep({ context, coreAnswers, cachedQuestions, cachedAnswers, onComplete, onBack }) {
	const [loading, setLoading] = (0, import_react.useState)(!cachedQuestions?.length);
	const [questions, setQuestions] = (0, import_react.useState)(cachedQuestions || FALLBACK_ADAPTIVE_QUESTIONS);
	const [answers, setAnswers] = (0, import_react.useState)(cachedAnswers || {});
	const [currentIndex, setCurrentIndex] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		if (cachedQuestions?.length) {
			setLoading(false);
			return;
		}
		let isMounted = true;
		async function fetchAdaptive() {
			try {
				setLoading(true);
				const res = await generateAdaptiveQuestionsServerFn({ data: {
					stage: context.stage,
					fieldOrSubject: context.fieldOrSubject,
					interests: context.interests,
					coreAnswers
				} });
				if (isMounted && res.questions?.length) setQuestions(res.questions);
			} catch (err) {
				console.warn("Using fallback adaptive questions:", err);
				if (isMounted) setQuestions(FALLBACK_ADAPTIVE_QUESTIONS);
			} finally {
				if (isMounted) setLoading(false);
			}
		}
		fetchAdaptive();
		return () => {
			isMounted = false;
		};
	}, [
		context,
		coreAnswers,
		cachedQuestions
	]);
	const currentQ = questions[currentIndex];
	const selectedOption = currentQ ? answers[currentQ.id] : void 0;
	const handleSelect = (optionId) => {
		if (!currentQ) return;
		setAnswers((prev) => ({
			...prev,
			[currentQ.id]: optionId
		}));
	};
	const handleNext = () => {
		if (currentIndex < questions.length - 1) setCurrentIndex((prev) => prev + 1);
		else onComplete(questions, answers);
	};
	const handlePrev = () => {
		if (currentIndex > 0) setCurrentIndex((prev) => prev - 1);
		else onBack();
	};
	if (loading) return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
		className: "relative mx-auto max-w-2xl overflow-hidden rounded-3xl bg-white border border-stone-200/90 p-8 sm:p-14 text-center shadow-xl font-sans",
		children: [
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-lilac/40 text-violet",
				children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Brain, { className: "h-8 w-8 animate-pulse" }, void 0, false, {
					fileName: _jsxFileName$4,
					lineNumber: 106,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName$4,
				lineNumber: 105,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h3", {
				className: "mt-6 text-2xl font-extrabold text-stone-900 tracking-tight",
				children: "Analyzing Your 15 Discovery Signals..."
			}, void 0, false, {
				fileName: _jsxFileName$4,
				lineNumber: 109,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
				className: "mt-2 text-sm text-stone-600 max-w-md mx-auto",
				children: "Gemini AI is examining your responses across The Thinker, Explorer, Decision Maker, Hidden Talent, and Future Self to identify specific crossroads."
			}, void 0, false, {
				fileName: _jsxFileName$4,
				lineNumber: 113,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "mt-8 flex items-center justify-center gap-2 text-xs font-mono text-stone-400",
				children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(LoaderCircle, { className: "h-4 w-4 animate-spin text-violet" }, void 0, false, {
					fileName: _jsxFileName$4,
					lineNumber: 119,
					columnNumber: 11
				}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: "Formulating 3 targeted adaptive questions..." }, void 0, false, {
					fileName: _jsxFileName$4,
					lineNumber: 120,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName$4,
				lineNumber: 118,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName$4,
		lineNumber: 104,
		columnNumber: 7
	}, this);
	if (!currentQ) return null;
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
		className: "relative mx-auto max-w-2xl overflow-hidden rounded-3xl bg-white border border-stone-200/90 shadow-2xl font-sans",
		children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
			className: "w-full bg-stone-100 h-1.5",
			children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "h-full bg-violet transition-all duration-300",
				style: { width: `${Math.round((currentIndex + 1) / questions.length * 100)}%` }
			}, void 0, false, {
				fileName: _jsxFileName$4,
				lineNumber: 134,
				columnNumber: 9
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName$4,
			lineNumber: 133,
			columnNumber: 7
		}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
			className: "relative p-6 sm:p-10 md:p-12",
			style: {
				backgroundImage: "radial-gradient(#d1d5db 1.2px, transparent 1.2px)",
				backgroundSize: "20px 20px"
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "flex items-center justify-between text-xs font-mono text-stone-500 mb-4",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "flex items-center gap-1.5 font-bold text-violet bg-lilac/30 border border-violet/30 px-2.5 py-0.5 rounded-full",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Sparkles, { className: "h-3.5 w-3.5" }, void 0, false, {
							fileName: _jsxFileName$4,
							lineNumber: 150,
							columnNumber: 13
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: [
							"AI ADAPTIVE SIGNAL ",
							currentIndex + 1,
							" OF ",
							questions.length
						] }, void 0, true, {
							fileName: _jsxFileName$4,
							lineNumber: 151,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName$4,
						lineNumber: 149,
						columnNumber: 11
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
						className: "text-stone-400 uppercase tracking-widest",
						children: "GEMINI CLARIFIER"
					}, void 0, false, {
						fileName: _jsxFileName$4,
						lineNumber: 155,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName$4,
					lineNumber: 148,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "mt-4 text-center sm:text-left",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h2", {
						className: "text-xl sm:text-2xl font-extrabold text-stone-900 leading-snug",
						children: currentQ.question
					}, void 0, false, {
						fileName: _jsxFileName$4,
						lineNumber: 160,
						columnNumber: 11
					}, this), currentQ.reason && /* @__PURE__ */ (void 0)("div", {
						className: "mt-3 inline-flex items-start gap-2 rounded-xl bg-stone-100/90 border border-stone-200 px-3.5 py-2 text-xs text-stone-700",
						children: [/* @__PURE__ */ (void 0)(CircleQuestionMark, { className: "h-4 w-4 text-stone-500 shrink-0 mt-0.5" }, void 0, false, {
							fileName: _jsxFileName$4,
							lineNumber: 167,
							columnNumber: 15
						}, this), /* @__PURE__ */ (void 0)("span", { children: [
							/* @__PURE__ */ (void 0)("strong", { children: "Why we ask this:" }, void 0, false, {
								fileName: _jsxFileName$4,
								lineNumber: 169,
								columnNumber: 17
							}, this),
							" ",
							currentQ.reason
						] }, void 0, true, {
							fileName: _jsxFileName$4,
							lineNumber: 168,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName$4,
						lineNumber: 166,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName$4,
					lineNumber: 159,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "mt-6 space-y-3",
					children: currentQ.options.map((opt) => {
						const isSelected = selectedOption === opt.id;
						return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
							type: "button",
							onClick: () => handleSelect(opt.id),
							className: `group flex w-full items-start gap-3.5 rounded-2xl border p-4 text-left transition-all ${isSelected ? "border-violet bg-violet text-white shadow-md scale-[1.01]" : "border-stone-200 bg-white/95 hover:bg-stone-50 hover:border-stone-400 text-stone-900 shadow-sm"}`,
							children: [
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: `grid h-7 w-7 shrink-0 place-items-center rounded-xl font-mono text-xs font-bold transition-colors ${isSelected ? "bg-white text-violet" : "bg-stone-100 text-stone-700 group-hover:bg-stone-200"}`,
									children: opt.id.toUpperCase()
								}, void 0, false, {
									fileName: _jsxFileName$4,
									lineNumber: 190,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: "flex-1 text-sm sm:text-base font-medium pt-0.5 leading-relaxed",
									children: opt.text
								}, void 0, false, {
									fileName: _jsxFileName$4,
									lineNumber: 200,
									columnNumber: 17
								}, this),
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: `grid h-5 w-5 shrink-0 place-items-center rounded-md border transition-colors mt-0.5 ${isSelected ? "border-white bg-white text-violet" : "border-stone-300 bg-transparent group-hover:border-stone-400"}`,
									children: isSelected && /* @__PURE__ */ (void 0)(Check, { className: "h-3.5 w-3.5 stroke-[3]" }, void 0, false, {
										fileName: _jsxFileName$4,
										lineNumber: 211,
										columnNumber: 34
									}, this)
								}, void 0, false, {
									fileName: _jsxFileName$4,
									lineNumber: 204,
									columnNumber: 17
								}, this)
							]
						}, opt.id, true, {
							fileName: _jsxFileName$4,
							lineNumber: 180,
							columnNumber: 15
						}, this);
					})
				}, void 0, false, {
					fileName: _jsxFileName$4,
					lineNumber: 176,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "mt-8 flex items-center justify-between pt-4 border-t border-stone-200/80",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
						type: "button",
						onClick: handlePrev,
						className: "inline-flex items-center gap-1.5 rounded-xl border border-stone-300 bg-white px-3.5 py-2 text-xs font-semibold text-stone-700 hover:bg-stone-50 transition-colors",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(ArrowLeft, { className: "h-3.5 w-3.5" }, void 0, false, {
							fileName: _jsxFileName$4,
							lineNumber: 225,
							columnNumber: 13
						}, this), "Previous"]
					}, void 0, true, {
						fileName: _jsxFileName$4,
						lineNumber: 220,
						columnNumber: 11
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
						type: "button",
						onClick: handleNext,
						disabled: !selectedOption,
						className: `inline-flex items-center gap-2 rounded-xl px-6 py-2.5 text-sm font-bold transition-all shadow-md ${selectedOption ? "bg-ink text-white hover:bg-black hover:scale-[1.02] cursor-pointer" : "bg-stone-200 text-stone-400 cursor-not-allowed shadow-none"}`,
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: currentIndex === questions.length - 1 ? "Synthesize Career DNA" : "Next Follow-up" }, void 0, false, {
							fileName: _jsxFileName$4,
							lineNumber: 239,
							columnNumber: 13
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(ArrowRight, { className: "h-4 w-4" }, void 0, false, {
							fileName: _jsxFileName$4,
							lineNumber: 242,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName$4,
						lineNumber: 229,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName$4,
					lineNumber: 219,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName$4,
			lineNumber: 140,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName$4,
		lineNumber: 131,
		columnNumber: 5
	}, this);
}
var _jsxFileName$3 = "/app/applet/src/components/career-quest/QuestSynthesizingStep.tsx";
var SYNTHESIS_STEPS = [
	"Auditing 15 Core Discovery Scenarios & Trade-offs",
	"Decoding Adaptive AI Signals & Working Style",
	"Calculating 8 Cognitive & Execution Dimensions",
	"Synthesizing Identity Archetype & 10 Strengths",
	"Benchmarking Top 5 Career Matches & Starter Projects"
];
function QuestSynthesizingStep({ context, coreAnswers, adaptiveAnswers, version, onSuccess, onErrorFallback }) {
	const [activeStepIndex, setActiveStepIndex] = (0, import_react.useState)(0);
	(0, import_react.useEffect)(() => {
		const timer = setInterval(() => {
			setActiveStepIndex((prev) => prev < SYNTHESIS_STEPS.length - 1 ? prev + 1 : prev);
		}, 1200);
		return () => clearInterval(timer);
	}, []);
	(0, import_react.useEffect)(() => {
		let isMounted = true;
		async function synthesize() {
			try {
				const res = await generateCareerDNAServerFn({ data: {
					context: {
						stage: context.stage,
						fieldOrSubject: context.fieldOrSubject,
						interests: context.interests,
						region: context.region
					},
					coreAnswers,
					adaptiveAnswers,
					version
				} });
				if (isMounted) if (res.ok && res.dna) onSuccess(res.dna);
				else onErrorFallback();
			} catch (err) {
				console.warn("Synthesis failed, falling back to local engine:", err);
				if (isMounted) onErrorFallback();
			}
		}
		synthesize();
		return () => {
			isMounted = false;
		};
	}, [
		context,
		coreAnswers,
		adaptiveAnswers,
		version,
		onSuccess,
		onErrorFallback
	]);
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
		className: "relative mx-auto max-w-xl overflow-hidden rounded-3xl bg-white border border-stone-200/90 p-8 sm:p-14 text-center shadow-2xl font-sans",
		children: [
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "relative mx-auto flex h-20 w-20 items-center justify-center rounded-3xl bg-gradient-to-tr from-violet via-lilac to-sun p-0.5 shadow-xl",
				children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "flex h-full w-full items-center justify-center rounded-[22px] bg-white",
					children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Brain, { className: "h-9 w-9 text-violet animate-pulse" }, void 0, false, {
						fileName: _jsxFileName$3,
						lineNumber: 87,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName$3,
					lineNumber: 86,
					columnNumber: 9
				}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Sparkles, {
					className: "absolute -top-2 -right-2 h-6 w-6 text-sun animate-spin",
					style: { animationDuration: "6s" }
				}, void 0, false, {
					fileName: _jsxFileName$3,
					lineNumber: 89,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName$3,
				lineNumber: 85,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h2", {
				className: "mt-6 text-2xl sm:text-3xl font-extrabold text-stone-900 tracking-tight",
				children: "Synthesizing Your Career DNA"
			}, void 0, false, {
				fileName: _jsxFileName$3,
				lineNumber: 95,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
				className: "mt-2 text-sm text-stone-600 max-w-md mx-auto",
				children: "Combining psychometric scenario weights with Google Gemini intelligence to formulate your tailored blueprint."
			}, void 0, false, {
				fileName: _jsxFileName$3,
				lineNumber: 99,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "mt-8 space-y-3 text-left",
				children: SYNTHESIS_STEPS.map((step, idx) => {
					const isDone = idx < activeStepIndex;
					const isCurrent = idx === activeStepIndex;
					return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: `flex items-center gap-3 rounded-xl p-3 border transition-all ${isCurrent ? "border-violet/40 bg-lilac/20 text-stone-900 font-semibold shadow-sm" : isDone ? "border-emerald-200 bg-emerald-50/50 text-stone-700" : "border-stone-100 bg-stone-50/50 text-stone-400 opacity-60"}`,
						children: [isDone ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(CircleCheck, { className: "h-5 w-5 text-emerald-600 shrink-0" }, void 0, false, {
							fileName: _jsxFileName$3,
							lineNumber: 122,
							columnNumber: 17
						}, this) : isCurrent ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(LoaderCircle, { className: "h-5 w-5 text-violet animate-spin shrink-0" }, void 0, false, {
							fileName: _jsxFileName$3,
							lineNumber: 124,
							columnNumber: 17
						}, this) : /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "h-5 w-5 rounded-full border border-stone-300 shrink-0" }, void 0, false, {
							fileName: _jsxFileName$3,
							lineNumber: 126,
							columnNumber: 17
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
							className: "text-xs sm:text-sm",
							children: step
						}, void 0, false, {
							fileName: _jsxFileName$3,
							lineNumber: 128,
							columnNumber: 15
						}, this)]
					}, step, true, {
						fileName: _jsxFileName$3,
						lineNumber: 111,
						columnNumber: 13
					}, this);
				})
			}, void 0, false, {
				fileName: _jsxFileName$3,
				lineNumber: 105,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "mt-8 text-xs font-mono text-stone-400",
				children: "Estimated completion: 2-4 seconds • Gemini Flash 2.5"
			}, void 0, false, {
				fileName: _jsxFileName$3,
				lineNumber: 134,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName$3,
		lineNumber: 83,
		columnNumber: 5
	}, this);
}
var _jsxFileName$2 = "/app/applet/src/components/career-quest/QuestDNAReport.tsx";
function QuestDNAReport({ dna, onRetake, onOpenEvolution, historyCount = 0 }) {
	const store = usePathfinder((s) => s);
	useNavigate();
	const [expandedMatchId, setExpandedMatchId] = (0, import_react.useState)(dna.careerMatches[0]?.id || "match-1");
	const [copied, setCopied] = (0, import_react.useState)(false);
	const [savedGoalToast, setSavedGoalToast] = (0, import_react.useState)(null);
	const toggleExpand = (id) => {
		setExpandedMatchId((prev) => prev === id ? "" : id);
	};
	const handleAdoptGoal = (match) => {
		actions.adoptCareerGoal(match.title);
		setSavedGoalToast(`Career target set to "${match.title}"! Profile & Roadmap updated.`);
		setTimeout(() => setSavedGoalToast(null), 4e3);
	};
	const handleCopySummary = () => {
		const text = `PATHFINDER CAREER DNA REPORT
Archetype: ${dna.archetype.title}
Tagline: ${dna.archetype.tagline}
Top Match: ${dna.careerMatches[0]?.title} (${dna.careerMatches[0]?.matchScore}% Match)
Stage: ${dna.context.stage}
Completed: ${dna.completedAt}`;
		if (typeof navigator !== "undefined" && navigator.clipboard) {
			navigator.clipboard.writeText(text);
			setCopied(true);
			setTimeout(() => setCopied(false), 2500);
		}
	};
	const handlePrint = () => {
		if (typeof window !== "undefined") window.print();
	};
	const dimensionsList = [
		{
			key: "analytical",
			label: "Analytical Rigor",
			value: dna.dimensions.analytical,
			color: "bg-blue-500"
		},
		{
			key: "creative",
			label: "Creative Intuition",
			value: dna.dimensions.creative,
			color: "bg-pink-500"
		},
		{
			key: "technical",
			label: "Technical Affinity",
			value: dna.dimensions.technical,
			color: "bg-violet"
		},
		{
			key: "leadership",
			label: "Leadership & Agency",
			value: dna.dimensions.leadership,
			color: "bg-amber-500"
		},
		{
			key: "empathy",
			label: "Human Empathy",
			value: dna.dimensions.empathy,
			color: "bg-emerald-500"
		},
		{
			key: "autonomy",
			label: "Autonomous Drive",
			value: dna.dimensions.autonomy,
			color: "bg-purple-600"
		},
		{
			key: "adaptability",
			label: "Adaptive Resilience",
			value: dna.dimensions.adaptability,
			color: "bg-teal-500"
		},
		{
			key: "socialImpact",
			label: "Mission & Impact",
			value: dna.dimensions.socialImpact,
			color: "bg-orange"
		}
	];
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
		className: "relative mx-auto max-w-4xl space-y-8 font-sans pb-16",
		children: [
			savedGoalToast && /* @__PURE__ */ (void 0)("div", {
				className: "fixed top-6 right-6 z-50 flex items-center gap-2.5 rounded-2xl bg-stone-900 px-5 py-3 text-sm font-semibold text-white shadow-2xl animate-in fade-in slide-in-from-top-4",
				children: [/* @__PURE__ */ (void 0)(CircleCheck, { className: "h-4 w-4 text-emerald-400" }, void 0, false, {
					fileName: _jsxFileName$2,
					lineNumber: 138,
					columnNumber: 11
				}, this), /* @__PURE__ */ (void 0)("span", { children: savedGoalToast }, void 0, false, {
					fileName: _jsxFileName$2,
					lineNumber: 139,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName$2,
				lineNumber: 137,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "flex flex-wrap items-center justify-between gap-4 rounded-3xl bg-white border border-stone-200/90 p-4 sm:p-6 shadow-sm",
				children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "grid h-10 w-10 place-items-center rounded-2xl bg-lilac/40 text-violet font-bold",
						children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Compass, { className: "h-5 w-5" }, void 0, false, {
							fileName: _jsxFileName$2,
							lineNumber: 147,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName$2,
						lineNumber: 146,
						columnNumber: 11
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
							className: "text-xs font-mono tracking-widest text-stone-500 uppercase",
							children: "CAREER DNA DOSSIER"
						}, void 0, false, {
							fileName: _jsxFileName$2,
							lineNumber: 151,
							columnNumber: 15
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
							className: "rounded-full bg-violet/10 px-2 py-0.5 text-[10px] font-bold text-violet",
							children: [
								"v",
								dna.version,
								".0"
							]
						}, void 0, true, {
							fileName: _jsxFileName$2,
							lineNumber: 154,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName$2,
						lineNumber: 150,
						columnNumber: 13
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "text-sm font-bold text-stone-900",
						children: [
							dna.context.stage,
							" • Synthesized ",
							dna.completedAt
						]
					}, void 0, true, {
						fileName: _jsxFileName$2,
						lineNumber: 158,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName$2,
						lineNumber: 149,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName$2,
					lineNumber: 145,
					columnNumber: 9
				}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [
						historyCount > 1 && onOpenEvolution && /* @__PURE__ */ (void 0)("button", {
							onClick: onOpenEvolution,
							className: "inline-flex items-center gap-1.5 rounded-xl border border-stone-200 bg-white px-3 py-2 text-xs font-semibold text-stone-700 hover:bg-stone-50 transition-colors shadow-sm",
							children: [/* @__PURE__ */ (void 0)(History, { className: "h-3.5 w-3.5 text-violet" }, void 0, false, {
								fileName: _jsxFileName$2,
								lineNumber: 170,
								columnNumber: 15
							}, this), /* @__PURE__ */ (void 0)("span", { children: [
								"Career Evolution (",
								historyCount,
								")"
							] }, void 0, true, {
								fileName: _jsxFileName$2,
								lineNumber: 171,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName$2,
							lineNumber: 166,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
							onClick: handleCopySummary,
							className: "inline-flex items-center gap-1.5 rounded-xl border border-stone-200 bg-white px-3 py-2 text-xs font-semibold text-stone-700 hover:bg-stone-50 transition-colors shadow-sm",
							title: "Copy summary text",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Copy, { className: "h-3.5 w-3.5 text-stone-500" }, void 0, false, {
								fileName: _jsxFileName$2,
								lineNumber: 180,
								columnNumber: 13
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: copied ? "Copied!" : "Copy" }, void 0, false, {
								fileName: _jsxFileName$2,
								lineNumber: 181,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName$2,
							lineNumber: 175,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
							onClick: handlePrint,
							className: "inline-flex items-center gap-1.5 rounded-xl border border-stone-200 bg-white px-3 py-2 text-xs font-semibold text-stone-700 hover:bg-stone-50 transition-colors shadow-sm",
							title: "Print or save as PDF",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Printer, { className: "h-3.5 w-3.5 text-stone-500" }, void 0, false, {
								fileName: _jsxFileName$2,
								lineNumber: 189,
								columnNumber: 13
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: "Print" }, void 0, false, {
								fileName: _jsxFileName$2,
								lineNumber: 190,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName$2,
							lineNumber: 184,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
							onClick: onRetake,
							className: "inline-flex items-center gap-1.5 rounded-xl border border-stone-200 bg-white px-3 py-2 text-xs font-semibold text-stone-700 hover:bg-stone-50 transition-colors shadow-sm",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(RotateCcw, { className: "h-3.5 w-3.5 text-stone-500" }, void 0, false, {
								fileName: _jsxFileName$2,
								lineNumber: 197,
								columnNumber: 13
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: "Retake Quest" }, void 0, false, {
								fileName: _jsxFileName$2,
								lineNumber: 198,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName$2,
							lineNumber: 193,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName$2,
					lineNumber: 164,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName$2,
				lineNumber: 144,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "relative overflow-hidden rounded-3xl bg-white border border-stone-200/90 p-6 sm:p-10 shadow-lg",
				children: [
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "absolute top-4 right-6 rotate-1 rounded bg-[#EAE5D9] px-3 py-1 text-[11px] font-mono text-stone-600 border border-stone-300",
						children: "CONFIDENTIAL DOSSIER"
					}, void 0, false, {
						fileName: _jsxFileName$2,
						lineNumber: 206,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "inline-flex items-center gap-2 rounded-full bg-violet/10 border border-violet/20 px-3.5 py-1 text-xs font-bold text-violet",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Sparkles, { className: "h-3.5 w-3.5" }, void 0, false, {
							fileName: _jsxFileName$2,
							lineNumber: 211,
							columnNumber: 11
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: "YOUR PRIMARY CAREER ARCHETYPE" }, void 0, false, {
							fileName: _jsxFileName$2,
							lineNumber: 212,
							columnNumber: 11
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName$2,
						lineNumber: 210,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h1", {
						className: "mt-4 text-3xl sm:text-5xl font-extrabold text-stone-900 tracking-tight leading-tight",
						children: dna.archetype.title
					}, void 0, false, {
						fileName: _jsxFileName$2,
						lineNumber: 215,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
						className: "mt-2 text-base sm:text-xl font-medium text-stone-600 italic",
						children: [
							"“",
							dna.archetype.tagline,
							"”"
						]
					}, void 0, true, {
						fileName: _jsxFileName$2,
						lineNumber: 219,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "mt-6 text-sm sm:text-base text-stone-700 leading-relaxed space-y-3 max-w-3xl",
						children: dna.archetype.description.split("\n\n").map((para, i) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", { children: para }, i, false, {
							fileName: _jsxFileName$2,
							lineNumber: 225,
							columnNumber: 13
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName$2,
						lineNumber: 223,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "mt-6 flex flex-wrap gap-2 pt-4 border-t border-stone-100",
						children: dna.archetype.traits.map((trait) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
							className: "rounded-full bg-stone-100 border border-stone-200 px-3.5 py-1 text-xs font-bold text-stone-800",
							children: ["✦ ", trait]
						}, trait, true, {
							fileName: _jsxFileName$2,
							lineNumber: 232,
							columnNumber: 13
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName$2,
						lineNumber: 230,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName$2,
				lineNumber: 204,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "rounded-3xl bg-white border border-stone-200/90 p-6 sm:p-8 shadow-sm",
				children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "flex items-center justify-between mb-6",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h2", {
						className: "text-xl font-extrabold text-stone-900",
						children: "Cognitive & Working Dimensions"
					}, void 0, false, {
						fileName: _jsxFileName$2,
						lineNumber: 246,
						columnNumber: 13
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
						className: "text-xs text-stone-500 mt-0.5",
						children: "Normalized score distribution from your 15 core scenarios and adaptive signals."
					}, void 0, false, {
						fileName: _jsxFileName$2,
						lineNumber: 249,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName$2,
						lineNumber: 245,
						columnNumber: 11
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
						className: "text-xs font-mono text-stone-400",
						children: "8 VECTORS"
					}, void 0, false, {
						fileName: _jsxFileName$2,
						lineNumber: 253,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName$2,
					lineNumber: 244,
					columnNumber: 9
				}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
					children: dimensionsList.map((dim) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "rounded-2xl border border-stone-100 bg-stone-50/70 p-3.5",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "flex items-center justify-between text-xs font-bold text-stone-800 mb-2",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: dim.label }, void 0, false, {
								fileName: _jsxFileName$2,
								lineNumber: 260,
								columnNumber: 17
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
								className: "font-mono text-stone-900",
								children: [dim.value, "%"]
							}, void 0, true, {
								fileName: _jsxFileName$2,
								lineNumber: 261,
								columnNumber: 17
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName$2,
							lineNumber: 259,
							columnNumber: 15
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "w-full h-2 rounded-full bg-stone-200 overflow-hidden",
							children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: `h-full rounded-full ${dim.color} transition-all duration-500`,
								style: { width: `${dim.value}%` }
							}, void 0, false, {
								fileName: _jsxFileName$2,
								lineNumber: 264,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName$2,
							lineNumber: 263,
							columnNumber: 15
						}, this)]
					}, dim.key, true, {
						fileName: _jsxFileName$2,
						lineNumber: 258,
						columnNumber: 13
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName$2,
					lineNumber: 256,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName$2,
				lineNumber: 243,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "space-y-4",
				children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h2", {
						className: "text-2xl font-extrabold text-stone-900 tracking-tight",
						children: "Top 5 Career Matches"
					}, void 0, false, {
						fileName: _jsxFileName$2,
						lineNumber: 278,
						columnNumber: 13
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
						className: "text-xs sm:text-sm text-stone-500",
						children: [
							"Ranked and contextualized specifically to your stage (",
							dna.context.stage,
							")."
						]
					}, void 0, true, {
						fileName: _jsxFileName$2,
						lineNumber: 281,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName$2,
						lineNumber: 277,
						columnNumber: 11
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "text-xs font-mono text-stone-400",
						children: "AI MATCHED"
					}, void 0, false, {
						fileName: _jsxFileName$2,
						lineNumber: 285,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName$2,
					lineNumber: 276,
					columnNumber: 9
				}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "space-y-4",
					children: dna.careerMatches.map((match, idx) => {
						const isExpanded = expandedMatchId === match.id;
						const isCurrentGoal = store.goal.toLowerCase() === match.title.toLowerCase();
						return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: `overflow-hidden rounded-3xl border transition-all ${isExpanded ? "border-stone-900 bg-white shadow-xl ring-1 ring-stone-900/10" : "border-stone-200/90 bg-white hover:border-stone-300 shadow-sm"}`,
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								onClick: () => toggleExpand(match.id),
								className: "flex flex-wrap items-center justify-between gap-4 p-5 sm:p-6 cursor-pointer select-none",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: "flex items-center gap-3.5",
									children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "grid h-12 w-12 place-items-center rounded-2xl bg-ink text-white font-extrabold text-base",
										children: ["0", idx + 1]
									}, void 0, true, {
										fileName: _jsxFileName$2,
										lineNumber: 308,
										columnNumber: 21
									}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "flex flex-wrap items-center gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
											className: "text-xs font-bold uppercase tracking-wider text-stone-500",
											children: match.domain
										}, void 0, false, {
											fileName: _jsxFileName$2,
											lineNumber: 314,
											columnNumber: 25
										}, this), isCurrentGoal && /* @__PURE__ */ (void 0)("span", {
											className: "rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5",
											children: "Current Goal"
										}, void 0, false, {
											fileName: _jsxFileName$2,
											lineNumber: 318,
											columnNumber: 27
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName$2,
										lineNumber: 313,
										columnNumber: 23
									}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h3", {
										className: "text-lg sm:text-xl font-extrabold text-stone-900",
										children: match.title
									}, void 0, false, {
										fileName: _jsxFileName$2,
										lineNumber: 323,
										columnNumber: 23
									}, this)] }, void 0, true, {
										fileName: _jsxFileName$2,
										lineNumber: 312,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName$2,
									lineNumber: 307,
									columnNumber: 19
								}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: "flex items-center gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "text-right",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "text-lg font-black text-stone-900",
											children: [match.matchScore, "%"]
										}, void 0, true, {
											fileName: _jsxFileName$2,
											lineNumber: 331,
											columnNumber: 23
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "text-[10px] font-mono text-stone-400 uppercase",
											children: "DNA FIT"
										}, void 0, false, {
											fileName: _jsxFileName$2,
											lineNumber: 332,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName$2,
										lineNumber: 330,
										columnNumber: 21
									}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "grid h-8 w-8 place-items-center rounded-xl bg-stone-100 text-stone-600",
										children: isExpanded ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(ChevronUp, { className: "h-4 w-4" }, void 0, false, {
											fileName: _jsxFileName$2,
											lineNumber: 337,
											columnNumber: 25
										}, this) : /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(ChevronDown, { className: "h-4 w-4" }, void 0, false, {
											fileName: _jsxFileName$2,
											lineNumber: 339,
											columnNumber: 25
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName$2,
										lineNumber: 335,
										columnNumber: 21
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName$2,
									lineNumber: 329,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName$2,
								lineNumber: 303,
								columnNumber: 17
							}, this), isExpanded && /* @__PURE__ */ (void 0)("div", {
								className: "border-t border-stone-100 p-5 sm:p-8 space-y-6 bg-[#FAFAF8]",
								children: [
									/* @__PURE__ */ (void 0)("div", {
										className: "grid grid-cols-1 md:grid-cols-2 gap-5",
										children: [/* @__PURE__ */ (void 0)("div", {
											className: "rounded-2xl bg-white border border-stone-200 p-4",
											children: [/* @__PURE__ */ (void 0)("div", {
												className: "text-xs font-mono font-bold text-stone-500 uppercase mb-1",
												children: "Role Summary"
											}, void 0, false, {
												fileName: _jsxFileName$2,
												lineNumber: 351,
												columnNumber: 25
											}, this), /* @__PURE__ */ (void 0)("p", {
												className: "text-sm text-stone-800 leading-relaxed",
												children: match.summary
											}, void 0, false, {
												fileName: _jsxFileName$2,
												lineNumber: 354,
												columnNumber: 25
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName$2,
											lineNumber: 350,
											columnNumber: 23
										}, this), /* @__PURE__ */ (void 0)("div", {
											className: "rounded-2xl bg-lilac/25 border border-violet/30 p-4",
											children: [/* @__PURE__ */ (void 0)("div", {
												className: "text-xs font-mono font-bold text-violet uppercase mb-1 flex items-center gap-1.5",
												children: [/* @__PURE__ */ (void 0)(Sparkles, { className: "h-3.5 w-3.5" }, void 0, false, {
													fileName: _jsxFileName$2,
													lineNumber: 359,
													columnNumber: 27
												}, this), /* @__PURE__ */ (void 0)("span", { children: "Why This Matches Your DNA" }, void 0, false, {
													fileName: _jsxFileName$2,
													lineNumber: 360,
													columnNumber: 27
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName$2,
												lineNumber: 358,
												columnNumber: 25
											}, this), /* @__PURE__ */ (void 0)("p", {
												className: "text-sm text-stone-800 leading-relaxed",
												children: match.whyMatched
											}, void 0, false, {
												fileName: _jsxFileName$2,
												lineNumber: 362,
												columnNumber: 25
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName$2,
											lineNumber: 357,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName$2,
										lineNumber: 349,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ (void 0)("div", {
										className: "rounded-2xl bg-white border border-stone-200 p-4 sm:p-5",
										children: [/* @__PURE__ */ (void 0)("div", {
											className: "text-xs font-mono font-bold text-stone-500 uppercase mb-2",
											children: "Day In The Life Snapshot"
										}, void 0, false, {
											fileName: _jsxFileName$2,
											lineNumber: 368,
											columnNumber: 23
										}, this), /* @__PURE__ */ (void 0)("p", {
											className: "text-sm text-stone-700 leading-relaxed",
											children: match.dayInTheLife
										}, void 0, false, {
											fileName: _jsxFileName$2,
											lineNumber: 371,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName$2,
										lineNumber: 367,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ (void 0)("div", {
										className: "grid grid-cols-1 sm:grid-cols-2 gap-4",
										children: [/* @__PURE__ */ (void 0)("div", {
											className: "rounded-2xl bg-white border border-stone-200 p-4",
											children: [/* @__PURE__ */ (void 0)("div", {
												className: "text-xs font-mono font-bold text-stone-500 uppercase mb-2",
												children: "Key Skills to Cultivate"
											}, void 0, false, {
												fileName: _jsxFileName$2,
												lineNumber: 377,
												columnNumber: 25
											}, this), /* @__PURE__ */ (void 0)("div", {
												className: "flex flex-wrap gap-1.5",
												children: match.keySkills.map((sk) => /* @__PURE__ */ (void 0)("span", {
													className: "rounded-lg bg-stone-100 px-2.5 py-1 text-xs font-medium text-stone-800",
													children: sk
												}, sk, false, {
													fileName: _jsxFileName$2,
													lineNumber: 382,
													columnNumber: 29
												}, this))
											}, void 0, false, {
												fileName: _jsxFileName$2,
												lineNumber: 380,
												columnNumber: 25
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName$2,
											lineNumber: 376,
											columnNumber: 23
										}, this), /* @__PURE__ */ (void 0)("div", {
											className: "rounded-2xl bg-white border border-stone-200 p-4",
											children: [/* @__PURE__ */ (void 0)("div", {
												className: "text-xs font-mono font-bold text-stone-500 uppercase mb-2",
												children: "Industry & Growth Outlook"
											}, void 0, false, {
												fileName: _jsxFileName$2,
												lineNumber: 393,
												columnNumber: 25
											}, this), /* @__PURE__ */ (void 0)("p", {
												className: "text-xs sm:text-sm text-stone-700 leading-relaxed",
												children: match.growthOutlook
											}, void 0, false, {
												fileName: _jsxFileName$2,
												lineNumber: 396,
												columnNumber: 25
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName$2,
											lineNumber: 392,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName$2,
										lineNumber: 375,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ (void 0)("div", {
										className: "rounded-2xl bg-amber-50/70 border border-amber-200 p-4 sm:p-5",
										children: [/* @__PURE__ */ (void 0)("div", {
											className: "text-xs font-mono font-bold text-amber-800 uppercase mb-1 flex items-center gap-1.5",
											children: [/* @__PURE__ */ (void 0)(Flame, { className: "h-4 w-4 text-orange" }, void 0, false, {
												fileName: _jsxFileName$2,
												lineNumber: 405,
												columnNumber: 25
											}, this), /* @__PURE__ */ (void 0)("span", { children: "Recommended 1-Week Starter Project" }, void 0, false, {
												fileName: _jsxFileName$2,
												lineNumber: 406,
												columnNumber: 25
											}, this)]
										}, void 0, true, {
											fileName: _jsxFileName$2,
											lineNumber: 404,
											columnNumber: 23
										}, this), /* @__PURE__ */ (void 0)("p", {
											className: "text-sm text-stone-800 font-medium leading-relaxed",
											children: match.starterProject
										}, void 0, false, {
											fileName: _jsxFileName$2,
											lineNumber: 408,
											columnNumber: 23
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName$2,
										lineNumber: 403,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ (void 0)("div", {
										className: "flex flex-wrap items-center gap-3 pt-3",
										children: [
											/* @__PURE__ */ (void 0)("button", {
												onClick: () => handleAdoptGoal(match),
												disabled: isCurrentGoal,
												className: `inline-flex items-center gap-2 rounded-xl px-5 py-2.5 text-xs sm:text-sm font-bold transition-all shadow-sm ${isCurrentGoal ? "bg-stone-200 text-stone-500 cursor-default" : "bg-ink text-white hover:bg-black"}`,
												children: [/* @__PURE__ */ (void 0)(Target, { className: "h-4 w-4 text-sun" }, void 0, false, {
													fileName: _jsxFileName$2,
													lineNumber: 424,
													columnNumber: 25
												}, this), /* @__PURE__ */ (void 0)("span", { children: isCurrentGoal ? "Active Target Goal" : "Adopt as My Target Goal" }, void 0, false, {
													fileName: _jsxFileName$2,
													lineNumber: 425,
													columnNumber: 25
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName$2,
												lineNumber: 415,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ (void 0)(Link, {
												to: "/learning",
												search: { query: match.recommendedCourseQuery || match.title },
												className: "inline-flex items-center gap-1.5 rounded-xl border border-stone-300 bg-white px-4 py-2.5 text-xs sm:text-sm font-semibold text-stone-700 hover:bg-stone-50 transition-colors shadow-sm",
												children: [/* @__PURE__ */ (void 0)(GraduationCap, { className: "h-4 w-4 text-violet" }, void 0, false, {
													fileName: _jsxFileName$2,
													lineNumber: 435,
													columnNumber: 25
												}, this), /* @__PURE__ */ (void 0)("span", { children: "Explore Courses" }, void 0, false, {
													fileName: _jsxFileName$2,
													lineNumber: 436,
													columnNumber: 25
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName$2,
												lineNumber: 430,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ (void 0)(Link, {
												to: "/roadmap",
												className: "inline-flex items-center gap-1.5 rounded-xl border border-stone-300 bg-white px-4 py-2.5 text-xs sm:text-sm font-semibold text-stone-700 hover:bg-stone-50 transition-colors shadow-sm",
												children: [/* @__PURE__ */ (void 0)(Compass, { className: "h-4 w-4 text-stone-500" }, void 0, false, {
													fileName: _jsxFileName$2,
													lineNumber: 443,
													columnNumber: 25
												}, this), /* @__PURE__ */ (void 0)("span", { children: "View Roadmap" }, void 0, false, {
													fileName: _jsxFileName$2,
													lineNumber: 444,
													columnNumber: 25
												}, this)]
											}, void 0, true, {
												fileName: _jsxFileName$2,
												lineNumber: 439,
												columnNumber: 23
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName$2,
										lineNumber: 414,
										columnNumber: 21
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName$2,
								lineNumber: 347,
								columnNumber: 19
							}, this)]
						}, match.id, true, {
							fileName: _jsxFileName$2,
							lineNumber: 294,
							columnNumber: 15
						}, this);
					})
				}, void 0, false, {
					fileName: _jsxFileName$2,
					lineNumber: 288,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName$2,
				lineNumber: 275,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "rounded-3xl bg-white border border-stone-200/90 p-6 sm:p-8 shadow-sm",
				children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "flex items-center justify-between mb-6",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h2", {
						className: "text-2xl font-extrabold text-stone-900 tracking-tight",
						children: "10 Core Strengths & Evidence"
					}, void 0, false, {
						fileName: _jsxFileName$2,
						lineNumber: 459,
						columnNumber: 13
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
						className: "text-xs sm:text-sm text-stone-500",
						children: "Uncovered from your uncensored choices across the 5 discovery rounds."
					}, void 0, false, {
						fileName: _jsxFileName$2,
						lineNumber: 462,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName$2,
						lineNumber: 458,
						columnNumber: 11
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
						className: "text-xs font-mono text-stone-400",
						children: "10 PILLARS"
					}, void 0, false, {
						fileName: _jsxFileName$2,
						lineNumber: 466,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName$2,
					lineNumber: 457,
					columnNumber: 9
				}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "grid grid-cols-1 md:grid-cols-2 gap-4",
					children: dna.strengths.map((str, i) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "rounded-2xl border border-stone-200/90 bg-stone-50/50 p-4 sm:p-5 flex flex-col justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "flex items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
								className: "font-bold text-stone-900 text-sm sm:text-base",
								children: [
									"0",
									i + 1,
									". ",
									str.name
								]
							}, void 0, true, {
								fileName: _jsxFileName$2,
								lineNumber: 477,
								columnNumber: 19
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
								className: "rounded-full bg-stone-200/80 px-2.5 py-0.5 text-[10px] font-mono uppercase text-stone-700 font-semibold",
								children: str.category
							}, void 0, false, {
								fileName: _jsxFileName$2,
								lineNumber: 480,
								columnNumber: 19
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName$2,
							lineNumber: 476,
							columnNumber: 17
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "mt-2 text-xs text-stone-600 leading-relaxed",
							children: [
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("strong", {
									className: "text-stone-800",
									children: "Observed Evidence:"
								}, void 0, false, {
									fileName: _jsxFileName$2,
									lineNumber: 486,
									columnNumber: 19
								}, this),
								" ",
								str.evidence
							]
						}, void 0, true, {
							fileName: _jsxFileName$2,
							lineNumber: 485,
							columnNumber: 17
						}, this)] }, void 0, true, {
							fileName: _jsxFileName$2,
							lineNumber: 475,
							columnNumber: 15
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "mt-3 pt-3 border-t border-stone-200/60 text-xs text-violet font-medium",
							children: [
								"💡 ",
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("strong", { children: "Growth Tip:" }, void 0, false, {
									fileName: _jsxFileName$2,
									lineNumber: 491,
									columnNumber: 20
								}, this),
								" ",
								str.growthTip
							]
						}, void 0, true, {
							fileName: _jsxFileName$2,
							lineNumber: 490,
							columnNumber: 15
						}, this)]
					}, str.name, true, {
						fileName: _jsxFileName$2,
						lineNumber: 471,
						columnNumber: 13
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName$2,
					lineNumber: 469,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName$2,
				lineNumber: 456,
				columnNumber: 7
			}, this),
			dna.unexpectedMatch && /* @__PURE__ */ (void 0)("div", {
				className: "relative overflow-hidden rounded-3xl bg-gradient-to-br from-blush/40 via-white to-sun/30 border border-orange/30 p-6 sm:p-8 shadow-md",
				children: [
					/* @__PURE__ */ (void 0)("div", {
						className: "inline-flex items-center gap-1.5 rounded-full bg-orange/15 border border-orange/30 px-3 py-1 text-xs font-bold text-orange",
						children: [/* @__PURE__ */ (void 0)(Lightbulb, { className: "h-3.5 w-3.5" }, void 0, false, {
							fileName: _jsxFileName$2,
							lineNumber: 502,
							columnNumber: 13
						}, this), /* @__PURE__ */ (void 0)("span", { children: "THE WILDCARD MATCH (NON-OBVIOUS DISCOVERY)" }, void 0, false, {
							fileName: _jsxFileName$2,
							lineNumber: 503,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName$2,
						lineNumber: 501,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ (void 0)("h3", {
						className: "mt-3 text-2xl font-extrabold text-stone-900",
						children: dna.unexpectedMatch.title
					}, void 0, false, {
						fileName: _jsxFileName$2,
						lineNumber: 506,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ (void 0)("div", {
						className: "text-xs font-bold text-stone-500 uppercase tracking-wider mt-0.5",
						children: dna.unexpectedMatch.domain
					}, void 0, false, {
						fileName: _jsxFileName$2,
						lineNumber: 510,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ (void 0)("p", {
						className: "mt-3 text-sm text-stone-700 leading-relaxed max-w-2xl",
						children: dna.unexpectedMatch.reason
					}, void 0, false, {
						fileName: _jsxFileName$2,
						lineNumber: 514,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ (void 0)("div", {
						className: "mt-4 rounded-xl bg-white/80 border border-stone-200 p-3.5 text-xs text-stone-800",
						children: [
							/* @__PURE__ */ (void 0)("strong", { children: "Curiosity Hook:" }, void 0, false, {
								fileName: _jsxFileName$2,
								lineNumber: 519,
								columnNumber: 13
							}, this),
							" ",
							dna.unexpectedMatch.explorationHook
						]
					}, void 0, true, {
						fileName: _jsxFileName$2,
						lineNumber: 518,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName$2,
				lineNumber: 500,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "rounded-3xl bg-white border border-stone-200/90 p-6 sm:p-8 shadow-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h2", {
						className: "text-xl font-extrabold text-stone-900 tracking-tight",
						children: "Next 7-Day Low-Pressure Playbook"
					}, void 0, false, {
						fileName: _jsxFileName$2,
						lineNumber: 526,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
						className: "text-xs sm:text-sm text-stone-500 mt-1",
						children: "Tiny, zero-anxiety experiments to test your resonance without committing your whole life."
					}, void 0, false, {
						fileName: _jsxFileName$2,
						lineNumber: 529,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "mt-6 space-y-3",
						children: dna.actionableNextSteps.map((step) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "flex items-start gap-3.5 rounded-2xl border border-stone-200 bg-stone-50/60 p-4",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "grid h-8 w-16 shrink-0 place-items-center rounded-xl bg-ink text-white font-mono text-xs font-bold",
								children: step.day
							}, void 0, false, {
								fileName: _jsxFileName$2,
								lineNumber: 539,
								columnNumber: 15
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "font-bold text-stone-900 text-sm sm:text-base",
								children: step.title
							}, void 0, false, {
								fileName: _jsxFileName$2,
								lineNumber: 543,
								columnNumber: 17
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "text-xs sm:text-sm text-stone-600 mt-0.5 leading-relaxed",
								children: step.action
							}, void 0, false, {
								fileName: _jsxFileName$2,
								lineNumber: 544,
								columnNumber: 17
							}, this)] }, void 0, true, {
								fileName: _jsxFileName$2,
								lineNumber: 542,
								columnNumber: 15
							}, this)]
						}, step.day, true, {
							fileName: _jsxFileName$2,
							lineNumber: 535,
							columnNumber: 13
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName$2,
						lineNumber: 533,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName$2,
				lineNumber: 525,
				columnNumber: 7
			}, this),
			dna.whatWeStillDontKnow?.length > 0 && /* @__PURE__ */ (void 0)("div", {
				className: "rounded-3xl bg-stone-100/80 border border-stone-200 p-6 sm:p-8",
				children: [
					/* @__PURE__ */ (void 0)("div", {
						className: "flex items-center gap-2 text-stone-700 font-bold text-sm mb-2",
						children: [/* @__PURE__ */ (void 0)(CircleQuestionMark, { className: "h-4 w-4 text-stone-500" }, void 0, false, {
							fileName: _jsxFileName$2,
							lineNumber: 557,
							columnNumber: 13
						}, this), /* @__PURE__ */ (void 0)("span", { children: "Honest Scientific Humility: What We Still Don't Know" }, void 0, false, {
							fileName: _jsxFileName$2,
							lineNumber: 558,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName$2,
						lineNumber: 556,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ (void 0)("p", {
						className: "text-xs text-stone-500 mb-4",
						children: "No quiz can predict everything. Here are remaining ambiguities that can only be answered by hands-on experimentation:"
					}, void 0, false, {
						fileName: _jsxFileName$2,
						lineNumber: 560,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ (void 0)("ul", {
						className: "space-y-2 text-xs sm:text-sm text-stone-700",
						children: dna.whatWeStillDontKnow.map((item, idx) => /* @__PURE__ */ (void 0)("li", {
							className: "flex items-start gap-2",
							children: [/* @__PURE__ */ (void 0)("span", {
								className: "text-stone-400 font-mono",
								children: [
									"0",
									idx + 1,
									"."
								]
							}, void 0, true, {
								fileName: _jsxFileName$2,
								lineNumber: 568,
								columnNumber: 17
							}, this), /* @__PURE__ */ (void 0)("span", { children: item }, void 0, false, {
								fileName: _jsxFileName$2,
								lineNumber: 569,
								columnNumber: 17
							}, this)]
						}, idx, true, {
							fileName: _jsxFileName$2,
							lineNumber: 567,
							columnNumber: 15
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName$2,
						lineNumber: 565,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName$2,
				lineNumber: 555,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
				className: "flex flex-wrap items-center justify-between gap-4 rounded-3xl bg-ink text-white p-6 sm:p-8 shadow-xl",
				children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "text-lg font-bold",
					children: "Ready to take your next step?"
				}, void 0, false, {
					fileName: _jsxFileName$2,
					lineNumber: 579,
					columnNumber: 11
				}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "text-xs text-stone-300 mt-0.5",
					children: [
						"Explore curated learning modules and AI mock interviews tailored to",
						" ",
						dna.careerMatches[0]?.title,
						"."
					]
				}, void 0, true, {
					fileName: _jsxFileName$2,
					lineNumber: 580,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName$2,
					lineNumber: 578,
					columnNumber: 9
				}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "flex items-center gap-3",
					children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Link, {
						to: "/roadmap",
						className: "inline-flex items-center gap-2 rounded-xl bg-sun px-5 py-3 text-xs sm:text-sm font-bold text-ink hover:bg-yellow-300 transition-colors shadow-sm",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: "Explore Custom Roadmap" }, void 0, false, {
							fileName: _jsxFileName$2,
							lineNumber: 591,
							columnNumber: 13
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(ArrowRight, { className: "h-4 w-4" }, void 0, false, {
							fileName: _jsxFileName$2,
							lineNumber: 592,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName$2,
						lineNumber: 587,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName$2,
					lineNumber: 586,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName$2,
				lineNumber: 577,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName$2,
		lineNumber: 134,
		columnNumber: 5
	}, this);
}
var _jsxFileName$1 = "/app/applet/src/components/career-quest/CareerEvolutionModal.tsx";
function CareerEvolutionModal({ isOpen, onClose, currentDNA, history, onSelectVersion }) {
	const allVersions = [currentDNA, ...history.filter((h) => h.id !== currentDNA.id)];
	const [selectedId, setSelectedId] = (0, import_react.useState)(currentDNA.id);
	if (!isOpen) return null;
	const activeCompareDNA = allVersions.find((v) => v.id === selectedId) || currentDNA;
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
		className: "fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm animate-in fade-in",
		children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
			className: "relative w-full max-w-3xl overflow-hidden rounded-3xl bg-white border border-stone-200 shadow-2xl font-sans max-h-[90vh] flex flex-col",
			children: [
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "flex items-center justify-between border-b border-stone-200 p-5 sm:p-6",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "flex items-center gap-2.5",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "grid h-9 w-9 place-items-center rounded-xl bg-violet/10 text-violet",
							children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(History, { className: "h-5 w-5" }, void 0, false, {
								fileName: _jsxFileName$1,
								lineNumber: 44,
								columnNumber: 15
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName$1,
							lineNumber: 43,
							columnNumber: 13
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h3", {
							className: "font-extrabold text-stone-900 text-lg",
							children: "Career Evolution & Retake History"
						}, void 0, false, {
							fileName: _jsxFileName$1,
							lineNumber: 47,
							columnNumber: 15
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
							className: "text-xs text-stone-500",
							children: "Track how your interests, strengths, and archetypes evolve over time."
						}, void 0, false, {
							fileName: _jsxFileName$1,
							lineNumber: 50,
							columnNumber: 15
						}, this)] }, void 0, true, {
							fileName: _jsxFileName$1,
							lineNumber: 46,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName$1,
						lineNumber: 42,
						columnNumber: 11
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
						onClick: onClose,
						className: "grid h-8 w-8 place-items-center rounded-xl text-stone-400 hover:bg-stone-100 hover:text-stone-700 transition-colors",
						children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(X, { className: "h-5 w-5" }, void 0, false, {
							fileName: _jsxFileName$1,
							lineNumber: 60,
							columnNumber: 13
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName$1,
						lineNumber: 56,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName$1,
					lineNumber: 41,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "overflow-y-auto p-5 sm:p-6 space-y-6 flex-1",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "text-xs font-mono font-bold uppercase text-stone-500 mb-2",
						children: [
							"Assessment Versions (",
							allVersions.length,
							")"
						]
					}, void 0, true, {
						fileName: _jsxFileName$1,
						lineNumber: 68,
						columnNumber: 13
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "flex flex-wrap gap-2",
						children: allVersions.map((item, idx) => {
							const isSelected = item.id === selectedId;
							const isLatest = idx === 0;
							return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
								onClick: () => setSelectedId(item.id),
								className: `flex items-center gap-2 rounded-xl px-3.5 py-2 text-xs font-bold transition-all border ${isSelected ? "border-violet bg-lilac/30 text-violet shadow-sm" : "border-stone-200 bg-stone-50 text-stone-600 hover:bg-stone-100"}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: ["Version ", item.version || allVersions.length - idx] }, void 0, true, {
										fileName: _jsxFileName$1,
										lineNumber: 86,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
										className: "text-[10px] font-mono text-stone-400",
										children: [
											"(",
											item.completedAt,
											")"
										]
									}, void 0, true, {
										fileName: _jsxFileName$1,
										lineNumber: 87,
										columnNumber: 21
									}, this),
									isLatest && /* @__PURE__ */ (void 0)("span", {
										className: "rounded-full bg-emerald-100 text-emerald-800 text-[9px] px-1.5 py-0.2 font-mono",
										children: "Active"
									}, void 0, false, {
										fileName: _jsxFileName$1,
										lineNumber: 91,
										columnNumber: 23
									}, this)
								]
							}, item.id, true, {
								fileName: _jsxFileName$1,
								lineNumber: 77,
								columnNumber: 19
							}, this);
						})
					}, void 0, false, {
						fileName: _jsxFileName$1,
						lineNumber: 71,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName$1,
						lineNumber: 67,
						columnNumber: 11
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "rounded-2xl border border-stone-200 bg-stone-50/70 p-5 space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "flex flex-wrap items-center justify-between gap-2 border-b border-stone-200 pb-3",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
										className: "text-xs font-mono uppercase tracking-wider text-stone-400",
										children: "Archetype for this snapshot"
									}, void 0, false, {
										fileName: _jsxFileName$1,
										lineNumber: 105,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h4", {
										className: "text-xl font-extrabold text-stone-900",
										children: activeCompareDNA.archetype.title
									}, void 0, false, {
										fileName: _jsxFileName$1,
										lineNumber: 108,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
										className: "text-xs text-stone-600 italic",
										children: [
											"\"",
											activeCompareDNA.archetype.tagline,
											"\""
										]
									}, void 0, true, {
										fileName: _jsxFileName$1,
										lineNumber: 111,
										columnNumber: 17
									}, this)
								] }, void 0, true, {
									fileName: _jsxFileName$1,
									lineNumber: 104,
									columnNumber: 15
								}, this), activeCompareDNA.id !== currentDNA.id && /* @__PURE__ */ (void 0)("button", {
									onClick: () => {
										onSelectVersion(activeCompareDNA);
										onClose();
									},
									className: "rounded-xl bg-ink px-4 py-2 text-xs font-bold text-white hover:bg-black transition-colors",
									children: "Set as Active Report"
								}, void 0, false, {
									fileName: _jsxFileName$1,
									lineNumber: 117,
									columnNumber: 17
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName$1,
								lineNumber: 103,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "text-xs font-mono font-bold uppercase text-stone-500 mb-2",
								children: "Top Matches in this assessment:"
							}, void 0, false, {
								fileName: _jsxFileName$1,
								lineNumber: 131,
								columnNumber: 15
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "space-y-2",
								children: activeCompareDNA.careerMatches.slice(0, 3).map((m, i) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
									className: "flex items-center justify-between rounded-xl bg-white border border-stone-200 p-3 text-xs",
									children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "flex items-center gap-2",
										children: [
											/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
												className: "font-bold text-stone-800",
												children: [
													"0",
													i + 1,
													"."
												]
											}, void 0, true, {
												fileName: _jsxFileName$1,
												lineNumber: 141,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
												className: "font-bold text-stone-900",
												children: m.title
											}, void 0, false, {
												fileName: _jsxFileName$1,
												lineNumber: 142,
												columnNumber: 23
											}, this),
											/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
												className: "text-stone-400",
												children: [
													"(",
													m.domain,
													")"
												]
											}, void 0, true, {
												fileName: _jsxFileName$1,
												lineNumber: 143,
												columnNumber: 23
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName$1,
										lineNumber: 140,
										columnNumber: 21
									}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
										className: "font-mono font-bold text-stone-700",
										children: [m.matchScore, "%"]
									}, void 0, true, {
										fileName: _jsxFileName$1,
										lineNumber: 145,
										columnNumber: 21
									}, this)]
								}, m.id, true, {
									fileName: _jsxFileName$1,
									lineNumber: 136,
									columnNumber: 19
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName$1,
								lineNumber: 134,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName$1,
								lineNumber: 130,
								columnNumber: 13
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "text-xs font-mono font-bold uppercase text-stone-500 mb-2",
								children: "Key Dimensions in this snapshot:"
							}, void 0, false, {
								fileName: _jsxFileName$1,
								lineNumber: 153,
								columnNumber: 15
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs",
								children: [
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "rounded-lg bg-white border border-stone-200 p-2 text-center",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "text-stone-500 text-[10px]",
											children: "Technical"
										}, void 0, false, {
											fileName: _jsxFileName$1,
											lineNumber: 158,
											columnNumber: 19
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "font-bold text-stone-900",
											children: [activeCompareDNA.dimensions.technical, "%"]
										}, void 0, true, {
											fileName: _jsxFileName$1,
											lineNumber: 159,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName$1,
										lineNumber: 157,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "rounded-lg bg-white border border-stone-200 p-2 text-center",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "text-stone-500 text-[10px]",
											children: "Creative"
										}, void 0, false, {
											fileName: _jsxFileName$1,
											lineNumber: 164,
											columnNumber: 19
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "font-bold text-stone-900",
											children: [activeCompareDNA.dimensions.creative, "%"]
										}, void 0, true, {
											fileName: _jsxFileName$1,
											lineNumber: 165,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName$1,
										lineNumber: 163,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "rounded-lg bg-white border border-stone-200 p-2 text-center",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "text-stone-500 text-[10px]",
											children: "Analytical"
										}, void 0, false, {
											fileName: _jsxFileName$1,
											lineNumber: 170,
											columnNumber: 19
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "font-bold text-stone-900",
											children: [activeCompareDNA.dimensions.analytical, "%"]
										}, void 0, true, {
											fileName: _jsxFileName$1,
											lineNumber: 171,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName$1,
										lineNumber: 169,
										columnNumber: 17
									}, this),
									/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
										className: "rounded-lg bg-white border border-stone-200 p-2 text-center",
										children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "text-stone-500 text-[10px]",
											children: "Leadership"
										}, void 0, false, {
											fileName: _jsxFileName$1,
											lineNumber: 176,
											columnNumber: 19
										}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
											className: "font-bold text-stone-900",
											children: [activeCompareDNA.dimensions.leadership, "%"]
										}, void 0, true, {
											fileName: _jsxFileName$1,
											lineNumber: 177,
											columnNumber: 19
										}, this)]
									}, void 0, true, {
										fileName: _jsxFileName$1,
										lineNumber: 175,
										columnNumber: 17
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName$1,
								lineNumber: 156,
								columnNumber: 15
							}, this)] }, void 0, true, {
								fileName: _jsxFileName$1,
								lineNumber: 152,
								columnNumber: 13
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName$1,
						lineNumber: 102,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName$1,
					lineNumber: 65,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "border-t border-stone-200 p-4 bg-stone-50 flex justify-end",
					children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", {
						onClick: onClose,
						className: "rounded-xl px-5 py-2 text-xs font-semibold text-stone-700 hover:bg-stone-200 transition-colors",
						children: "Close"
					}, void 0, false, {
						fileName: _jsxFileName$1,
						lineNumber: 188,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName$1,
					lineNumber: 187,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName$1,
			lineNumber: 39,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName$1,
		lineNumber: 38,
		columnNumber: 5
	}, this);
}
var _jsxFileName = "/app/applet/src/routes/quest.tsx?tsr-split=component";
function CareerQuestPage() {
	const store = usePathfinder((s) => s);
	const navigate = useNavigate();
	const [step, setStep] = (0, import_react.useState)("cover");
	const [context, setContext] = (0, import_react.useState)({ stage: "Undergraduate student" });
	const [coreAnswers, setCoreAnswers] = (0, import_react.useState)({});
	const [currentCoreIndex, setCurrentCoreIndex] = (0, import_react.useState)(0);
	const [adaptiveQuestions, setAdaptiveQuestions] = (0, import_react.useState)([]);
	const [adaptiveAnswers, setAdaptiveAnswers] = (0, import_react.useState)({});
	const [activeDNA, setActiveDNA] = (0, import_react.useState)(store.careerDNA);
	const [evolutionOpen, setEvolutionOpen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (store.activeQuestProgress) {
			const p = store.activeQuestProgress;
			if (p.stage) setContext({
				stage: p.stage,
				fieldOrSubject: p.fieldOrSubject,
				interests: p.interests,
				region: p.region
			});
			if (p.coreAnswers) setCoreAnswers(p.coreAnswers);
			if (typeof p.currentQuestionIndex === "number") setCurrentCoreIndex(p.currentQuestionIndex);
			if (p.adaptiveQuestions) setAdaptiveQuestions(p.adaptiveQuestions);
			if (p.adaptiveAnswers) setAdaptiveAnswers(p.adaptiveAnswers);
		}
	}, [store.activeQuestProgress]);
	const persistProgress = (nextStep, nextIndex, nextCoreAnswers, nextAdaptiveAnswers = adaptiveAnswers, nextAdaptiveQuestions = adaptiveQuestions) => {
		const progress = {
			stage: context.stage,
			fieldOrSubject: context.fieldOrSubject,
			interests: context.interests,
			region: context.region,
			currentStep: nextStep,
			currentQuestionIndex: nextIndex,
			coreAnswers: nextCoreAnswers,
			adaptiveAnswers: nextAdaptiveAnswers,
			adaptiveQuestions: nextAdaptiveQuestions,
			updatedAt: (/* @__PURE__ */ new Date()).toISOString()
		};
		actions.saveQuestProgress(progress);
	};
	const handleStartFresh = () => {
		actions.clearQuestProgress();
		setCoreAnswers({});
		setCurrentCoreIndex(0);
		setAdaptiveQuestions([]);
		setAdaptiveAnswers({});
		setStep("context");
	};
	const handleResume = () => {
		if (store.activeQuestProgress) {
			const savedStep = store.activeQuestProgress.currentStep;
			if (savedStep === "core") setStep("core");
			else if (savedStep === "adaptive") setStep("adaptive");
			else setStep("core");
		} else setStep("core");
	};
	const handleViewDNA = () => {
		if (store.careerDNA) {
			setActiveDNA(store.careerDNA);
			setStep("report");
		}
	};
	const handleContextContinue = (ctx) => {
		setContext(ctx);
		setStep("intro");
	};
	const handleBeginCore = () => {
		setStep("core");
		setCurrentCoreIndex(0);
		persistProgress("core", 0, coreAnswers);
	};
	const currentQ = CORE_QUESTIONS[currentCoreIndex] || CORE_QUESTIONS[0];
	const currentAns = coreAnswers[currentQ.id];
	const handleSelectCoreOption = (optId) => {
		const isMulti = !!currentQ.allowMultiple;
		let nextAns;
		if (isMulti) {
			const existing = Array.isArray(currentAns) ? currentAns : currentAns ? [currentAns] : [];
			if (existing.includes(optId)) nextAns = existing.filter((x) => x !== optId);
			else nextAns = [...existing, optId];
		} else nextAns = optId;
		const updatedCore = {
			...coreAnswers,
			[currentQ.id]: nextAns
		};
		setCoreAnswers(updatedCore);
		persistProgress("core", currentCoreIndex, updatedCore);
	};
	const handleNextCore = () => {
		if (currentCoreIndex < CORE_QUESTIONS.length - 1) {
			const nextIdx = currentCoreIndex + 1;
			setCurrentCoreIndex(nextIdx);
			persistProgress("core", nextIdx, coreAnswers);
		} else {
			setStep("adaptive");
			persistProgress("adaptive", currentCoreIndex, coreAnswers);
		}
	};
	const handlePrevCore = () => {
		if (currentCoreIndex > 0) {
			const prevIdx = currentCoreIndex - 1;
			setCurrentCoreIndex(prevIdx);
			persistProgress("core", prevIdx, coreAnswers);
		} else setStep("intro");
	};
	const handleSaveAndExit = () => {
		persistProgress("core", currentCoreIndex, coreAnswers);
		navigate({ to: "/" });
	};
	const handleAdaptiveComplete = (questions, answers) => {
		setAdaptiveQuestions(questions);
		setAdaptiveAnswers(answers);
		persistProgress("adaptive", currentCoreIndex, coreAnswers, answers, questions);
		setStep("synthesizing");
	};
	const handleSynthesisSuccess = (dna) => {
		actions.saveCareerDNA(dna);
		setActiveDNA(dna);
		setStep("report");
	};
	const handleSynthesisFallback = () => {
		const nextVer = (store.careerDNA?.version || 0) + 1;
		const fallbackDNA = generateFallbackCareerDNA(context, coreAnswers, adaptiveAnswers, nextVer);
		actions.saveCareerDNA(fallbackDNA);
		setActiveDNA(fallbackDNA);
		setStep("report");
	};
	const handleSelectEvolutionVersion = (dna) => {
		setActiveDNA(dna);
	};
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
		className: "w-full",
		children: [
			step === "cover" && /* @__PURE__ */ (void 0)(QuestDossierCover, {
				onStart: handleStartFresh,
				onResume: store.activeQuestProgress ? handleResume : void 0,
				onViewDNA: store.careerDNA ? handleViewDNA : void 0,
				onOpenEvolution: () => setEvolutionOpen(true),
				existingDNA: store.careerDNA,
				historyCount: (store.careerDNAHistory?.length || 0) + (store.careerDNA ? 1 : 0),
				inProgress: store.activeQuestProgress
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 202,
				columnNumber: 30
			}, this),
			step === "context" && /* @__PURE__ */ (void 0)(QuestContextStep, {
				initialContext: context,
				onContinue: handleContextContinue,
				onBack: () => setStep("cover")
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 204,
				columnNumber: 32
			}, this),
			step === "intro" && /* @__PURE__ */ (void 0)(QuestIntroStep, {
				context,
				onBegin: handleBeginCore,
				onBack: () => setStep("context")
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 206,
				columnNumber: 30
			}, this),
			step === "core" && /* @__PURE__ */ (void 0)(QuestQuestionCard, {
				question: currentQ,
				currentAnswer: currentAns,
				onSelectOption: handleSelectCoreOption,
				onNext: handleNextCore,
				onPrev: handlePrevCore,
				onSaveAndExit: handleSaveAndExit,
				canGoBack: true,
				totalQuestions: CORE_QUESTIONS.length,
				currentQuestionNumber: currentCoreIndex + 1
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 208,
				columnNumber: 29
			}, this),
			step === "adaptive" && /* @__PURE__ */ (void 0)(QuestAdaptiveStep, {
				context,
				coreAnswers,
				cachedQuestions: adaptiveQuestions.length ? adaptiveQuestions : void 0,
				cachedAnswers: adaptiveAnswers,
				onComplete: handleAdaptiveComplete,
				onBack: () => {
					setStep("core");
					setCurrentCoreIndex(CORE_QUESTIONS.length - 1);
				}
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 210,
				columnNumber: 33
			}, this),
			step === "synthesizing" && /* @__PURE__ */ (void 0)(QuestSynthesizingStep, {
				context,
				coreAnswers,
				adaptiveAnswers,
				version: (store.careerDNA?.version || 0) + 1,
				onSuccess: handleSynthesisSuccess,
				onErrorFallback: handleSynthesisFallback
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 215,
				columnNumber: 37
			}, this),
			step === "report" && activeDNA && /* @__PURE__ */ (void 0)(QuestDNAReport, {
				dna: activeDNA,
				onRetake: handleStartFresh,
				onOpenEvolution: () => setEvolutionOpen(true),
				historyCount: (store.careerDNAHistory?.length || 0) + (store.careerDNA ? 1 : 0)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 217,
				columnNumber: 44
			}, this),
			activeDNA && /* @__PURE__ */ (void 0)(CareerEvolutionModal, {
				isOpen: evolutionOpen,
				onClose: () => setEvolutionOpen(false),
				currentDNA: activeDNA,
				history: store.careerDNAHistory || [],
				onSelectVersion: handleSelectEvolutionVersion
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 220,
				columnNumber: 23
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 201,
		columnNumber: 7
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 200,
		columnNumber: 10
	}, this);
}
//#endregion
export { CareerQuestPage as component };
