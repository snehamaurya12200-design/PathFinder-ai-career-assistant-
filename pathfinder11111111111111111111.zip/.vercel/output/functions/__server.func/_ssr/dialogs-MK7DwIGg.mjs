import { o as __toESM } from "../_runtime.mjs";
import { y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as require_jsx_dev_runtime } from "../_libs/react.mjs";
import { $ as GraduationCap, B as MapPin, C as ShieldAlert, Et as Building2, Mt as BookOpen, R as Mic, Tt as CalendarDays, X as IndianRupee, _t as CircleCheck, at as ExternalLink, dt as Clock, h as Timer, mt as CircleX, y as Sparkles } from "../_libs/lucide-react.mjs";
import { a as DialogDescription, c as DialogTitle, f as usePathfinder, i as DialogContent, l as actions, o as DialogFooter, r as Dialog, s as DialogHeader, t as APP_STATUSES } from "./AppShell-CmHrRTAn.mjs";
import { r as evaluateInterviewAnswerWithGemini } from "./ai.functions-u7pgug8o.mjs";
import { t as Button } from "./button-Cp1tlOE-.mjs";
import { l as testBank, o as interviewBank, r as courseById, s as jobs } from "./pathfinder-data-LKyDtySq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dialogs-MK7DwIGg.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_dev_runtime = require_jsx_dev_runtime();
var _jsxFileName = "/app/applet/src/components/pathfinder/dialogs.tsx";
var statusColor = {
	Applied: "bg-lilac text-violet",
	"Under Review": "bg-butter",
	Shortlisted: "bg-mint text-primary-foreground",
	"Interview Scheduled": "bg-blush",
	Selected: "bg-success text-primary-foreground",
	Rejected: "bg-destructive text-destructive-foreground"
};
function StatusBadge({ status }) {
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
		className: `rounded-full px-2 py-0.5 text-[10px] font-semibold ${statusColor[status]}`,
		children: status
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 45,
		columnNumber: 5
	}, this);
}
function JobDialog({ jobId, open, onOpenChange }) {
	const job = jobs.find((j) => j.id === jobId);
	const app = usePathfinder((s) => s.applications.find((a) => a.jobId === jobId));
	const [confirm, setConfirm] = (0, import_react.useState)(false);
	const [note, setNote] = (0, import_react.useState)("");
	const [showApp, setShowApp] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!open) {
			setConfirm(false);
			setNote("");
		}
	}, [open]);
	if (!job) return null;
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(import_jsx_dev_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Dialog, {
		open: open && !showApp,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogContent, {
			className: "max-h-[90vh] overflow-y-auto rounded-2xl bg-card",
			children: !confirm ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(import_jsx_dev_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "flex items-center gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
						className: `flex h-11 w-11 items-center justify-center rounded-xl ${job.color}`,
						children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Building2, { className: "h-5 w-5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 76,
							columnNumber: 21
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 73,
						columnNumber: 19
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "text-left",
						children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogTitle, { children: job.title }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 79,
							columnNumber: 21
						}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogDescription, { children: [job.company, " · Sample listing"] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 80,
							columnNumber: 21
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 78,
						columnNumber: 19
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 72,
					columnNumber: 17
				}, this) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 71,
					columnNumber: 15
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "flex flex-wrap gap-3 text-xs text-muted-foreground",
					children: [
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
							className: "flex items-center gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(MapPin, { className: "h-3 w-3" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 86,
								columnNumber: 19
							}, this), job.location]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 85,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
							className: "flex items-center gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(IndianRupee, { className: "h-3 w-3" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 90,
								columnNumber: 19
							}, this), job.salary.replace("₹", "")]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 89,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
							className: "flex items-center gap-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Clock, { className: "h-3 w-3" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 94,
									columnNumber: 19
								}, this),
								job.type,
								" · ",
								job.posted
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 93,
							columnNumber: 17
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 84,
					columnNumber: 15
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Section, {
					title: "Job description",
					children: job.description
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 98,
					columnNumber: 15
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Section, {
					title: "Required skills",
					children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "flex flex-wrap gap-1.5",
						children: job.tags.map((t) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
							className: "rounded-full bg-muted px-2 py-0.5 text-[11px]",
							children: t
						}, t, false, {
							fileName: _jsxFileName,
							lineNumber: 102,
							columnNumber: 21
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 100,
						columnNumber: 17
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 99,
					columnNumber: 15
				}, this),
				(() => {
					const userSkills = app ? {} : window?.__lastSkills || {};
					const jobSkillScores = job.skills.map((s) => ({
						name: s,
						score: userSkills[s] ?? (s === "Frontend" ? 60 : s === "React" ? 48 : s === "Visual Design" ? 94 : 35)
					}));
					const matched = jobSkillScores.filter((x) => x.score >= 50);
					const gaps = jobSkillScores.filter((x) => x.score < 50);
					const calcMatch = Math.round(jobSkillScores.reduce((a, b) => a + b.score, 0) / (jobSkillScores.length || 1));
					return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "rounded-xl border bg-muted/40 p-3 text-xs space-y-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "flex items-center justify-between font-semibold",
								children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
									className: "flex items-center gap-1.5 text-violet",
									children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Sparkles, { className: "h-3.5 w-3.5" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 129,
										columnNumber: 25
									}, this), "Skill Suitability Analysis"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 128,
									columnNumber: 23
								}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("b", {
									className: "text-success",
									children: [calcMatch, "% match"]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 132,
									columnNumber: 23
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 127,
								columnNumber: 21
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
								className: "flex flex-wrap gap-1.5",
								children: jobSkillScores.map((s) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
									className: `rounded-full px-2 py-0.5 text-[10px] font-medium ${s.score >= 50 ? "bg-mint/40 text-primary-foreground" : "bg-orange/20 text-orange"}`,
									children: [
										s.name,
										": ",
										s.score,
										"%"
									]
								}, s.name, true, {
									fileName: _jsxFileName,
									lineNumber: 136,
									columnNumber: 25
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 134,
								columnNumber: 21
							}, this),
							/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
								className: "text-[11px] text-muted-foreground",
								children: [matched.length > 0 ? `Strong fit in ${matched.map((m) => m.name).join(", ")}.` : "Foundational match.", gaps.length > 0 ? ` Focus on ${gaps.map((g) => g.name).join(", ")} before technical rounds.` : " Ready for technical interviews."]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 144,
								columnNumber: 21
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 126,
						columnNumber: 19
					}, this);
				})(),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Section, {
					title: "Eligibility",
					children: job.eligibility
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 156,
					columnNumber: 15
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Section, {
					title: "Application details",
					children: job.apply
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 157,
					columnNumber: 15
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogFooter, {
					className: "gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Button, {
						variant: "outline",
						onClick: () => actions.toggleSave(job.id),
						children: "Save job"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 159,
						columnNumber: 17
					}, this), app ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Button, {
						onClick: () => setShowApp(true),
						children: ["View application · ", app.status]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 163,
						columnNumber: 19
					}, this) : /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Button, {
						onClick: () => setConfirm(true),
						children: "Apply"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 165,
						columnNumber: 19
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 158,
					columnNumber: 15
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 70,
				columnNumber: 13
			}, this) : /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(import_jsx_dev_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogTitle, { children: "Confirm application" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 172,
					columnNumber: 17
				}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogDescription, { children: [
					"Apply to ",
					job.title,
					" at ",
					job.company,
					"? This is a demo — no real employer receives it."
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 173,
					columnNumber: 17
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 171,
					columnNumber: 15
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("label", {
					className: "text-xs font-semibold",
					children: ["Note for recruiter (optional)", /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("textarea", {
						value: note,
						onChange: (e) => setNote(e.target.value),
						rows: 3,
						className: "mt-1 w-full rounded-xl border bg-background p-2 text-sm font-normal outline-none",
						placeholder: "Why you're a great fit…"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 180,
						columnNumber: 17
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 178,
					columnNumber: 15
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogFooter, {
					className: "gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Button, {
						variant: "outline",
						onClick: () => setConfirm(false),
						children: "Back"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 189,
						columnNumber: 17
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Button, {
						onClick: () => {
							actions.apply(job.id, note || void 0);
							toast.success(`Applied to ${job.title}`, { description: "Status: Applied. Track it under My applications." });
							setConfirm(false);
							setShowApp(true);
						},
						children: "Confirm & apply"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 192,
						columnNumber: 17
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 188,
					columnNumber: 15
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 170,
				columnNumber: 13
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 68,
			columnNumber: 9
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 67,
		columnNumber: 7
	}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(ApplicationDialog, {
		jobId: job.id,
		open: open && showApp,
		onOpenChange: (o) => {
			setShowApp(o);
			if (!o) onOpenChange(false);
		}
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 209,
		columnNumber: 7
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 66,
		columnNumber: 5
	}, this);
}
function Section({ title, children }) {
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
		className: "mb-1 text-xs font-semibold",
		children: title
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 224,
		columnNumber: 7
	}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
		className: "text-sm text-muted-foreground",
		children
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 225,
		columnNumber: 7
	}, this)] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 223,
		columnNumber: 5
	}, this);
}
function ApplicationDialog({ jobId, open, onOpenChange }) {
	const app = usePathfinder((s) => s.applications.find((a) => a.jobId === jobId));
	const job = jobs.find((j) => j.id === jobId);
	const [iv, setIv] = (0, import_react.useState)({
		date: "",
		time: "",
		mode: "Video call",
		details: ""
	});
	const [onb, setOnb] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		if (app?.interview) setIv(app.interview);
		setOnb(app?.onboarding ?? "");
	}, [app?.jobId, open]);
	if (!job || !app) return null;
	const idx = APP_STATUSES.indexOf(app.status);
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogContent, {
			className: "max-h-[90vh] overflow-y-auto rounded-2xl bg-card",
			children: [
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogTitle, { children: [
					job.title,
					" · ",
					job.company
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 250,
					columnNumber: 11
				}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogDescription, { children: [
					"Applied ",
					new Date(app.appliedAt).toLocaleDateString(),
					" · Demo tracker — update the status yourself when you hear back."
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 253,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 249,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("ol", {
					className: "flex flex-wrap gap-1.5 text-[10px]",
					children: APP_STATUSES.map((s, i) => {
						const reached = app.status === s || i < idx && s !== "Rejected" && app.status !== "Rejected" || app.status === "Rejected" && i < 4 && app.history.some((h) => h.status === s);
						return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("li", {
							className: `rounded-full px-2 py-0.5 ${reached ? statusColor[s] : "bg-muted text-muted-foreground"}`,
							children: s
						}, s, false, {
							fileName: _jsxFileName,
							lineNumber: 265,
							columnNumber: 15
						}, this);
					})
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 258,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("label", {
					className: "text-xs font-semibold",
					children: ["Update status", /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("select", {
						value: app.status,
						onChange: (e) => {
							actions.updateApplication(app.jobId, { status: e.target.value });
							toast(`Status updated: ${e.target.value}`);
						},
						className: "mt-1 w-full rounded-xl border bg-background p-2 text-sm font-normal",
						children: APP_STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", { children: s }, s, false, {
							fileName: _jsxFileName,
							lineNumber: 285,
							columnNumber: 15
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 276,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 274,
					columnNumber: 9
				}, this),
				app.status === "Interview Scheduled" && /* @__PURE__ */ (void 0)("div", {
					className: "space-y-2 rounded-xl bg-muted p-3",
					children: [
						/* @__PURE__ */ (void 0)("p", {
							className: "flex items-center gap-1 text-xs font-semibold",
							children: [/* @__PURE__ */ (void 0)(CalendarDays, { className: "h-3.5 w-3.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 292,
								columnNumber: 15
							}, this), "Interview details"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 291,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ (void 0)("div", {
							className: "grid grid-cols-2 gap-2",
							children: [/* @__PURE__ */ (void 0)("input", {
								type: "date",
								"aria-label": "Interview date",
								value: iv.date,
								onChange: (e) => setIv({
									...iv,
									date: e.target.value
								}),
								className: "rounded-lg border bg-background p-1.5 text-sm"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 296,
								columnNumber: 15
							}, this), /* @__PURE__ */ (void 0)("input", {
								type: "time",
								"aria-label": "Interview time",
								value: iv.time,
								onChange: (e) => setIv({
									...iv,
									time: e.target.value
								}),
								className: "rounded-lg border bg-background p-1.5 text-sm"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 303,
								columnNumber: 15
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 295,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ (void 0)("select", {
							"aria-label": "Interview mode",
							value: iv.mode,
							onChange: (e) => setIv({
								...iv,
								mode: e.target.value
							}),
							className: "w-full rounded-lg border bg-background p-1.5 text-sm",
							children: [
								"Video call",
								"Phone",
								"In person"
							].map((m) => /* @__PURE__ */ (void 0)("option", { children: m }, m, false, {
								fileName: _jsxFileName,
								lineNumber: 318,
								columnNumber: 17
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 311,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ (void 0)("input", {
							"aria-label": "Interview notes",
							placeholder: "Link, address or interviewer name",
							value: iv.details,
							onChange: (e) => setIv({
								...iv,
								details: e.target.value
							}),
							className: "w-full rounded-lg border bg-background p-1.5 text-sm"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 321,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ (void 0)(Button, {
							size: "sm",
							onClick: () => {
								actions.updateApplication(app.jobId, { interview: iv });
								toast.success("Interview details saved");
							},
							children: "Save interview"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 328,
							columnNumber: 13
						}, this),
						app.interview?.date && /* @__PURE__ */ (void 0)("p", {
							className: "text-xs text-muted-foreground",
							children: [
								"Saved: ",
								app.interview.date,
								" ",
								app.interview.time,
								" · ",
								app.interview.mode,
								app.interview.details ? ` · ${app.interview.details}` : ""
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 338,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 290,
					columnNumber: 11
				}, this),
				app.status === "Selected" && /* @__PURE__ */ (void 0)("div", {
					className: "space-y-2 rounded-xl bg-muted p-3",
					children: [
						/* @__PURE__ */ (void 0)("p", {
							className: "text-xs font-semibold",
							children: "Onboarding & next steps"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 347,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ (void 0)("ul", {
							className: "list-disc pl-4 text-xs text-muted-foreground",
							children: [
								/* @__PURE__ */ (void 0)("li", { children: "Accept the offer letter by email" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 349,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ (void 0)("li", { children: "Submit ID and education documents" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 350,
									columnNumber: 15
								}, this),
								/* @__PURE__ */ (void 0)("li", { children: "Complete joining formalities before your start date" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 351,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 348,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ (void 0)("textarea", {
							"aria-label": "Onboarding notes",
							rows: 2,
							value: onb,
							onChange: (e) => setOnb(e.target.value),
							placeholder: "Add instructions you received…",
							className: "w-full rounded-lg border bg-background p-1.5 text-sm"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 353,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ (void 0)(Button, {
							size: "sm",
							onClick: () => {
								actions.updateApplication(app.jobId, { onboarding: onb });
								toast.success("Onboarding notes saved");
							},
							children: "Save notes"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 361,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 346,
					columnNumber: 11
				}, this),
				app.note && /* @__PURE__ */ (void 0)(Section, {
					title: "Your note",
					children: app.note
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 372,
					columnNumber: 22
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", {
					className: "mb-1 text-xs font-semibold",
					children: "History"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 374,
					columnNumber: 11
				}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("ul", {
					className: "space-y-1 text-xs text-muted-foreground",
					children: app.history.map((h, i) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("li", { children: [
						new Date(h.at).toLocaleString(),
						" — ",
						h.status
					] }, i, true, {
						fileName: _jsxFileName,
						lineNumber: 377,
						columnNumber: 15
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 375,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 373,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogFooter, {
					className: "gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Button, {
						variant: "outline",
						onClick: () => {
							actions.withdraw(app.jobId);
							toast("Application withdrawn");
							onOpenChange(false);
						},
						children: "Withdraw"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 384,
						columnNumber: 11
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Button, {
						onClick: () => onOpenChange(false),
						children: "Done"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 394,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 383,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 248,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 247,
		columnNumber: 5
	}, this);
}
function CourseDialog({ courseId, reason, open, onOpenChange }) {
	const course = courseId ? courseById(courseId) : void 0;
	const progress = usePathfinder((s) => courseId ? s.enrolled[courseId] : void 0);
	const inList = usePathfinder((s) => courseId ? s.learningList.includes(courseId) : false);
	if (!course) return null;
	const enrolled = progress !== void 0;
	const step = Math.ceil(100 / (course.lessons || 10));
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogContent, {
			className: "max-w-2xl max-h-[90vh] overflow-y-auto rounded-3xl border-border bg-card p-6 shadow-soft",
			children: [
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogHeader, {
					className: "text-left",
					children: [
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "flex flex-wrap items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
									className: "rounded-full bg-lilac/50 px-2.5 py-0.5 text-[10px] font-semibold text-violet",
									children: course.stream || "General"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 420,
									columnNumber: 13
								}, this),
								course.provider && /* @__PURE__ */ (void 0)("span", {
									className: "rounded-full bg-muted px-2.5 py-0.5 text-[10px] font-medium text-foreground",
									children: course.provider
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 424,
									columnNumber: 15
								}, this),
								course.pricing && /* @__PURE__ */ (void 0)("span", {
									className: "rounded-full bg-mint/50 px-2.5 py-0.5 text-[10px] font-bold text-success",
									children: course.pricing
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 429,
									columnNumber: 15
								}, this)
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 419,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogTitle, {
							className: "mt-2 flex items-center gap-2 text-xl font-bold",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(BookOpen, { className: "h-5 w-5 text-violet" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 435,
								columnNumber: 13
							}, this), course.title]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 434,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogDescription, {
							className: "text-xs leading-relaxed text-muted-foreground",
							children: course.desc
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 438,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 418,
					columnNumber: 9
				}, this),
				course.isMedical && /* @__PURE__ */ (void 0)("div", {
					className: "rounded-2xl border border-destructive/20 bg-destructive/10 p-3.5 text-xs text-destructive",
					children: /* @__PURE__ */ (void 0)("div", {
						className: "flex items-start gap-2",
						children: [/* @__PURE__ */ (void 0)(ShieldAlert, { className: "h-4 w-4 shrink-0 mt-0.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 447,
							columnNumber: 15
						}, this), /* @__PURE__ */ (void 0)("div", { children: [/* @__PURE__ */ (void 0)("p", {
							className: "font-semibold",
							children: "Academic & Educational Resource Notice"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 449,
							columnNumber: 17
						}, this), /* @__PURE__ */ (void 0)("p", {
							className: "mt-1 text-[11px] leading-relaxed text-destructive/90",
							children: [
								"This course is designed exclusively for educational, theoretical, and academic enrichment. It does ",
								/* @__PURE__ */ (void 0)("strong", { children: "NOT" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 452,
									columnNumber: 39
								}, this),
								" confer clinical qualifications, healthcare credentials, medical licensing, or legal authority to diagnose or treat patients."
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 450,
							columnNumber: 17
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 448,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 446,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 445,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
					className: "grid grid-cols-2 gap-2 sm:grid-cols-4 text-center text-xs",
					children: [
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "rounded-xl bg-muted/60 p-2",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
								className: "block text-[10px] text-muted-foreground",
								children: "Duration"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 464,
								columnNumber: 13
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("b", {
								className: "text-foreground",
								children: course.duration
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 465,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 463,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "rounded-xl bg-muted/60 p-2",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
								className: "block text-[10px] text-muted-foreground",
								children: "Lessons"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 468,
								columnNumber: 13
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("b", {
								className: "text-foreground",
								children: [course.lessons, " lessons"]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 469,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 467,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "rounded-xl bg-muted/60 p-2",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
								className: "block text-[10px] text-muted-foreground",
								children: "Difficulty"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 472,
								columnNumber: 13
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("b", {
								className: "text-foreground",
								children: course.level
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 473,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 471,
							columnNumber: 11
						}, this),
						/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
							className: "rounded-xl bg-muted/60 p-2",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
								className: "block text-[10px] text-muted-foreground",
								children: "Format"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 476,
								columnNumber: 13
							}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("b", {
								className: "truncate text-foreground text-[11px]",
								children: course.format || "Structured"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 477,
								columnNumber: 13
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 475,
							columnNumber: 11
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 462,
					columnNumber: 9
				}, this),
				course.educationLevels && course.educationLevels.length > 0 && /* @__PURE__ */ (void 0)("div", {
					className: "space-y-1.5",
					children: [/* @__PURE__ */ (void 0)("p", {
						className: "flex items-center gap-1.5 text-xs font-semibold text-foreground",
						children: [/* @__PURE__ */ (void 0)(GraduationCap, { className: "h-3.5 w-3.5 text-violet" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 485,
							columnNumber: 15
						}, this), "Target Education Levels"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 484,
						columnNumber: 13
					}, this), /* @__PURE__ */ (void 0)("div", {
						className: "flex flex-wrap gap-1.5",
						children: course.educationLevels.map((lvl) => /* @__PURE__ */ (void 0)("span", {
							className: "rounded-full bg-butter/60 px-2.5 py-0.5 text-[10px] font-medium text-foreground",
							children: lvl
						}, lvl, false, {
							fileName: _jsxFileName,
							lineNumber: 490,
							columnNumber: 17
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 488,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 483,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Section, {
					title: "Skills Covered & Competencies",
					children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "flex flex-wrap gap-1.5 pt-1",
						children: course.skills.map((s) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
							className: "rounded-full bg-lilac/60 px-2.5 py-0.5 text-[11px] font-medium text-foreground",
							children: s
						}, s, false, {
							fileName: _jsxFileName,
							lineNumber: 505,
							columnNumber: 15
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 503,
						columnNumber: 11
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 502,
					columnNumber: 9
				}, this),
				course.syllabus && course.syllabus.length > 0 && /* @__PURE__ */ (void 0)(Section, {
					title: "Syllabus & Curriculum Modules",
					children: /* @__PURE__ */ (void 0)("ol", {
						className: "mt-1 space-y-1.5",
						children: course.syllabus.map((item, idx) => /* @__PURE__ */ (void 0)("li", {
							className: "flex items-center gap-2 rounded-xl border border-border/70 bg-background/50 px-3 py-2 text-xs text-foreground",
							children: [/* @__PURE__ */ (void 0)("span", {
								className: "grid h-5 w-5 shrink-0 place-items-center rounded-full bg-muted text-[10px] font-bold text-muted-foreground",
								children: idx + 1
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 524,
								columnNumber: 19
							}, this), /* @__PURE__ */ (void 0)("span", {
								className: "min-w-0 flex-1",
								children: item
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 527,
								columnNumber: 19
							}, this)]
						}, idx, true, {
							fileName: _jsxFileName,
							lineNumber: 520,
							columnNumber: 17
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 518,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 517,
					columnNumber: 11
				}, this),
				reason && /* @__PURE__ */ (void 0)("div", {
					className: "rounded-2xl border border-violet/20 bg-lilac/30 p-3 text-xs text-violet",
					children: /* @__PURE__ */ (void 0)("div", {
						className: "flex items-start gap-2",
						children: [/* @__PURE__ */ (void 0)(Sparkles, { className: "h-4 w-4 shrink-0 mt-0.5 text-violet" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 537,
							columnNumber: 15
						}, this), /* @__PURE__ */ (void 0)("div", { children: [/* @__PURE__ */ (void 0)("p", {
							className: "font-semibold",
							children: "Why this is recommended for you"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 539,
							columnNumber: 17
						}, this), /* @__PURE__ */ (void 0)("p", {
							className: "mt-0.5 text-[11px] leading-relaxed text-muted-foreground",
							children: reason
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 540,
							columnNumber: 17
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 538,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 536,
						columnNumber: 13
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 535,
					columnNumber: 11
				}, this),
				enrolled && /* @__PURE__ */ (void 0)("div", {
					className: "rounded-2xl border border-border/70 bg-card p-3.5 space-y-1.5",
					children: [/* @__PURE__ */ (void 0)("div", {
						className: "flex justify-between text-xs",
						children: [/* @__PURE__ */ (void 0)("span", {
							className: "font-semibold text-foreground",
							children: "Learning Progress"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 549,
							columnNumber: 15
						}, this), /* @__PURE__ */ (void 0)("span", {
							className: "font-bold text-foreground",
							children: [progress, "%"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 550,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 548,
						columnNumber: 13
					}, this), /* @__PURE__ */ (void 0)("div", {
						className: "h-2 w-full overflow-hidden rounded-full bg-muted",
						children: /* @__PURE__ */ (void 0)("div", {
							className: "h-full rounded-full bg-mint transition-all",
							style: { width: `${progress}%` }
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 553,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 552,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 547,
					columnNumber: 11
				}, this),
				course.url && /* @__PURE__ */ (void 0)("div", {
					className: "flex items-center justify-between rounded-2xl bg-muted/40 p-3 text-xs",
					children: [/* @__PURE__ */ (void 0)("div", {
						className: "min-w-0 flex-1",
						children: [/* @__PURE__ */ (void 0)("p", {
							className: "font-semibold text-foreground",
							children: "Verified Direct Course Platform"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 564,
							columnNumber: 15
						}, this), /* @__PURE__ */ (void 0)("p", {
							className: "truncate text-[11px] text-muted-foreground",
							children: course.url
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 565,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 563,
						columnNumber: 13
					}, this), /* @__PURE__ */ (void 0)("a", {
						href: course.url,
						target: "_blank",
						rel: "noopener noreferrer",
						className: "ml-3 inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-3 py-1.5 text-xs font-semibold text-foreground transition hover:bg-muted",
						children: [/* @__PURE__ */ (void 0)("span", { children: "Visit Platform" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 573,
							columnNumber: 15
						}, this), /* @__PURE__ */ (void 0)(ExternalLink, { className: "h-3.5 w-3.5" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 574,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 567,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 562,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogFooter, {
					className: "gap-2 sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "flex items-center gap-2",
						children: [!enrolled && !inList && /* @__PURE__ */ (void 0)(Button, {
							variant: "outline",
							size: "sm",
							onClick: () => {
								actions.addToList(course.id);
								toast.success("Added to your learning wishlist");
							},
							children: "Add to learning list"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 582,
							columnNumber: 15
						}, this), !enrolled && inList && /* @__PURE__ */ (void 0)(Button, {
							variant: "outline",
							size: "sm",
							onClick: () => {
								actions.removeFromList(course.id);
								toast("Removed from learning list");
							},
							children: "Remove from list"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 594,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 580,
						columnNumber: 11
					}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", {
						className: "flex items-center gap-2",
						children: !enrolled ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Button, {
							onClick: () => {
								actions.enroll(course.id);
								toast.success(`Enrolled in ${course.title}`, { description: "Track your progress under Ongoing courses." });
							},
							children: "Enroll Now"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 609,
							columnNumber: 15
						}, this) : progress < 100 ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Button, {
							onClick: () => {
								actions.progressCourse(course.id, step, course.skills, 1);
								if (progress + step >= 100) toast.success(`Course completed: ${course.title}`, { description: `Skills improved: ${course.skills.join(", ")}` });
								else toast.success("Lesson completed!");
							},
							children: [
								"Complete next lesson (+",
								step,
								"%)"
							]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 620,
							columnNumber: 15
						}, this) : /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", {
							className: "flex items-center gap-1 text-sm font-semibold text-success",
							children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(CircleCheck, { className: "h-4 w-4" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 634,
								columnNumber: 17
							}, this), "Course Completed"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 633,
							columnNumber: 15
						}, this)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 607,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 579,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 417,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 416,
		columnNumber: 5
	}, this);
}
function MockTestDialog({ open, onOpenChange, initialSubject }) {
	const subjects = Object.keys(testBank);
	const [subject, setSubject] = (0, import_react.useState)(null);
	const [i, setI] = (0, import_react.useState)(0);
	const [answers, setAnswers] = (0, import_react.useState)([]);
	const [done, setDone] = (0, import_react.useState)(false);
	const [left, setLeft] = (0, import_react.useState)(0);
	const history = usePathfinder((s) => s.tests);
	const bank = subject ? testBank[subject] : null;
	(0, import_react.useEffect)(() => {
		if (open) {
			setSubject(initialSubject ?? null);
			setDone(false);
			setI(0);
		}
	}, [open, initialSubject]);
	(0, import_react.useEffect)(() => {
		if (bank) {
			setAnswers(bank.questions.map(() => null));
			setLeft(bank.questions.length * 30);
			setI(0);
			setDone(false);
		}
	}, [subject]);
	(0, import_react.useEffect)(() => {
		if (!open || !bank || done) return;
		if (left <= 0) {
			submit();
			return;
		}
		const t = setTimeout(() => setLeft((l) => l - 1), 1e3);
		return () => clearTimeout(t);
	}, [
		left,
		open,
		done,
		bank
	]);
	const score = bank ? bank.questions.reduce((a, q, k) => a + (answers[k] === q.answer ? 1 : 0), 0) : 0;
	function submit() {
		if (!bank || !subject || done) return;
		setDone(true);
		actions.recordTest({
			subject,
			score,
			total: bank.questions.length
		}, bank.skills);
		toast.success(`Test submitted: ${score}/${bank.questions.length}`, { description: `${bank.skills.join(", ")} progress updated.` });
	}
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogContent, {
			className: "max-h-[90vh] overflow-y-auto rounded-2xl bg-card",
			children: [
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogTitle, { children: ["Mock test", subject ? ` · ${subject}` : ""] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 700,
					columnNumber: 11
				}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogDescription, { children: !subject ? "Choose a subject to start." : done ? "Results and explanations" : `Question ${i + 1} of ${bank.questions.length}` }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 701,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 699,
					columnNumber: 9
				}, this),
				!subject && /* @__PURE__ */ (void 0)(import_jsx_dev_runtime.Fragment, { children: [/* @__PURE__ */ (void 0)("div", {
					className: "grid grid-cols-2 gap-2",
					children: subjects.map((s) => /* @__PURE__ */ (void 0)(Button, {
						variant: "outline",
						onClick: () => setSubject(s),
						children: s
					}, s, false, {
						fileName: _jsxFileName,
						lineNumber: 713,
						columnNumber: 17
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 711,
					columnNumber: 13
				}, this), history.length > 0 && /* @__PURE__ */ (void 0)("div", { children: [/* @__PURE__ */ (void 0)("p", {
					className: "mb-1 text-xs font-semibold",
					children: "Test history"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 720,
					columnNumber: 17
				}, this), /* @__PURE__ */ (void 0)("ul", {
					className: "space-y-1 text-xs text-muted-foreground",
					children: history.slice(0, 6).map((h, k) => /* @__PURE__ */ (void 0)("li", { children: [
						h.subject,
						" — ",
						h.score,
						"/",
						h.total,
						" · ",
						new Date(h.at).toLocaleDateString()
					] }, k, true, {
						fileName: _jsxFileName,
						lineNumber: 723,
						columnNumber: 21
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 721,
					columnNumber: 17
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 719,
					columnNumber: 15
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 710,
					columnNumber: 11
				}, this),
				bank && !done && /* @__PURE__ */ (void 0)(import_jsx_dev_runtime.Fragment, { children: [
					/* @__PURE__ */ (void 0)("p", {
						className: "flex items-center gap-1 text-xs text-orange",
						children: [
							/* @__PURE__ */ (void 0)(Timer, { className: "h-3.5 w-3.5" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 735,
								columnNumber: 15
							}, this),
							Math.floor(left / 60),
							":",
							String(left % 60).padStart(2, "0"),
							" left"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 734,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ (void 0)("p", {
						className: "text-sm font-semibold",
						children: bank.questions[i].q
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 738,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ (void 0)("div", {
						className: "space-y-2",
						children: bank.questions[i].options.map((o, k) => /* @__PURE__ */ (void 0)("button", {
							onClick: () => setAnswers((a) => a.map((v, j) => j === i ? k : v)),
							className: `w-full rounded-xl border p-2 text-left text-sm ${answers[i] === k ? "border-violet bg-lilac" : "bg-card hover:bg-muted"}`,
							children: o
						}, k, false, {
							fileName: _jsxFileName,
							lineNumber: 741,
							columnNumber: 17
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 739,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ (void 0)(DialogFooter, {
						className: "gap-2",
						children: [/* @__PURE__ */ (void 0)(Button, {
							variant: "outline",
							disabled: i === 0,
							onClick: () => setI(i - 1),
							children: "Previous"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 751,
							columnNumber: 15
						}, this), i < bank.questions.length - 1 ? /* @__PURE__ */ (void 0)(Button, {
							onClick: () => setI(i + 1),
							children: "Next"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 755,
							columnNumber: 17
						}, this) : /* @__PURE__ */ (void 0)(Button, {
							onClick: submit,
							children: "Submit test"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 757,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 750,
						columnNumber: 13
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 733,
					columnNumber: 11
				}, this),
				bank && done && /* @__PURE__ */ (void 0)(import_jsx_dev_runtime.Fragment, { children: [
					/* @__PURE__ */ (void 0)("p", {
						className: "text-3xl font-bold",
						children: [
							score,
							"/",
							bank.questions.length,
							" ",
							/* @__PURE__ */ (void 0)("span", {
								className: "text-sm font-normal text-muted-foreground",
								children: [
									"(",
									Math.round(score / bank.questions.length * 100),
									"%)"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 766,
								columnNumber: 15
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 764,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ (void 0)("ul", {
						className: "space-y-3",
						children: bank.questions.map((q, k) => {
							const ok = answers[k] === q.answer;
							return /* @__PURE__ */ (void 0)("li", {
								className: "rounded-xl bg-muted p-3 text-xs",
								children: [
									/* @__PURE__ */ (void 0)("p", {
										className: "flex gap-1.5 font-semibold",
										children: [ok ? /* @__PURE__ */ (void 0)(CircleCheck, { className: "h-4 w-4 shrink-0 text-success" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 777,
											columnNumber: 25
										}, this) : /* @__PURE__ */ (void 0)(CircleX, { className: "h-4 w-4 shrink-0 text-destructive" }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 779,
											columnNumber: 25
										}, this), q.q]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 775,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ (void 0)("p", {
										className: "mt-1",
										children: [
											"Correct: ",
											/* @__PURE__ */ (void 0)("b", { children: q.options[q.answer] }, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 784,
												columnNumber: 32
											}, this),
											!ok && answers[k] != null ? ` · You chose: ${q.options[answers[k]]}` : !ok ? " · Not answered" : ""
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 783,
										columnNumber: 21
									}, this),
									/* @__PURE__ */ (void 0)("p", {
										className: "mt-1 text-muted-foreground",
										children: q.explain
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 791,
										columnNumber: 21
									}, this)
								]
							}, k, true, {
								fileName: _jsxFileName,
								lineNumber: 774,
								columnNumber: 19
							}, this);
						})
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 770,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ (void 0)(DialogFooter, {
						className: "gap-2",
						children: [/* @__PURE__ */ (void 0)(Button, {
							variant: "outline",
							onClick: () => setSubject(null),
							children: "Take another test"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 797,
							columnNumber: 15
						}, this), /* @__PURE__ */ (void 0)(Button, {
							onClick: () => onOpenChange(false),
							children: "Close"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 800,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 796,
						columnNumber: 13
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 763,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 698,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 697,
		columnNumber: 5
	}, this);
}
function heuristic(answer) {
	const words = answer.trim().split(/\s+/).filter(Boolean).length;
	const star = [
		"situation",
		"task",
		"action",
		"result",
		"because",
		"example",
		"learned"
	].filter((w) => answer.toLowerCase().includes(w)).length;
	return {
		score: Math.min(100, Math.round(Math.min(words, 80) * .8 + star * 6)),
		text: words < 15 ? "Answer is quite short — add a concrete example and the result." : star >= 2 ? "Good structure with examples. Keep it concise and finish with the impact." : "Clear answer. Try the STAR method (Situation, Task, Action, Result) to add structure."
	};
}
function MockInterviewDialog({ open, onOpenChange }) {
	const goal = usePathfinder((s) => s.goal);
	const [role, setRole] = (0, import_react.useState)(goal);
	const [diff, setDiff] = (0, import_react.useState)("Medium");
	const [started, setStarted] = (0, import_react.useState)(false);
	const [i, setI] = (0, import_react.useState)(0);
	const [answer, setAnswer] = (0, import_react.useState)("");
	const [fb, setFb] = (0, import_react.useState)([]);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [listening, setListening] = (0, import_react.useState)(false);
	const recRef = (0, import_react.useRef)(null);
	const qs = (0, import_react.useMemo)(() => interviewBank[role]?.[diff] ?? [], [role, diff]);
	const finished = started && fb.length === qs.length && qs.length > 0;
	const saved = (0, import_react.useRef)(false);
	(0, import_react.useEffect)(() => {
		if (open) {
			setRole(Object.keys(interviewBank).includes(goal) ? goal : "Frontend Developer");
			setStarted(false);
			setI(0);
			setFb([]);
			setAnswer("");
			saved.current = false;
		}
	}, [open, goal]);
	(0, import_react.useEffect)(() => {
		if (finished && !saved.current) {
			saved.current = true;
			const avg = Math.round(fb.reduce((a, f) => a + f.score, 0) / fb.length);
			const avgBreakdown = {
				technical: Math.round(fb.reduce((a, f) => a + (f.breakdown?.technical ?? f.score), 0) / fb.length),
				problemSolving: Math.round(fb.reduce((a, f) => a + (f.breakdown?.problemSolving ?? f.score), 0) / fb.length),
				communication: Math.round(fb.reduce((a, f) => a + (f.breakdown?.communication ?? f.score), 0) / fb.length),
				relevance: Math.round(fb.reduce((a, f) => a + (f.breakdown?.relevance ?? f.score), 0) / fb.length),
				confidence: Math.round(fb.reduce((a, f) => a + (f.breakdown?.confidence ?? f.score), 0) / fb.length)
			};
			actions.recordDetailedInterview({
				id: "interview-" + Date.now(),
				role,
				difficulty: diff,
				score: avg,
				at: (/* @__PURE__ */ new Date()).toISOString(),
				breakdown: avgBreakdown,
				feedback: fb.map((f) => f.text).join(" "),
				strength: fb[0]?.strength || "Demonstrated clear technical domain concepts",
				improvement: fb[0]?.improvement || "Provide more concrete metrics and structure",
				recommendation: fb[0]?.recommendation || "Structure behavioral answers with the STAR method",
				questionsAnswers: fb.map((f) => ({
					q: f.q,
					a: f.a,
					score: f.score,
					text: f.text
				}))
			});
			toast.success(`Mock interview completed: ${avg}%`, { description: "Communication and role competencies updated in My Skills." });
		}
	}, [finished]);
	async function submitAnswer() {
		const q = qs[i];
		if (!answer.trim()) return;
		setLoading(true);
		let f = heuristic(answer);
		try {
			const r = await evaluateInterviewAnswerWithGemini({ data: {
				role,
				difficulty: diff,
				question: q,
				answer,
				questionIndex: i + 1,
				totalQuestions: qs.length
			} });
			if (r.ok && r.data) f = {
				score: r.data.score ?? f.score,
				text: r.data.feedback || f.text,
				breakdown: r.data.breakdown || {
					technical: 75,
					problemSolving: 70,
					communication: 75,
					relevance: 80,
					confidence: 75
				},
				strength: r.data.strength,
				improvement: r.data.improvement,
				recommendation: r.data.recommendation
			};
		} catch {}
		setFb((x) => [...x, {
			...f,
			q,
			a: answer
		}]);
		setAnswer("");
		setLoading(false);
	}
	function voice() {
		const W = window;
		const C = W.SpeechRecognition ?? W.webkitSpeechRecognition;
		if (!C) {
			toast.error("Voice input isn't supported in this browser. Please type your answer.");
			return;
		}
		if (listening) {
			recRef.current?.stop();
			return;
		}
		const r = new C();
		r.lang = "en-IN";
		r.interimResults = false;
		r.onresult = (e) => setAnswer((a) => `${a} ${e.results[0][0].transcript}`.trim());
		r.onend = () => setListening(false);
		r.onerror = () => setListening(false);
		recRef.current = r;
		setListening(true);
		r.start();
	}
	const avg = fb.length ? Math.round(fb.reduce((a, f) => a + f.score, 0) / fb.length) : 0;
	return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogContent, {
			className: "max-h-[90vh] overflow-y-auto rounded-2xl bg-card",
			children: [
				/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogTitle, { children: "Mock interview" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 975,
					columnNumber: 11
				}, this), /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DialogDescription, { children: !started ? "Pick a role and difficulty." : finished ? "Your performance summary" : `Question ${i + 1} of ${qs.length} · ${role} · ${diff}` }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 976,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 974,
					columnNumber: 9
				}, this),
				!started && /* @__PURE__ */ (void 0)(import_jsx_dev_runtime.Fragment, { children: [
					/* @__PURE__ */ (void 0)("label", {
						className: "text-xs font-semibold",
						children: ["Target role", /* @__PURE__ */ (void 0)("select", {
							value: role,
							onChange: (e) => setRole(e.target.value),
							className: "mt-1 w-full rounded-xl border bg-background p-2 text-sm font-normal",
							children: Object.keys(interviewBank).map((r) => /* @__PURE__ */ (void 0)("option", { children: r }, r, false, {
								fileName: _jsxFileName,
								lineNumber: 994,
								columnNumber: 19
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 988,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 986,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ (void 0)("div", {
						className: "flex gap-2",
						children: [
							"Easy",
							"Medium",
							"Hard"
						].map((d) => /* @__PURE__ */ (void 0)(Button, {
							size: "sm",
							variant: "outline",
							onClick: () => setDiff(d),
							className: diff === d ? "bg-lilac text-violet" : "",
							children: d
						}, d, false, {
							fileName: _jsxFileName,
							lineNumber: 1e3,
							columnNumber: 17
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 998,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ (void 0)(DialogFooter, { children: /* @__PURE__ */ (void 0)(Button, {
						onClick: () => setStarted(true),
						children: "Start interview"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1012,
						columnNumber: 15
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1011,
						columnNumber: 13
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 985,
					columnNumber: 11
				}, this),
				started && !finished && /* @__PURE__ */ (void 0)(import_jsx_dev_runtime.Fragment, { children: [fb[i - 1] && /* @__PURE__ */ (void 0)("div", {
					className: "rounded-xl bg-muted p-3 text-xs",
					children: [/* @__PURE__ */ (void 0)("p", {
						className: "font-semibold",
						children: [
							"Feedback on previous answer · ",
							fb[i - 1].score,
							"/100"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1020,
						columnNumber: 17
					}, this), /* @__PURE__ */ (void 0)("p", {
						className: "mt-1 text-muted-foreground",
						children: fb[i - 1].text
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1023,
						columnNumber: 17
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1019,
					columnNumber: 15
				}, this), fb.length === i ? /* @__PURE__ */ (void 0)(import_jsx_dev_runtime.Fragment, { children: [
					/* @__PURE__ */ (void 0)("p", {
						className: "text-sm font-semibold",
						children: qs[i]
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1028,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ (void 0)("textarea", {
						"aria-label": "Your answer",
						rows: 4,
						value: answer,
						onChange: (e) => setAnswer(e.target.value),
						placeholder: listening ? "Listening…" : "Type your answer or use the mic…",
						className: "w-full rounded-xl border bg-background p-2 text-sm outline-none"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1029,
						columnNumber: 17
					}, this),
					/* @__PURE__ */ (void 0)(DialogFooter, {
						className: "gap-2",
						children: [/* @__PURE__ */ (void 0)(Button, {
							variant: "outline",
							onClick: voice,
							className: listening ? "pulse-ring" : "",
							children: [/* @__PURE__ */ (void 0)(Mic, {}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1043,
								columnNumber: 21
							}, this), listening ? "Stop" : "Speak"]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 1038,
							columnNumber: 19
						}, this), /* @__PURE__ */ (void 0)(Button, {
							disabled: loading || !answer.trim(),
							onClick: submitAnswer,
							children: loading ? "Evaluating…" : "Submit answer"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1046,
							columnNumber: 19
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1037,
						columnNumber: 17
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1027,
					columnNumber: 15
				}, this) : /* @__PURE__ */ (void 0)(import_jsx_dev_runtime.Fragment, { children: [/* @__PURE__ */ (void 0)("div", {
					className: "rounded-xl bg-muted p-3 text-xs",
					children: [/* @__PURE__ */ (void 0)("p", {
						className: "font-semibold",
						children: [
							"Feedback · ",
							fb[i].score,
							"/100"
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1054,
						columnNumber: 19
					}, this), /* @__PURE__ */ (void 0)("p", {
						className: "mt-1 text-muted-foreground",
						children: fb[i].text
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1055,
						columnNumber: 19
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1053,
					columnNumber: 17
				}, this), /* @__PURE__ */ (void 0)(DialogFooter, { children: /* @__PURE__ */ (void 0)(Button, {
					onClick: () => setI(i + 1),
					children: i + 1 < qs.length ? "Next question" : "See summary"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 1058,
					columnNumber: 19
				}, this) }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 1057,
					columnNumber: 17
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1052,
					columnNumber: 15
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1017,
					columnNumber: 11
				}, this),
				finished && /* @__PURE__ */ (void 0)(import_jsx_dev_runtime.Fragment, { children: [
					/* @__PURE__ */ (void 0)("p", {
						className: "text-3xl font-bold text-interview-blue",
						children: [avg, "%"]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1068,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ (void 0)("p", {
						className: "text-xs text-muted-foreground",
						children: [
							avg >= 75 ? "Strong — you're interview-ready." : avg >= 50 ? "Good — a few areas to improve." : "Keep practising — add examples and structure.",
							" ",
							"Saved to your progress."
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1069,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ (void 0)("ul", {
						className: "space-y-2",
						children: fb.map((f, k) => /* @__PURE__ */ (void 0)("li", {
							className: "rounded-xl bg-muted p-3 text-xs",
							children: [/* @__PURE__ */ (void 0)("p", {
								className: "font-semibold",
								children: [
									f.q,
									" · ",
									f.score,
									"/100"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 1080,
								columnNumber: 19
							}, this), /* @__PURE__ */ (void 0)("p", {
								className: "mt-1 text-muted-foreground",
								children: f.text
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1083,
								columnNumber: 19
							}, this)]
						}, k, true, {
							fileName: _jsxFileName,
							lineNumber: 1079,
							columnNumber: 17
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 1077,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ (void 0)(DialogFooter, {
						className: "gap-2",
						children: [/* @__PURE__ */ (void 0)(Button, {
							variant: "outline",
							onClick: () => {
								setStarted(false);
								setI(0);
								setFb([]);
								saved.current = false;
							},
							children: "Try again"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1088,
							columnNumber: 15
						}, this), /* @__PURE__ */ (void 0)(Button, {
							asChild: true,
							children: /* @__PURE__ */ (void 0)(Link, {
								to: "/interviews",
								onClick: () => onOpenChange(false),
								children: "View interview report"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 1100,
								columnNumber: 17
							}, this)
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 1099,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 1087,
						columnNumber: 13
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 1067,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 973,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 972,
		columnNumber: 5
	}, this);
}
//#endregion
export { MockTestDialog as a, MockInterviewDialog as i, CourseDialog as n, StatusBadge as o, JobDialog as r, ApplicationDialog as t };
