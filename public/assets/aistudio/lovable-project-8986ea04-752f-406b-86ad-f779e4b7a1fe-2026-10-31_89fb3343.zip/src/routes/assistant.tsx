import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Mic, SendHorizontal, Sparkles, FileText, UserPen } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import blob from "@/assets/blob.png";

export const Route = createFileRoute("/assistant")({
  head: () => ({
    meta: [
      { title: "AI Career Assistant — Pathfinder" },
      { name: "description", content: "Talk to your AI career consultant about goals, skills and next steps." },
      { property: "og:title", content: "AI Career Assistant — Pathfinder" },
      { property: "og:description", content: "Voice-first AI career guidance." },
    ],
  }),
  component: Assistant,
});

const chips = ["Explore careers", "Skill gaps", "Mock interview", "Build roadmap", "Resume tips", "Internships"];

function Assistant() {
  const [listening, setListening] = useState(false);
  const [msgs, setMsgs] = useState([
    { me: false, t: "Hi Sneha! Want me to review your CV and suggest your next best step?" },
    { me: true, t: "Yes, I want to become a frontend developer." },
  ]);
  const [text, setText] = useState("");
  const send = (t: string) => {
    if (!t.trim()) return;
    setMsgs((m) => [...m, { me: true, t }, { me: false, t: "Great — tell me which skills you already have, and I'll map the gaps." }]);
    setText("");
  };
  return (
    <AppShell>
      <div className="relative mx-auto max-w-2xl overflow-hidden rounded-3xl border bg-card p-6">
        <img src={blob} alt="" width={816} height={816} className="pointer-events-none absolute -right-10 -top-10 w-40 opacity-80" />
        <h1 className="text-3xl font-bold leading-tight">Hello<br />Sneha</h1>
        <div className="mt-4 flex gap-2">
          <span className="flex items-center gap-1 rounded-full bg-lilac px-3 py-1 text-xs"><FileText className="h-3 w-3" />Course material</span>
          <span className="flex items-center gap-1 rounded-full bg-lilac px-3 py-1 text-xs"><UserPen className="h-3 w-3" />My profile</span>
        </div>
        <div className="mt-6 space-y-3">
          {msgs.map((m, i) => (
            <div key={i} className={`flex gap-2 ${m.me ? "justify-end" : ""}`}>
              {!m.me && <Sparkles className="mt-1 h-4 w-4 shrink-0 text-violet" />}
              <p className={`max-w-[75%] rounded-2xl px-4 py-2 text-sm ${m.me ? "bg-lilac" : ""}`}>{m.t}</p>
            </div>
          ))}
        </div>
        <p className="mt-6 text-center text-xs text-muted-foreground">Use tags for better assistance</p>
        <div className="mt-2 flex flex-wrap justify-center gap-2">
          {chips.map((c, i) => (
            <button key={c} onClick={() => send(c)} className={`rounded-full px-3 py-1 text-xs ${["bg-lilac", "bg-blush", "bg-butter"][i % 3]}`}>{c}</button>
          ))}
        </div>
        <div className="mt-5 flex items-center gap-2">
          <button
            onClick={() => setListening((l) => !l)}
            aria-label="Voice input"
            className={`grid h-11 w-11 shrink-0 place-items-center rounded-full bg-ink text-ink-foreground ${listening ? "pulse-ring" : ""}`}
          ><Mic className="h-5 w-5" /></button>
          <form onSubmit={(e) => { e.preventDefault(); send(text); }} className="ai-ring flex flex-1 items-center rounded-full px-4 py-2">
            <input value={text} onChange={(e) => setText(e.target.value)} placeholder={listening ? "Listening…" : "Ask me anything…"} className="flex-1 bg-transparent text-sm outline-none" />
            <button type="submit" aria-label="Send"><SendHorizontal className="h-4 w-4" /></button>
          </form>
        </div>
      </div>
    </AppShell>
  );
}
