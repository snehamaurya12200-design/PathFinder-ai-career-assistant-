import { useSyncExternalStore } from "react";

export type AppStatus = "Applied" | "Under Review" | "Shortlisted" | "Interview Scheduled" | "Selected" | "Rejected";
export const APP_STATUSES: AppStatus[] = ["Applied", "Under Review", "Shortlisted", "Interview Scheduled", "Selected", "Rejected"];

export type Application = {
  jobId: number;
  status: AppStatus;
  appliedAt: string;
  note?: string;
  history: { status: AppStatus; at: string }[];
  interview?: { date: string; time: string; mode: string; details: string };
  onboarding?: string;
};
export type TestResult = { subject: string; score: number; total: number; at: string };
export type InterviewResult = { role: string; difficulty: string; score: number; at: string };
export type ChatMsg = { me: boolean; t: string };

export type PathfinderState = {
  goal: string;
  skills: Record<string, number>;
  applications: Application[];
  savedJobs: number[];
  enrolled: Record<string, number>; // courseId -> progress 0-100
  learningList: string[];
  lessonsDone: number;
  hours: number;
  tests: TestResult[];
  interviews: InterviewResult[];
  connections: Record<number, "pending" | "connected">;
  events: number[];
  groups: string[];
  chat: ChatMsg[];
};

export const DEFAULT_SKILLS: Record<string, number> = {
  Frontend: 60, Communication: 12, "Data Structures": 27, JavaScript: 55, React: 48, TypeScript: 20,
  "Interaction Design": 75, "User Research": 85, "Content Strategy": 50, "Visual Design": 94,
  "Design Leadership": 40, "Product Thinking": 36,
};

export const initialState: PathfinderState = {
  goal: "Frontend Developer",
  skills: DEFAULT_SKILLS,
  applications: [],
  savedJobs: [],
  enrolled: { "react-pro": 35 },
  learningList: [],
  lessonsDone: 46,
  hours: 127,
  tests: [],
  interviews: [],
  connections: {},
  events: [],
  groups: [],
  chat: [
    { me: false, t: "Hi Sneha! Want me to review your CV and suggest your next best step?" },
    { me: true, t: "Yes, I want to become a frontend developer." },
  ],
};

const KEY = "pathfinder-state-v1";
let state: PathfinderState = initialState;
let hydrated = false;
const listeners = new Set<() => void>();

function hydrate() {
  if (hydrated || typeof window === "undefined") return;
  hydrated = true;
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) state = { ...initialState, ...JSON.parse(raw) };
  } catch { /* ignore */ }
}

export function getState() { hydrate(); return state; }

export function setState(fn: (s: PathfinderState) => Partial<PathfinderState>) {
  hydrate();
  state = { ...state, ...fn(state) };
  try { localStorage.setItem(KEY, JSON.stringify(state)); } catch { /* ignore */ }
  listeners.forEach((l) => l());
}

function subscribe(l: () => void) {
  listeners.add(l);
  // notify once after hydration on the client
  if (!hydrated) { hydrate(); queueMicrotask(l); }
  return () => listeners.delete(l);
}

export function usePathfinder<T>(sel: (s: PathfinderState) => T): T {
  return useSyncExternalStore(subscribe, () => sel(state), () => sel(initialState));
}

const clamp = (n: number) => Math.max(0, Math.min(100, Math.round(n)));
const now = () => new Date().toISOString();

/* ---------- actions ---------- */
export const actions = {
  setGoal: (goal: string) => setState(() => ({ goal })),
  setSkill: (name: string, v: number) => setState((s) => ({ skills: { ...s.skills, [name]: clamp(v) } })),
  removeSkill: (name: string) => setState((s) => { const k = { ...s.skills }; delete k[name]; return { skills: k }; }),
  boostSkills: (names: string[], by: number) =>
    setState((s) => {
      const k = { ...s.skills };
      names.forEach((n) => { k[n] = clamp((k[n] ?? 0) + by); });
      return { skills: k };
    }),
  toggleSave: (id: number) => setState((s) => ({ savedJobs: s.savedJobs.includes(id) ? s.savedJobs.filter((x) => x !== id) : [...s.savedJobs, id] })),
  apply: (jobId: number, note?: string) =>
    setState((s) => s.applications.some((a) => a.jobId === jobId) ? {} : ({
      applications: [...s.applications, { jobId, status: "Applied", appliedAt: now(), note, history: [{ status: "Applied", at: now() }] }],
    })),
  updateApplication: (jobId: number, patch: Partial<Application>) =>
    setState((s) => ({
      applications: s.applications.map((a) => {
        if (a.jobId !== jobId) return a;
        const history = patch.status && patch.status !== a.status ? [...a.history, { status: patch.status, at: now() }] : a.history;
        return { ...a, ...patch, history };
      }),
    })),
  withdraw: (jobId: number) => setState((s) => ({ applications: s.applications.filter((a) => a.jobId !== jobId) })),
  enroll: (id: string) => setState((s) => s.enrolled[id] !== undefined ? {} : ({ enrolled: { ...s.enrolled, [id]: 0 }, learningList: s.learningList.filter((x) => x !== id) })),
  addToList: (id: string) => setState((s) => s.learningList.includes(id) || s.enrolled[id] !== undefined ? {} : ({ learningList: [...s.learningList, id] })),
  removeFromList: (id: string) => setState((s) => ({ learningList: s.learningList.filter((x) => x !== id) })),
  progressCourse: (id: string, by: number, skills: string[], lessonHours: number) =>
    setState((s) => {
      const prev = s.enrolled[id] ?? 0;
      if (prev >= 100) return {};
      const next = clamp(prev + by);
      const k = { ...s.skills };
      const gain = next === 100 ? 8 : 2;
      skills.forEach((n) => { k[n] = clamp((k[n] ?? 0) + gain); });
      return { enrolled: { ...s.enrolled, [id]: next }, skills: k, lessonsDone: s.lessonsDone + 1, hours: s.hours + lessonHours };
    }),
  lessonComplete: () => setState((s) => ({ lessonsDone: s.lessonsDone + 1, hours: s.hours + 1 })),
  recordTest: (r: Omit<TestResult, "at">, skills: string[]) =>
    setState((s) => {
      const pct = r.score / r.total;
      const k = { ...s.skills };
      skills.forEach((n) => { const cur = k[n] ?? 0; k[n] = clamp(cur + (pct * 100 - cur) * 0.3); });
      return { tests: [{ ...r, at: now() }, ...s.tests], skills: k };
    }),
  recordInterview: (r: Omit<InterviewResult, "at">) =>
    setState((s) => ({ interviews: [{ ...r, at: now() }, ...s.interviews], skills: { ...s.skills, Communication: clamp((s.skills.Communication ?? 0) + (r.score >= 60 ? 6 : 2)) } })),
  connect: (id: number) => setState((s) => ({ connections: { ...s.connections, [id]: "pending" } })),
  acceptConnection: (id: number) => setState((s) => ({ connections: { ...s.connections, [id]: "connected" } })),
  removeConnection: (id: number) => setState((s) => { const c = { ...s.connections }; delete c[id]; return { connections: c }; }),
  toggleEvent: (id: number) => setState((s) => ({ events: s.events.includes(id) ? s.events.filter((x) => x !== id) : [...s.events, id] })),
  toggleGroup: (g: string) => setState((s) => ({ groups: s.groups.includes(g) ? s.groups.filter((x) => x !== g) : [...s.groups, g] })),
  setChat: (chat: ChatMsg[]) => setState(() => ({ chat })),
};

/** Career readiness: average of goal skills, nudged by activity. */
export function readiness(s: PathfinderState, goalSkills: string[]) {
  if (!goalSkills.length) return 0;
  const avg = goalSkills.reduce((a, n) => a + (s.skills[n] ?? 0), 0) / goalSkills.length;
  return clamp(avg);
}
