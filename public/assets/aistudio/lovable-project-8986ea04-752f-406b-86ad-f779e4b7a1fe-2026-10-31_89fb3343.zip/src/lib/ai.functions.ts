import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const Input = z.object({
  system: z.string().max(4000),
  messages: z.array(z.object({ role: z.enum(["user", "assistant"]), content: z.string().max(6000) })).max(40),
});

/** Calls Lovable AI Gateway (streamed SSE, consumed server-side) and returns the final text. */
export const askAI = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => Input.parse(d))
  .handler(async ({ data }) => {
    const key = process.env.LOVABLE_API_KEY;
    if (!key) return { ok: false as const, error: "AI is not configured." };
    const res = await fetch("https://ai.gateway.lovable.dev/v1/responses", {
      method: "POST",
      headers: { "Content-Type": "application/json", "Lovable-API-Key": key, "X-Lovable-AIG-SDK": "fetch" },
      body: JSON.stringify({
        model: "openai/gpt-6-astra",
        instructions: data.system,
        input: data.messages.map((m) => ({ role: m.role, content: m.content })),
        reasoning: { effort: "low" },
        store: false,
        stream: true,
      }),
    });
    if (!res.ok || !res.body) {
      let msg = `AI request failed (${res.status}).`;
      try { const j = await res.json(); msg = j?.error?.message ?? j?.message ?? msg; } catch { /* ignore */ }
      if (res.status === 402) msg = "AI credits have run out for this workspace. " + msg;
      if (res.status === 429) msg = "Too many requests — please wait a moment and try again.";
      return { ok: false as const, error: msg };
    }
    const reader = res.body.getReader();
    const dec = new TextDecoder();
    let buf = "", text = "";
    for (;;) {
      const { value, done } = await reader.read();
      if (done) break;
      buf += dec.decode(value, { stream: true });
      const lines = buf.split("\n");
      buf = lines.pop() ?? "";
      for (const line of lines) {
        if (!line.startsWith("data:")) continue;
        const payload = line.slice(5).trim();
        if (!payload || payload === "[DONE]") continue;
        try {
          const ev = JSON.parse(payload);
          if (ev.type === "response.output_text.delta") text += ev.delta ?? "";
          if (ev.type === "error" || ev.type === "response.failed") return { ok: false as const, error: ev.error?.message ?? ev.response?.error?.message ?? "AI error." };
        } catch { /* ignore partial */ }
      }
    }
    if (!text.trim()) return { ok: false as const, error: "The assistant could not answer that request." };
    return { ok: true as const, text: text.trim() };
  });
