// Demo/sample data for the Pathfinder prototype. Not real employers or listings.

export const jobs = [
  { id: 1, title: "UI/UX Designer", company: "Voxa", location: "Bengaluru", type: "Full-time", salary: "₹12–18 LPA", match: 92, posted: "2d ago", tags: ["Figma", "Prototyping", "User research"], skills: ["Visual Design", "User Research", "Interaction Design"], color: "bg-lilac",
    description: "Design end-to-end flows for a consumer voice app, from research to high-fidelity prototypes.", eligibility: "0–2 years experience · Portfolio required · Any degree", apply: "Submit portfolio link and a short cover note. Demo listing." },
  { id: 2, title: "Frontend Developer", company: "Nimbus Labs", location: "Remote", type: "Full-time", salary: "₹10–16 LPA", match: 88, posted: "1d ago", tags: ["React", "Tailwind", "TypeScript"], skills: ["React", "TypeScript", "Frontend"], color: "bg-mint",
    description: "Build accessible React interfaces for a cloud dashboard and collaborate with designers on a component library.", eligibility: "Freshers welcome · Strong JavaScript & React basics", apply: "Share GitHub profile and resume. Demo listing." },
  { id: 3, title: "Product Designer Intern", company: "Brightpath", location: "Pune", type: "Internship", salary: "₹30k / month", match: 81, posted: "5h ago", tags: ["Design systems", "Figma"], skills: ["Visual Design", "Product Thinking"], color: "bg-butter",
    description: "6-month internship supporting the design system team with components, documentation and audits.", eligibility: "Final-year students or recent graduates", apply: "Resume + 2 case studies. Demo listing." },
  { id: 4, title: "Junior Web Developer", company: "Orbit Studio", location: "Hyderabad", type: "Full-time", salary: "₹6–9 LPA", match: 76, posted: "3d ago", tags: ["HTML", "CSS", "JavaScript"], skills: ["Frontend", "JavaScript"], color: "bg-blush",
    description: "Build and maintain marketing websites and landing pages for agency clients.", eligibility: "0–1 years · HTML/CSS/JS fundamentals", apply: "Resume and one live project link. Demo listing." },
  { id: 5, title: "Team Lead – Design", company: "Kite Health", location: "Remote", type: "Contract", salary: "₹20–26 LPA", match: 69, posted: "1w ago", tags: ["Leadership", "Feedback", "UX"], skills: ["Design Leadership", "Communication"], color: "bg-lilac",
    description: "Lead a team of 4 designers on a 12-month health platform contract.", eligibility: "4+ years design · 1+ year leading people", apply: "Portfolio and references. Demo listing." },
  { id: 6, title: "Tailwind CSS Developer", company: "Pixelcraft", location: "Mumbai", type: "Part-time", salary: "₹4–6 LPA", match: 85, posted: "4d ago", tags: ["Tailwind", "Responsive"], skills: ["Frontend"], color: "bg-mint",
    description: "Part-time role converting designs into responsive Tailwind pages.", eligibility: "Any experience · Tailwind portfolio", apply: "Share two Tailwind builds. Demo listing." },
];
export type Job = (typeof jobs)[number];

export type Course = { id: string; title: string; desc: string; duration: string; lessons: number; level: "Beginner" | "Intermediate" | "Advanced"; skills: string[]; goals: string[]; bg: string };
export const courses: Course[] = [
  { id: "react-pro", title: "React Pro", desc: "Advanced component patterns, hooks and performance.", duration: "6 hours", lessons: 7, level: "Intermediate", skills: ["React", "Frontend"], goals: ["Frontend Developer"], bg: "bg-blush" },
  { id: "web-foundations", title: "Web Foundations", desc: "HTML, CSS & JavaScript from scratch.", duration: "10 hours", lessons: 12, level: "Beginner", skills: ["Frontend", "JavaScript"], goals: ["Frontend Developer", "UI/UX Designer"], bg: "bg-lilac" },
  { id: "interview-prep", title: "Interview Prep", desc: "Crack technical and behavioural rounds.", duration: "5 hours", lessons: 9, level: "Advanced", skills: ["Communication", "Data Structures"], goals: ["Frontend Developer", "UI/UX Designer", "Data Analyst"], bg: "bg-butter" },
  { id: "typescript", title: "TypeScript Essentials", desc: "Types, generics and typing React apps.", duration: "4 hours", lessons: 8, level: "Intermediate", skills: ["TypeScript", "Frontend"], goals: ["Frontend Developer"], bg: "bg-mint" },
  { id: "dsa", title: "Data Structures in JS", desc: "Arrays, maps, trees and common interview problems.", duration: "8 hours", lessons: 10, level: "Intermediate", skills: ["Data Structures", "JavaScript"], goals: ["Frontend Developer", "Data Analyst"], bg: "bg-lilac" },
  { id: "communication", title: "Speaking with Confidence", desc: "Structure answers, present work and use STAR.", duration: "3 hours", lessons: 6, level: "Beginner", skills: ["Communication"], goals: ["Frontend Developer", "UI/UX Designer", "Data Analyst"], bg: "bg-blush" },
  { id: "ux-research", title: "UX Research Methods", desc: "Interviews, usability tests and synthesis.", duration: "5 hours", lessons: 8, level: "Beginner", skills: ["User Research", "Product Thinking"], goals: ["UI/UX Designer"], bg: "bg-butter" },
  { id: "design-leadership", title: "Design Leadership", desc: "Critiques, feedback and leading design teams.", duration: "4 hours", lessons: 7, level: "Advanced", skills: ["Design Leadership", "Communication"], goals: ["UI/UX Designer"], bg: "bg-mint" },
  { id: "sql-analytics", title: "SQL for Analytics", desc: "Queries, joins and dashboards for analysts.", duration: "7 hours", lessons: 10, level: "Beginner", skills: ["Data Structures", "Product Thinking"], goals: ["Data Analyst"], bg: "bg-lilac" },
];
export const courseById = (id: string) => courses.find((c) => c.id === id);

export const careerDetails: Record<string, { goal: string; skills: string[]; responsibilities: string[]; jobs: number[] }> = {
  frontend: { goal: "Frontend Developer", skills: ["Frontend", "JavaScript", "React", "TypeScript", "Data Structures", "Communication"], responsibilities: ["Build responsive, accessible user interfaces", "Turn designs into reusable components", "Work with APIs and manage app state", "Review code and fix performance issues"], jobs: [2, 4, 6] },
  uiux: { goal: "UI/UX Designer", skills: ["Visual Design", "User Research", "Interaction Design", "Product Thinking", "Design Leadership", "Communication"], responsibilities: ["Research user needs and pain points", "Create wireframes and prototypes", "Maintain a design system", "Test designs with real users"], jobs: [1, 3, 5] },
  data: { goal: "Data Analyst", skills: ["Data Structures", "Product Thinking", "Communication"], responsibilities: ["Clean and analyse datasets", "Build dashboards and reports", "Share insights with stakeholders", "Define and track key metrics"], jobs: [] },
};
export const goalSkills = (goal: string) => Object.values(careerDetails).find((c) => c.goal === goal)?.skills ?? [];

/** Recommend courses for goal, ranked by gap size. */
export function recommend(goal: string, skills: Record<string, number>, exclude: string[] = []) {
  const need = goalSkills(goal);
  return courses
    .filter((c) => !exclude.includes(c.id) && (c.goals.includes(goal) || c.skills.some((s) => need.includes(s))))
    .map((c) => {
      const gaps = c.skills.filter((s) => need.includes(s)).map((s) => ({ s, v: skills[s] ?? 0 })).sort((a, b) => a.v - b.v);
      const worst = gaps[0];
      return { course: c, score: worst ? 100 - worst.v : 0, reason: worst ? `Your ${worst.s} is at ${worst.v}% — this closes that gap for ${goal}.` : `Supports your ${goal} goal.` };
    })
    .sort((a, b) => b.score - a.score);
}

export type Question = { q: string; options: string[]; answer: number; explain: string };
export const testBank: Record<string, { skills: string[]; questions: Question[] }> = {
  JavaScript: { skills: ["JavaScript", "Frontend"], questions: [
    { q: "What does `typeof null` return?", options: ["'null'", "'object'", "'undefined'", "'number'"], answer: 1, explain: "A historical quirk: typeof null is 'object'." },
    { q: "Which method creates a new array with transformed items?", options: ["forEach", "map", "reduce", "find"], answer: 1, explain: "map returns a new array of the callback results." },
    { q: "`===` compares…", options: ["Value only", "Type only", "Value and type", "References only"], answer: 2, explain: "Strict equality checks both value and type, no coercion." },
    { q: "Which keyword declares a block-scoped constant?", options: ["var", "let", "const", "static"], answer: 2, explain: "const is block-scoped and cannot be reassigned." },
    { q: "What does `Promise.all` do if one promise rejects?", options: ["Ignores it", "Rejects immediately", "Waits for all then resolves", "Retries"], answer: 1, explain: "Promise.all rejects as soon as any input rejects." },
  ] },
  React: { skills: ["React", "Frontend"], questions: [
    { q: "Which hook stores local component state?", options: ["useEffect", "useState", "useMemo", "useRef"], answer: 1, explain: "useState returns a value and a setter." },
    { q: "Keys in lists help React…", options: ["Style items", "Identify items between renders", "Sort items", "Fetch data"], answer: 1, explain: "Keys let React match elements across renders." },
    { q: "useEffect with an empty dependency array runs…", options: ["Every render", "Never", "Once after mount", "Before mount"], answer: 2, explain: "[] means run after the first render only." },
    { q: "Props are…", options: ["Mutable by child", "Read-only inputs", "Global state", "CSS classes"], answer: 1, explain: "Children should treat props as read-only." },
    { q: "Which avoids recalculating an expensive value?", options: ["useMemo", "useState", "useId", "useContext"], answer: 0, explain: "useMemo caches a computed value between renders." },
  ] },
  "Data Structures": { skills: ["Data Structures"], questions: [
    { q: "Average lookup time in a hash map?", options: ["O(n)", "O(log n)", "O(1)", "O(n²)"], answer: 2, explain: "Hash maps give constant average lookup." },
    { q: "A stack follows…", options: ["FIFO", "LIFO", "Random order", "Priority order"], answer: 1, explain: "Last in, first out." },
    { q: "Binary search requires…", options: ["A sorted array", "A linked list", "A hash map", "Duplicates"], answer: 0, explain: "It halves a sorted range each step." },
    { q: "Which is best for BFS?", options: ["Stack", "Queue", "Heap", "Set"], answer: 1, explain: "BFS processes nodes in queue order." },
  ] },
  "Visual Design": { skills: ["Visual Design", "Interaction Design"], questions: [
    { q: "Minimum WCAG AA contrast for body text?", options: ["2:1", "3:1", "4.5:1", "7:1"], answer: 2, explain: "AA requires 4.5:1 for normal text." },
    { q: "Visual hierarchy is mainly created by…", options: ["Size, weight and contrast", "Only colour", "Animations", "Fonts count"], answer: 0, explain: "Size, weight and contrast guide attention." },
    { q: "An 8pt grid helps with…", options: ["Consistent spacing", "Colour choice", "Copywriting", "Accessibility only"], answer: 0, explain: "It keeps spacing consistent and predictable." },
    { q: "Gestalt 'proximity' means…", options: ["Close items feel related", "Similar colours", "Closed shapes", "Symmetry"], answer: 0, explain: "Items placed together are perceived as a group." },
  ] },
  Communication: { skills: ["Communication"], questions: [
    { q: "STAR stands for…", options: ["Skill, Task, Action, Result", "Situation, Task, Action, Result", "Story, Talk, Answer, Review", "Situation, Team, Action, Reason"], answer: 1, explain: "Situation, Task, Action, Result." },
    { q: "Best way to start a project walkthrough?", options: ["Tech stack", "The problem and goal", "Your title", "Tools used"], answer: 1, explain: "Lead with the problem so listeners have context." },
    { q: "When you don't know an answer, you should…", options: ["Guess confidently", "Stay silent", "Say so and reason aloud", "Change the topic"], answer: 2, explain: "Honest reasoning shows how you think." },
    { q: "Good feedback is…", options: ["Vague", "Specific and actionable", "Only positive", "Delivered publicly"], answer: 1, explain: "Specific, actionable feedback helps people improve." },
  ] },
};

export const interviewBank: Record<string, Record<string, string[]>> = {
  "Frontend Developer": {
    Easy: ["Tell me about yourself and why frontend?", "What is the difference between let, const and var?", "How do you make a page responsive?"],
    Medium: ["Explain how React decides when to re-render.", "How would you improve a slow-loading page?", "Describe a bug you fixed and how you found it."],
    Hard: ["Design the state management for a large dashboard.", "How would you build an accessible custom dropdown?", "Tell me about a disagreement with a teammate and how you resolved it."],
  },
  "UI/UX Designer": {
    Easy: ["Walk me through your design process.", "What makes a good user interface?", "How do you take feedback on your work?"],
    Medium: ["How do you validate a design decision?", "Tell me about a usability test that changed your design.", "How do you balance user needs with business goals?"],
    Hard: ["How would you build a design system from scratch?", "Describe leading a project with conflicting stakeholders.", "How do you measure the success of a redesign?"],
  },
  "Data Analyst": {
    Easy: ["Why data analysis?", "What is the difference between mean and median?", "Which tools do you use daily?"],
    Medium: ["How do you handle missing data?", "Explain a dashboard you built and its impact.", "How would you explain a finding to a non-technical manager?"],
    Hard: ["Design metrics for a new product launch.", "How would you detect a drop in user engagement?", "Tell me about an analysis that was wrong and what you learned."],
  },
};

export const people = [
  { id: 1, name: "Ananya Rao", role: "Senior UX Designer", company: "Voxa", mutual: 12, mentor: true, color: "bg-lilac", bio: "8 years designing voice and mobile products. Mentors early-career designers on portfolios.", skills: ["User Research", "Figma", "Mentoring"], location: "Bengaluru" },
  { id: 2, name: "Rahul Mehta", role: "Frontend Engineer", company: "Nimbus Labs", mutual: 8, mentor: false, color: "bg-mint", bio: "Builds React dashboards and loves accessibility.", skills: ["React", "TypeScript", "A11y"], location: "Remote" },
  { id: 3, name: "Priya Shah", role: "Product Manager", company: "Brightpath", mutual: 5, mentor: true, color: "bg-butter", bio: "PM for design-system tooling. Happy to talk career switches into product.", skills: ["Roadmaps", "Discovery"], location: "Pune" },
  { id: 4, name: "Arjun Nair", role: "Design Lead", company: "Kite Health", mutual: 15, mentor: true, color: "bg-blush", bio: "Leads a health design team. Runs monthly portfolio reviews.", skills: ["Leadership", "UX"], location: "Remote" },
  { id: 5, name: "Sneha Iyer", role: "React Developer", company: "Pixelcraft", mutual: 3, mentor: false, color: "bg-lilac", bio: "Tailwind and React enthusiast, 2 years in.", skills: ["React", "Tailwind"], location: "Mumbai" },
  { id: 6, name: "Karan Verma", role: "Data Analyst", company: "Orbit Studio", mutual: 6, mentor: false, color: "bg-mint", bio: "SQL, dashboards and experiment analysis.", skills: ["SQL", "Analytics"], location: "Hyderabad" },
];
