type SkillRadarProps = { compact?: boolean; development?: boolean };
export function SkillRadar({ compact = false, development = false }: SkillRadarProps) {
  const rings = [1, .8, .6, .4, .2];
  const point = (i: number, r: number) => `${160 + Math.sin(i * Math.PI / 3) * 105 * r},${150 - Math.cos(i * Math.PI / 3) * 105 * r}`;
  const values = development ? [.8, .65, .6, .75, .9, .65] : [.84, .58, .37, .32, .92, .74];
  return <svg viewBox="0 0 320 300" className={compact ? "mx-auto w-full max-w-72" : "mx-auto w-full max-w-96"} role="img" aria-label={development ? "Current, theoretical and expected skill comparison" : "Skill graph: research 84, content 58, leadership 37, product thinking 32, visual design 92, interaction 74"}>
    {rings.map(r => <polygon key={r} points={Array.from({ length: 6 }, (_, i) => point(i, r)).join(" ")} fill="none" stroke="var(--border)" strokeWidth="2" />)}
    {Array.from({ length: 6 }, (_, i) => <line key={i} x1="160" y1="150" x2={point(i, 1).split(",")[0]} y2={point(i, 1).split(",")[1]} stroke="var(--border)" />)}
    <polygon points={values.map((r,i) => point(i,r)).join(" ")} fill={development ? "var(--chart-green)" : "var(--violet)"} fillOpacity=".3" stroke={development ? "var(--chart-green)" : "var(--violet)"} strokeWidth="3" />
    {development ? <polygon points={[.28,.15,.35,.3,.85,.2].map((r,i)=>point(i,r)).join(" ")} fill="var(--chart-cyan)" fillOpacity=".35" stroke="var(--chart-cyan)" strokeWidth="2" /> : values.map((r,i)=><circle key={i} cx={point(i,r).split(",")[0]} cy={point(i,r).split(",")[1]} r="5" fill="var(--violet)" stroke="var(--card)" strokeWidth="2" />)}
    {(development ? ["1", "2", "3", "4", "5", "6"] : ["RES 84", "CON 58", "LEA 37", "PT 32", "VIS 92", "INT 74"]).map((label,i)=><text key={i} x={point(i,1.22).split(",")[0]} y={Number(point(i,1.22).split(",")[1])+4} textAnchor="middle" fill="var(--foreground)" fontSize="10">{label}</text>)}
  </svg>;
}