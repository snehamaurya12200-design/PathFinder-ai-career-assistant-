import { Link } from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";
import {
  LayoutGrid, Search, Lightbulb, BriefcaseBusiness, GraduationCap, Users, MessageCircle,
  LifeBuoy, Settings, Sun, Moon, MoonStar, Bell, Sparkles,
} from "lucide-react";
import shapes from "@/assets/shapes.png";

const nav = [
  { to: "/", label: "Dashboard", icon: LayoutGrid },
  { to: "/assistant", label: "AI Assistant", icon: MessageCircle },
  { to: "/roadmap", label: "Explore Careers", icon: Search },
  { to: "/skills", label: "My Skills", icon: Lightbulb },
  { to: "/jobs", label: "Job Board", icon: BriefcaseBusiness },
  { to: "/learning", label: "Learning", icon: GraduationCap },
  { to: "/networking", label: "Networking", icon: Users },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen p-3 md:p-8">
      <div className="mx-auto flex max-w-[1400px] overflow-hidden rounded-3xl bg-background shadow-soft">
        <aside className="hidden w-60 shrink-0 flex-col bg-sidebar p-5 lg:flex">
          <div className="mb-8 flex items-center gap-2 font-bold">
            <span className="grid h-7 w-7 place-items-center rounded-lg bg-ink text-xs text-ink-foreground">P</span>
            Pathfinder
          </div>
          <nav className="space-y-1">
            {nav.map((n, i) => (
              <Link
                key={i}
                to={n.to}
                activeOptions={{ exact: true }}
                className="flex items-center gap-3 rounded-xl px-3 py-2 text-sm text-foreground/80 hover:bg-card/60"
                activeProps={n.to !== "/" || i === 0 ? { className: "bg-card font-semibold text-foreground" } : {}}
              >
                <n.icon className="h-4 w-4" /> {n.label}
              </Link>
            ))}
          </nav>
          <div className="relative mt-auto rounded-2xl bg-card/70 p-4 pt-20 text-center">
            <img src={shapes} alt="" width={816} height={816} loading="lazy" className="absolute -top-10 left-1/2 w-32 -translate-x-1/2" />
            <p className="font-bold">Upgrade to Pro</p>
            <p className="mt-1 text-xs text-muted-foreground">Unlock mock interviews and AI roadmaps</p>
            <span className="mt-2 inline-block rounded-full bg-butter px-2 py-0.5 text-[10px] font-semibold">Free for 1 month</span>
            <button className="mt-3 w-full rounded-full bg-ink py-2 text-xs font-semibold text-ink-foreground">Upgrade now</button>
          </div>
          <div className="mt-5 space-y-2 text-sm text-foreground/80">
            <p className="flex items-center gap-3 px-3"><LifeBuoy className="h-4 w-4" /> Support Center</p>
            <p className="flex items-center gap-3 px-3"><Settings className="h-4 w-4" /> Settings</p>
          </div>
        </aside>
        <main className="min-w-0 flex-1 p-5 md:p-7">
          <header className="mb-6 flex items-center gap-3">
            <div className="flex w-full max-w-xs items-center gap-2 rounded-full bg-muted px-4 py-2 text-sm text-muted-foreground">
              <Search className="h-4 w-4" /> Search careers, skills…
            </div>
            <Link to="/assistant" className="ai-ring flex items-center gap-1.5 rounded-full px-4 py-1.5 text-xs font-semibold">
              AI Assistant <Sparkles className="h-3.5 w-3.5" />
            </Link>
            <div className="ml-auto flex items-center gap-4">
              <ThemeToggle />
              <Bell className="h-5 w-5" />
              <span className="grid h-9 w-9 place-items-center rounded-full bg-sun font-bold">S</span>
            </div>
          </header>
          {children}
        </main>
      </div>
    </div>
  );
}

const modes = ["light", "dark", "night"] as const;
type Mode = (typeof modes)[number];
function applyMode(m: Mode) {
  const el = document.documentElement;
  el.classList.toggle("dark", m !== "light");
  el.classList.toggle("night", m === "night");
}
function ThemeToggle() {
  const [mode, setMode] = useState<Mode>("light");
  useEffect(() => {
    const saved = localStorage.getItem("theme-mode") as Mode | null;
    if (saved && modes.includes(saved)) { setMode(saved); applyMode(saved); }
  }, []);
  const next = () => {
    const m = modes[(modes.indexOf(mode) + 1) % modes.length]!;
    setMode(m); applyMode(m); localStorage.setItem("theme-mode", m);
  };
  const Icon = mode === "light" ? Sun : mode === "dark" ? Moon : MoonStar;
  const label = mode === "light" ? "Light mode" : mode === "dark" ? "Dark mode" : "Night mode";
  return (
    <button onClick={next} aria-label={`${label} – click to switch`} title={label} className="flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-medium transition hover:bg-muted">
      <Icon className="h-4 w-4" /><span className="hidden sm:inline">{label.replace(" mode", "")}</span>
    </button>
  );
}
